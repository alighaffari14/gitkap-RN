import { IMLocalized } from "./Core/localization/IMLocalization";
import AppStyles from "./DynamicAppStyles";

const ListingAppConfig = {
  isSMSAuthEnabled: true,
  appIdentifier: "rn-real-estate-android",
  onboardingConfig: {
    welcomeTitle: IMLocalized("Welcome to your app"),
    welcomeCaption: IMLocalized(
      "Use this codebase to build your own real estate app in minutes."
    ),
    walkthroughScreens: [
      {
        icon: require("../assets/icons/logo.png"),
        title: IMLocalized("Build your perfect app"),
        description: IMLocalized("Launch your own real estate app in minutes.")
      },
      {
        icon: require("../assets/icons/map.png"),
        title: IMLocalized("Map View"),
        description: IMLocalized(
          "Visualize houses on the map to make your search easier."
        )
      },
      {
        icon: require("../assets/icons/heart.png"),
        title: IMLocalized("Saved Places"),
        description: IMLocalized(
          "Save your favorite places to come back to them later."
        )
      },
      {
        icon: require("../assets/icons/filters.png"),
        title: IMLocalized("Advanced Custom Filters"),
        description: IMLocalized(
          "Custom dynamic filters to accommodate all markets and all customer needs."
        )
      },
      {
        icon: require("../assets/icons/instagram.png"),
        title: IMLocalized("Add New Listings"),
        description: IMLocalized(
          "Add new listings directly from the app, including photo gallery and filters."
        )
      },
      {
        icon: require("../assets/icons/chat.png"),
        title: IMLocalized("Chat"),
        description: IMLocalized(
          "Communicate with your customers and real estate agents in real-time."
        )
      },
      {
        icon: require("../assets/icons/notification.png"),
        title: IMLocalized("Get Notified"),
        description: IMLocalized(
          "Stay on top of your game with real-time push notifications."
        )
      }
    ]
  },

  tabIcons: {
    Home: {
      focus: AppStyles.iconSet.homefilled,
      unFocus: AppStyles.iconSet.homeUnfilled
    },
    Categories: {
      focus: AppStyles.iconSet.collections,
      unFocus: AppStyles.iconSet.collections
    },
    Messages: {
      focus: AppStyles.iconSet.commentFilled,
      unFocus: AppStyles.iconSet.commentUnfilled
    },
    Search: {
      focus: AppStyles.iconSet.search,
      unFocus: AppStyles.iconSet.search
    }
  },
  reverseGeoCodingAPIKey: "AIzaSyCDeWXVrJxUCRQlpcWK2JJQSB-kFVjCqlM"
};

export default ListingAppConfig;
