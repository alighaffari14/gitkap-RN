import moment from 'moment';
import { Platform } from 'react-native';

export const timeFormatAndroid = timeStamp => {
  time = '';
  if (timeStamp) {
    if (moment().diff(timeStamp, 'days') == 0) {
      time = moment(timeStamp).format('H:mm');
    } else {
      time = moment(timeStamp).fromNow();
    }
  }
  // time = postTime.toUTCString();
  return time;
  // return '21:07';
};
export const timeFormatIos = timeStamp => {
  time = '';
  if (timeStamp) {
    const timeStampSeconds = timeStamp.seconds
      ? timeStamp.seconds
      : timeStamp._seconds;

    if (moment().diff(moment.unix(timeStampSeconds), 'days') === 0) {
      time = moment.unix(timeStampSeconds).format('H:mm');
    } else {
      time = moment.unix(timeStampSeconds).fromNow();
    }
  }
  return time;
  // return '21:07';
};

export const timeFormat =
  Platform.OS === 'ios' ? timeFormatIos : timeFormatAndroid;
