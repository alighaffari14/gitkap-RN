// @flow
import React from 'react';
import {View, TextInput, Text} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';
import Button from 'react-native-button';
import LinearGradient from 'react-native-linear-gradient';
import PhoneInput from 'react-native-phone-input';

import CountriesModalPicker from '../../../truly-native/CountriesModalPicker/CountriesModalPicker';

// import styles from './ResturantUserForm.styles';
import {IMLocalized} from '../../../localization/IMLocalization';
import colors from '../../../../shared/colors';
import ListingAppConfig from '../../../../ListingAppConfig';
import {INDIVIDUAL} from '../../../../shared/strings';

type IndividualUserFormProps = {};
type IndividualUserFormState = {};

class IndividualUserFormComponent extends React.PureComponent<IndividualUserFormProps, IndividualUserFormState> {
    static defaultProps: any

    constructor(props: ResturantUserFormProps) {
      super(props);
      this.state = {
        name: '',
        email: '',
        password: '',
      };
    }

    phoneRef: null

    componentDidMount() {
      // this.setState({
      //     pickerData: this.phone.getPickerData()
      // })
    }

    onRegister = () => {
      const {name, email, password} = this.state;
      const userDetails = {
        name: name,
        email: email,
        password: password,
        appIdentifier: ListingAppConfig.appIdentifier,
        type: INDIVIDUAL,
      };
      this.props.register(userDetails);
    }

    onLogin = () => {
      this.props.login();
    }

    setUserName = (text) => {
      this.setState({name: text});
    }

    setEmail = (text) => {
      this.setState({email: text});
    }

    setPassword = (text) => {
      this.setState({password: text});
    }

    setWorkingHours = (text) => {
      this.setState({workingHours: text});
    }

    renderContent = (): ReactElement<any> => {
      const {styles} = this.props;

      return (
          <>
          <TextInput
                  onChangeText={this.setUserName}
                    placeholder={IMLocalized('User Name')}
                    placeholderTextColor="#aaaaaa"
                    style={styles.InputContainer}
                    underlineColorAndroid="transparent"
                    value={this.state.name}
          />

          <TextInput
            autoCapitalize='none'
                    onChangeText={this.setEmail}
                    placeholder={IMLocalized('E-mail Address')}
                    placeholderTextColor="#aaaaaa"
                    style={styles.InputContainer}
                    underlineColorAndroid="transparent"
                    value={this.state.email}
          />
              <TextInput
                  onChangeText={this.setPassword}
                    placeholder={IMLocalized('Password')}
                    placeholderTextColor="#aaaaaa"
                    secureTextEntry
                    style={styles.InputContainer}
                    underlineColorAndroid="transparent"
                    value={this.state.password}
          />
          <LinearGradient
                  colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
                    style={styles.signupContainer}
                >
                  <Button
              // containerStyle={styles.signupContainer}
              onPress={this.onRegister}
                        style={styles.signupText}
            >
              {IMLocalized('Sign Up')}
            </Button>
          </LinearGradient>
          <Button
            containerStyle={styles.signInContainer}
                    onPress={this.onLogin}
                    style={styles.signInText}
          >
            {IMLocalized('Login')}
          </Button>
        </>
      );
    }

    render() {
      const content = this.renderContent();

      return content;
    }
}

IndividualUserFormComponent.propTypes = {};

IndividualUserFormComponent.defaultProps = {};

export default IndividualUserFormComponent;
