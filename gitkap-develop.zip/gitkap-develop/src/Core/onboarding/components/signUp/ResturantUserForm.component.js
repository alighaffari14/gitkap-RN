// @flow
import React from 'react';
import { View, TextInput, Text, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import type { Element as ReactElement } from 'react';
import Button from 'react-native-button';
import LinearGradient from 'react-native-linear-gradient';
import PhoneInput from 'react-native-phone-input';
import TimePicker from 'react-native-24h-timepicker';

import CountriesModalPicker from '../../../truly-native/CountriesModalPicker/CountriesModalPicker';

import styles from './ResturantUserForm.styles';
import { IMLocalized } from '../../../localization/IMLocalization';
import colors from '../../../../shared/colors';
import ListingAppConfig from '../../../../ListingAppConfig';
import { BUSINESS } from '../../../../shared/strings';

type ResturantUserFormProps = {};
type ResturantUserFormState = {};

class ResturantUserFormComponent extends React.PureComponent<ResturantUserFormProps, ResturantUserFormState> {
  static defaultProps: any

  constructor(props: ResturantUserFormProps) {
    super(props);
    this.state = {
      businessName: '',
      JobDescription: '',
      homeAddress: '',
      taxNo: '',
      email: '',
      password: '',
      workingHours: '',
      countryModalVisible: false,
      country: '',
      startTimer: '',
      finishTimer: '',
      phoneNumber: '',
      noOfOrders: '',
      about: '',
    };
  }

  phoneRef: null

  componentDidMount() {
    // this.setState({
    //     pickerData: this.phone.getPickerData()
    // })
  }

  onRegister = (text) => {
    const { businessName, JobDescription, homeAddress, taxNo, email, password, workingHours, country, startTimer, finishTimer, phoneNumber, about } = this.state;
    const userDetails = {
      businessName: businessName,
      JobDescription: JobDescription,
      homeAddress: homeAddress,
      taxNo: taxNo,
      workingHours: workingHours,
      email: email,
      password: password,
      appIdentifier: ListingAppConfig.appIdentifier,
      type: BUSINESS,
      startTimer: startTimer,
      finishTimer: finishTimer,
      phoneNumber: phoneNumber,
      aboutResturant: about,
    };
    // console.log('userDetails', userDetails);
    this.props.register(userDetails);
  }

  onLogin = () => {
    this.props.login();
  }

  onSelectCountry = (country) => {
    this.setState({ country });
  }

  setbusinessName = (text) => {
    this.setState({ businessName: text });
  }

  setJobDescription = (text) => {
    this.setState({ JobDescription: text });
  }

  sethomeAddress = (text) => {
    this.setState({ homeAddress: text });
  }

  setTaxNo = (text) => {
    this.setState({ taxNo: text });
  }

  setPhoneNum = (text) => {
    this.setState({ phoneNumber: text });
  }

  setEmail = (text) => {
    this.setState({ email: text });
  }

  setPassword = (text) => {
    this.setState({ password: text });
  }

  setWorkingHours = (text) => {
    this.setState({ workingHours: text });
  }

  onPressFlag = () => {
    // this.myCountryPicker.open()
    this.setState({
      countryModalVisible: true,
    });
  }

  selectCountry(country) {
    this.phone.selectCountry(country.iso2);
  }

  onPressCancelContryModalPicker = () => {
    this.setState({ countryModalVisible: false });
  }

  contactPhoneInputRender = () => {
    const { styles, appStyles } = this.props;
    const { pickerData, countryModalVisible } = this.state;

    return (
      <>
        <PhoneInput
          allowZeroAfterCountryCode
          flagStyle={styles.flagStyle}
          offset={10}
          // ref={phoneRef}
          onPressFlag={this.onPressFlag}
          ref={(ref) => {
            this.phone = ref;
          }}
          style={styles.InputContainer}
          textProps={{ placeholder: IMLocalized('Contact number'), placeholderTextColor: '#aaaaaa' }}
          textStyle={styles.phoneInputTextStyle}
        />
        {pickerData && (
          <CountriesModalPicker
            appStyles={appStyles}
            cancelText={IMLocalized('Cancel')}
            data={pickerData}
            onCancel={this.onPressCancelContryModalPicker}
            onChange={this.onSelectCountry}
            visible={countryModalVisible}
          />
        )}
      </>
    );
  };

  onConfirmStart(hour, minute) {
    this.setState({ startTimer: `${hour}:${minute}` });
    this.startTimePicker.close();
  }

  onConfirmFinsh(hour, minute) {
    this.setState({ finishTimer: `${hour}:${minute}` });
    this.finishTimePicker.close();
  }

  renderStartTimePicker = () => {
    return (
      <TimePicker
        onCancel={() => this.onCancel()}
        onConfirm={(hour, minute) => this.onConfirmStart(hour, minute)}
        ref={(ref) => {
          this.startTimePicker = ref;
        }}
      />
    );
  }

  renderFinishTimePicker = () => {
    return (
      <TimePicker
        onCancel={() => this.onCancel()}
        onConfirm={(hour, minute) => this.onConfirmFinsh(hour, minute)}
        ref={(ref) => {
          this.finishTimePicker = ref;
        }}
      />
    );
  }

  renderTimePickerText = () => {
    const { startTimer, finishTimer } = this.state;

    return (
      <View style={{ flexDirection: 'row', justifyContent: 'space-around' }}>
        <TouchableOpacity
          onPress={() => this.startTimePicker.open()}
          style={styles.timePicker}
        >
          <Text style={styles.buttonText}>Open Time</Text>
          <Text style={styles.buttonText}>{startTimer}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => this.finishTimePicker.open()}
          style={styles.timePicker}
        >
          <Text style={styles.buttonText}>Close Time</Text>
          <Text style={styles.buttonText}>{finishTimer}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  PhoneInputRender = () => {
    const { styles, appStyles } = this.props;
    const { pickerData, countryModalVisible } = this.state;

    return (
      <>
        <PhoneInput
          allowZeroAfterCountryCode
          flagStyle={styles.flagStyle}
          offset={10}
          onPressFlag={this.onPressFlag}
          ref={this.phoneRef}
          ref={(ref) => {
            this.phone = ref;
          }}
          style={styles.InputContainer}
          textProps={{ placeholder: IMLocalized('Phone number'), placeholderTextColor: '#aaaaaa' }}
          textStyle={styles.phoneInputTextStyle}
        />
        {pickerData && (
          <CountriesModalPicker
            appStyles={appStyles}
            cancelText={IMLocalized('Cancel')}
            data={pickerData}
            onCancel={this.onPressCancelContryModalPicker}
            onChange={this.onSelectCountry}
            visible={countryModalVisible}
          />
        )}
      </>
    );
  };

  renderContent = (): ReactElement<any> => {
    const { styles } = this.props;

    return (
      <>
        <TextInput
          onChangeText={this.setbusinessName}
          placeholder={IMLocalized('Business Name')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.businessName}
        />
        <TextInput
          onChangeText={this.setJobDescription}
          placeholder={IMLocalized('Job description')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.JobDescription}
        />

        <TextInput
          onChangeText={(text) => this.setState({ about: text })}
          placeholder={IMLocalized('About Resturant')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.about}
        />

        <TextInput
          onChangeText={this.sethomeAddress}
          placeholder={IMLocalized('Home Address')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.homeAddress}
        />

        <TextInput
          onChangeText={this.setTaxNo}
          placeholder={IMLocalized('Tax No')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.taxNo}
        />

        <TextInput
          onChangeText={this.setPhoneNum}
          placeholder={IMLocalized('Phone Number')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.phoneNumber}
        />

        {this.renderStartTimePicker()}
        {this.renderFinishTimePicker()}
        {this.renderTimePickerText()}

        {/* <TextInput
            onChangeText={this.setWorkingHours}
            placeholder={IMLocalized('Working Hours')}
                  placeholderTextColor="#aaaaaa"
                  style={styles.InputContainer}
            underlineColorAndroid="transparent"
            value={this.state.workingHours}
          /> */}
        {/* {this.contactPhoneInputRender()} */}

        <View style={{ alignItems: 'center', justifyContent: 'center', marginVertical: 17, paddingTop: 10, fontSize: 14 }}>
          <Text style={{ color: colors.lightPurple }}>----- Login information -----</Text>
        </View>

        {/* {this.PhoneInputRender()} */}
        <TextInput
          autoCapitalize="none"
          onChangeText={this.setEmail}
          placeholder={IMLocalized('E-mail Address')}
          placeholderTextColor="#aaaaaa"
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.email}
        />
        <TextInput
          onChangeText={this.setPassword}
          placeholder={IMLocalized('Password')}
          placeholderTextColor="#aaaaaa"
          secureTextEntry
          style={styles.InputContainer}
          underlineColorAndroid="transparent"
          value={this.state.password}
        />
        <View style={{ paddingBottom: 20 }}>
          <LinearGradient
            colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
            style={styles.signupContainer}
          >
            <Button
              // containerStyle={styles.signupContainer}
              onPress={this.onRegister}
              style={styles.signupText}
            >
              {IMLocalized('Sign Up')}
            </Button>
          </LinearGradient>
          <Button
            containerStyle={styles.signInContainer}
            onPress={this.onLogin}
            style={styles.signInText}
          >
            {IMLocalized('Login')}
          </Button>
        </View>
      </>
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

ResturantUserFormComponent.propTypes = {};

ResturantUserFormComponent.defaultProps = {};

export default ResturantUserFormComponent;
