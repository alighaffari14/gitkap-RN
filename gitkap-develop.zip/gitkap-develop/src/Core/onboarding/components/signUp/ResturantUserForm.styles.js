// @flow
import {StyleSheet, I18nManager} from 'react-native';
import colors from '../../../../shared/colors';

const style = StyleSheet.create({
  timePicker: {
    alignItems: 'center',
    alignSelf: 'center',
    borderColor: colors.lightGray,
    borderRadius: 5,
    borderWidth: 1,
    color: colors.gray,
    height: 52,
    justifyContent: 'center',
    marginTop: 20,
    paddingLeft: 20,
    textAlign: I18nManager.isRTL ? 'right' : 'left',
    width: '40%',
  },
});

export default style;
