import React, { useEffect } from 'react';
import { View } from 'react-native';
import PropTypes from 'prop-types';
import deviceStorage from '../utils/AuthDeviceStorage';
import { setUserData } from '../redux/auth';
import { connect } from 'react-redux';

function LoadScreen(props) {
  const { navigation } = props;

  const appStyles = (navigation.state.params.appStyles || props.navigation.getParam('appStyles'));
  const appConfig = (navigation.state.params.appConfig || props.navigation.getParam('appConfig'));

  useEffect(() => {
    setAppState();
  }, []);

  const setAppState = async () => {
    // const shouldShowDasboardFlow = await deviceStorage.getShouldShowDashboardFlow();
    // const shouldShowOnboardingFlow = await deviceStorage.getShouldShowOnboardingFlow();
    const userData = await deviceStorage.getUserData();

    const user = JSON.parse(userData);




    // console.log('user', !!user);
    // if (shouldShowOnboardingFlow) {
    //     navigation.navigate("Walkthrough", { appStyles: appStyles, appConfig: appConfig });
    // } else
    if (user == 'false' || !user) {

      navigation.navigate('Login', { appStyles: appStyles, appConfig: appConfig });
    } else {
      props.setUserData(user)
      navigation.navigate('search', { appStyles: appStyles, appConfig: appConfig });
    }

    // if (!props.user11) {
    //     navigation.navigate("Login", { appStyles: appStyles, appConfig: appConfig });
    // } else if (shouldShowDasboardFlow) {
    //     navigation.navigate("MainStack", { appStyles: appStyles, appConfig: appConfig });
    // }
    // if (shouldShowOnboardingFlow) {
    //     navigation.navigate("Walkthrough", { appStyles: appStyles, appConfig: appConfig });
    // } else {
    //     navigation.navigate("search", { appStyles: appStyles, appConfig: appConfig });
    // }
  };

  return <View />;
}

LoadScreen.propTypes = {
  // user: PropTypes.object,
  navigation: PropTypes.object,
};

LoadScreen.navigationOptions = {
  header: null,
};



export default connect(null, {
  setUserData,
})(LoadScreen);
