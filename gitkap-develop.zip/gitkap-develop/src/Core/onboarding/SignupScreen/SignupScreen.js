import React, { useState } from 'react';
import { Text, TextInput, View, Alert, Image, TouchableOpacity } from 'react-native';
import Button from 'react-native-button';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useDynamicStyleSheet } from 'react-native-dark-mode';
import { connect } from 'react-redux';

import authDeviceStorage from '../utils/AuthDeviceStorage';
import TNActivityIndicator from '../../truly-native/TNActivityIndicator';
import ResturantUserFormComponent from '../components/signUp/ResturantUserForm.component';
import IndividualUserFormComponent from '../components/signIn/IndividualUserForm.component';
import TNProfilePictureSelector from '../../truly-native/TNProfilePictureSelector/TNProfilePictureSelector';
import { setUserData } from '../redux/auth';
import { localizedErrorMessage } from '../utils/ErrorCode';

import dynamicStyles from './styles';
import { IMLocalized } from '../../localization/IMLocalization';
import authManager from '../utils/authManager';
import { INDIVIDUAL, BUSINESS } from '../../../shared/strings';

function SignupScreen(props) {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [personal, setPersonal] = useState(true);

  const [profilePictureURL, setProfilePictureURL] = useState(null);
  const [loading, setLoading] = useState(false);

  const appConfig = (props.navigation.state.params.appConfig || props.navigation.getParam('appConfig'));
  const appStyles = (props.navigation.state.params.appStyles || props.navigation.getParam('appStyles'));
  const styles = useDynamicStyleSheet(dynamicStyles(appStyles));

  const onRegister = (userDetails) => {
    setLoading(true);
    if (!((userDetails.businessName || userDetails.name) && userDetails.password && userDetails.email)) {
      Alert.alert('Please enter required fields');
      setLoading(false);

      return;
    } else {
      authManager
        .createAccountWithEmailAndPassword(userDetails, appConfig.appIdentifier)
        .then((response) => {
          const user = response.user;
          if (user) {
            props.setUserData({ user: user });
            props.navigation.navigate('search', { user: user });
          } else {
            Alert.alert('', localizedErrorMessage(response.error), [{ text: IMLocalized('OK') }], {
              cancelable: false,
            });
          }
          setLoading(false);
        });
    }
  };

  const onIndividualRegister = (userDetails) => {
    setLoading(true);

    if (!((userDetails.businessName || userDetails.name) && userDetails.password && userDetails.email)) {
      Alert.alert('Please enter required fields');
      setLoading(false);

      return;
    }

    authManager
      .createAccountWithEmailAndPassword(userDetails, appConfig.appIdentifier)
      .then((response) => {
        const user = response.user;
        if (user) {
          props.setUserData({ user: user });
          props.navigation.navigate('search', { user: user, appConfig, appStyles });
        } else {
          Alert.alert('', localizedErrorMessage(response.error), [{ text: IMLocalized('OK') }], {
            cancelable: false,
          });
        }
        setLoading(false);
      });
  };

  const handleIndividual = () => {
    setPersonal(true);
  };

  const handleBusiness = () => {
    setPersonal(false);
  };

  const onLogin = () => {
    props.navigation.navigate('Login', { appStyles, appConfig });
  };

  function renderBusinessForm() {
    return (
      <ResturantUserFormComponent
        appStyles={appStyles}
        login={onLogin}
        register={onRegister}
        styles={styles}
      />
    );
  }

  function renderPersonalForm() {
    return (
      <IndividualUserFormComponent
        appStyles={appStyles}
        login={onLogin}
        register={onIndividualRegister}
        styles={styles}
      />
    );
  }

  function renderTabBar() {
    const tabBarStylePersonal = personal ? styles.tabBarIndividual : null;
    const tabBarStyleBusiness = !personal ? styles.tabBarIndividual : null;

    return (
      <View style={{ flex: 1, flexDirection: 'row', width: '100%' }}>
        <TouchableOpacity
          onPress={handleIndividual}
          style={styles.tabBar}
        >
          <View style={tabBarStylePersonal}>
            <Text>{INDIVIDUAL}</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleBusiness}
          style={styles.tabBar}
        >
          <View style={tabBarStyleBusiness}>
            <Text>{BUSINESS}</Text>
          </View>
        </TouchableOpacity>

      </View>
    );
  }

  const renderForms = () => {
    const currentRender = personal ? renderPersonalForm() : renderBusinessForm();

    return currentRender;
  };

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView
        keyboardShouldPersistTaps="always"
        style={{ flex: 1, width: '100%' }}
      >
        {/* <TouchableOpacity onPress={() => props.navigation.goBack()}>
          <Image style={appStyles.styleSet.backArrowStyle} source={appStyles.iconSet.backArrow} />
        </TouchableOpacity> */}
        {/* <Text style={styles.title}>{IMLocalized('Create new account')}</Text> */}
        {/* <TNProfilePictureSelector
          setProfilePictureURL={setProfilePictureURL}
          appStyles={appStyles}
        /> */}
        <View style={{ padding: 30 }}>
          <Text style={{ fontSize: 30 }}>Offer</Text>
          <Text style={{ fontSize: 30, fontWeight: 'bold' }}>Oppotunity!</Text>
        </View>
        {renderTabBar()}
        {renderForms()}
        {appConfig.isSMSAuthEnabled && (
          <>
            {/* <Text style={styles.orTextStyle}>{IMLocalized('OR')}</Text>
            <Button
              containerStyle={styles.PhoneNumberContainer}
              onPress={() => props.navigation.goBack()}
            >
              {IMLocalized('Sign up with phone number')}
            </Button> */}
          </>
        )}
      </KeyboardAwareScrollView>
      {loading && <TNActivityIndicator appStyles={appStyles} />}
    </View>
  );
}

export default connect(null, {
  setUserData,
})(SignupScreen);
