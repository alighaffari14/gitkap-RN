import AsyncStorage from '@react-native-community/async-storage';

const SHOULD_SHOW_ONBOARDING_FLOW = 'SHOULD_SHOW_ONBOARDING_FLOW';
const SHOULD_SHOW_DASHBOARD = 'SHOULD_SHOW_DASHBOARD';
export const USER_DATA = 'USER_DATA';
const USER_LOCATION = 'USER_LOCATION';

/**
 * Get Should Show Onboarding
 * @param {String} value
 * @return {Boolean}
 */
const getShouldShowOnboardingFlow = async () => {
  try {
    const result = await AsyncStorage.getItem(SHOULD_SHOW_ONBOARDING_FLOW);

    return result !== null ? false : true;
  } catch (err) {
  }
};

/**
 * Set Should Show OnBoarding Flow
 * @param {String} value
 *
 */
const setShouldShowOnboardingFlow = async (value) => {
  try {
    await AsyncStorage.setItem(SHOULD_SHOW_ONBOARDING_FLOW, value);
  } catch (err) {
  }
};

/**
 * Get Should Show dasboard
 * @param {String} value
 * @return {Boolean}
 */
const getShouldShowDashboardFlow = async () => {
  try {
    const result = await AsyncStorage.getItem(SHOULD_SHOW_DASHBOARD);

    return result;
  } catch (err) {
  }
};

/**
 * Set Should Show Dasboard Flow
 * @param {String} value
 *
 */
const setShouldShowOnDashboardFlow = async (value) => {
  try {
    await AsyncStorage.setItem(SHOULD_SHOW_DASHBOARD, value);
  } catch (err) {
  }
};

/**
 * Get user data
 * @param {String} value
 * @return {Boolean}
 */
const getUserData = async () => {
  try {
    const result = await AsyncStorage.getItem(USER_DATA);

    return result;
  } catch (err) {
  }
};

/**
 * Set user data
 * @param {String} value
 *
 */
const setUserData = async (value) => {
  try {
    await AsyncStorage.setItem(USER_DATA, value && JSON.stringify(value));
  } catch (err) {
  }
};

/**
 * Get user location
 * @param {String} value
 * @return {Boolean}
 */
const getUserLocation = async () => {
  try {
    const result = await AsyncStorage.getItem(USER_LOCATION);

    return result;
  } catch (err) {
  }
};

/**
 * Set user location
 * @param {String} value
 *
 */
const setUserLocation = async (value) => {
  try {
    await AsyncStorage.setItem(USER_LOCATION, value && JSON.stringify(value));
  } catch (err) {
  }
};

const authDeviceStorage = {
  getShouldShowOnboardingFlow,
  setShouldShowOnboardingFlow,

  getShouldShowDashboardFlow,
  setShouldShowOnDashboardFlow,

  getUserData,
  setUserData,

  getUserLocation,
  setUserLocation,
};

export default authDeviceStorage;
