import React, { useState } from 'react';
import { Text, TextInput, View, Alert, TouchableOpacity, Image } from 'react-native';
import Button from 'react-native-button';
import LinearGradient from 'react-native-linear-gradient';
import { connect } from 'react-redux';
import { useDynamicStyleSheet } from 'react-native-dark-mode';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

import TNActivityIndicator from '../../truly-native/TNActivityIndicator';
import { IMLocalized } from '../../localization/IMLocalization';
import { setUserData } from '../redux/auth';
import authManager from '../utils/authManager';
import { localizedErrorMessage } from '../utils/ErrorCode';

import dynamicStyles from './styles';
import colors from '../../../shared/colors';
import authDeviceStorage from '../utils/AuthDeviceStorage';

function LoginScreen(props) {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const appStyles = (props.navigation.state.params.appStyles || props.navigation.getParam('appStyles'));
  const styles = useDynamicStyleSheet(dynamicStyles(appStyles));
  const appConfig = (props.navigation.state.params.appConfig || props.navigation.getParam('appConfig'));

  const onPressLogin = () => {
    if (!(email && password)) {
      Alert.alert('Please enter all fields');

      return;
    }
    setLoading(true);
    authManager
      .loginWithEmailAndPassword(email, password)
      .then((response) => {

        if (response.user) {
          const user = response.user;
          authDeviceStorage.setShouldShowOnDashboardFlow('true');
          props.setUserData(user);
          props.navigation.navigate('MainStack', { user: user });
        } else {
          setLoading(false);
          Alert.alert('', localizedErrorMessage(response.error), [{ text: IMLocalized('OK') }], {
            cancelable: false,
          });
        }
      });
  };

  const onRegister = () => {
    props.navigation.navigate('Signup', { appStyles: appStyles, appConfig: appConfig });
  };

  const onFBButtonPress = () => {
    authManager
      .loginOrSignUpWithFacebook(appConfig.appIdentifier)
      .then((response) => {
        if (response.user) {
          const user = response.user;
          props.setUserData(user);
          props.navigation.navigate('search', { user: user });
        } else {
          Alert.alert('', localizedErrorMessage(response.error), [{ text: IMLocalized('OK') }], {
            cancelable: false,
          });
        }
      });
  };

  return (
    <View style={styles.container}>
      <KeyboardAwareScrollView keyboardShouldPersistTaps='always' style={{ flex: 1, width: '100%' }}>
        <View>
          <TouchableOpacity
            onPress={() => props.navigation.goBack()}
            style={{ alignSelf: 'flex-start' }}
          >
            <Image style={appStyles.styleSet.backArrowStyle}
              source={appStyles.iconSet.backArrow} />
          </TouchableOpacity>
          {/* <Text style={styles.title}>{IMLocalized('Sign In')}</Text> */}
          <View style={{ padding: 30 }}>
            <Text style={{ fontSize: 30 }}>Welcome to take</Text>
            <Text style={{ fontSize: 30, fontWeight: 'bold' }}>Oppotunity!</Text>
          </View>
        </View>
        <View>
          <TextInput
            autoCapitalize='none'
            onChangeText={text => setEmail(text)}
            placeholder={IMLocalized('E-mail')}
            placeholderTextColor="#aaaaaa"
            style={styles.InputContainer}
            underlineColorAndroid="transparent"
            value={email}
          />
          <TextInput
            onChangeText={text => setPassword(text)}
            placeholder={IMLocalized('Password')}
            placeholderTextColor="#aaaaaa"
            secureTextEntry
            style={styles.InputContainer}
            underlineColorAndroid="transparent"
            value={password}
          />
        </View>
        {/* <Button
          containerStyle={styles.loginContainer}
          style={styles.loginText}
          onPress={() => onPressLogin()}
        >
          {IMLocalized('Log In')}
        </Button> */}
        {/* <Text style={styles.orTextStyle}> {IMLocalized('OR')}</Text> */}
        {/* <Button
          containerStyle={styles.facebookContainer}
          style={styles.facebookText}
          onPress={() => onFBButtonPress()}
        >
          {IMLocalized('Login With Facebook')}
        </Button>
        {appConfig.isSMSAuthEnabled && (
          <Button
            containerStyle={styles.phoneNumberContainer}
            onPress={() => props.navigation.goBack()}
          >
            {IMLocalized('Login with phone number')}
          </Button>
        )} */}

        <View>
          <LinearGradient
            colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
            style={styles.signupContainer}
          >
            <Button
              // containerStyle={styles.signupContainer}
              onPress={onPressLogin}
              style={styles.signupText}
            >
              {IMLocalized('Login')}
            </Button>
          </LinearGradient>
          <Button
            containerStyle={styles.signInContainer}
            onPress={onRegister}
            style={styles.signInText}
          >
            {IMLocalized('Sign Up')}
          </Button>
        </View>

        {loading && <TNActivityIndicator appStyles={appStyles} />}
      </KeyboardAwareScrollView>
    </View>
  );
}

export default connect(null, {
  setUserData,
})(LoginScreen);
