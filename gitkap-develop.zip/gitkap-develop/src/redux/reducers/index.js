import { combineReducers } from 'redux';
import { createNavigationReducer } from 'react-navigation-redux-helpers';
import { RootNavigator } from '../../navigators/AppNavigation';
import { app } from './app';
import { auth } from '../../Core/onboarding/redux/auth';
import deviceStorage from '../../Core/onboarding/utils/AuthDeviceStorage';

const LOG_OUT = 'LOG_OUT';

const navReducer = createNavigationReducer(RootNavigator);

// combine reducers to build the state
const appReducer = combineReducers({
  nav: navReducer,
  auth,
  app,
});

const rootReducer = (state, action) => {
  if (action.type === LOG_OUT) {
    deviceStorage.setShouldShowOnboardingFlow('false');
    state = undefined;
  }

  return appReducer(state, action);
};

export default rootReducer;
