import {Platform, StyleSheet, Dimensions, I18nManager} from 'react-native';
import {Configuration} from './Configuration';
import colors from './shared/colors';

const {width, height} = Dimensions.get('window');
const SCREEN_WIDTH = width < height ? width : height;
const numColumns = 1.5;

export const AppStyles = {
  color: {
    main: '#ff5a66',
    text: '#4b4f52',
    title: '#464646',
    subtitle: '#545454',
    categoryTitle: '#161616',
    tint: '#ff5a66',
    description: '#bbbbbb',
    filterTitle: '#8a8a8a',
    starRating: '#ff5a66',
    location: '#a9a9a9',
    white: 'white',
    facebook: '#4267b2',
    grey: 'grey',
    greenBlue: '#ff5a66',
    placeholder: '#a0a0a0',
    background: '#f2f2f2',
    blue: '#3293fe',
  },
  fontSize: {
    title: 30,
    content: 20,
    normal: 16,
  },
  buttonWidth: {
    main: '70%',
  },
  textInputWidth: {
    main: '80%',
  },
  fontName: {
    main: 'FontAwesome',
    bold: 'FontAwesome',
  },
  borderRadius: {
    main: 25,
    small: 5,
  },
  InputContainer: {
    height: 52,
    borderWidth: 1,
    borderColor: colors.lightGray,
    paddingLeft: 20,
    // color: AppStyles.colorSet.mainTextColor,
    width: '90%',
    alignSelf: 'center',
    // marginTop: 20,
    alignItems: 'center',
    textAlign: 'center',
    borderRadius: 5,
    // textAlign: I18nManager.isRTL ? 'right' : 'left',
  },
};

export const AppIcon = {
  container: {
    backgroundColor: 'white',
    borderRadius: 20,
    padding: 8,
    marginRight: 10,
  },
  containerMapBtn: {
    backgroundColor: 'white',
    borderRadius: 20,
    paddingLeft: 8,
    paddingRight: 8,
    marginRight: 10,
  },
  containerAddListingBtn: {
    backgroundColor: 'white',
    borderRadius: 20,
    paddingLeft: 8,
    paddingRight: 8,
  },
  style: {
    tintColor: AppStyles.color.tint,
    width: 25,
    height: 25,
  },
  images: {
    home: require('../assets/icons/home.png'),
    categories: require('../assets/icons/categories.png'),
    collections: require('../assets/icons/collections.png'),
    compose: require('../assets/icons/compose.png'),
    filter: require('../assets/icons/filter.png'),
    filters: require('../assets/icons/filters.png'),
    heart: require('../assets/icons/heart.png'),
    heartFilled: require('../assets/icons/heart-filled.png'),
    map: require('../assets/icons/map.png'),
    search: require('../assets/icons/search.png'),
    review: require('../assets/icons/review.png'),
    list: require('../assets/icons/list.png'),
    starFilled: require('../assets/icons/star_filled.png'),
    starNoFilled: require('../assets/icons/star_nofilled.png'),
    defaultUser: require('../assets/icons/default_user.jpg'),
    logout: require('../assets/icons/shutdown.png'),
    rightArrow: require('../assets/icons/right-arrow.png'),
    accountDetail: require('../assets/icons/account-detail.png'),
    wishlistFilled: require('../assets/icons/wishlist-filled.png'),
    orderDrawer: require('../assets/icons/order-drawer.png'),
    settings: require('../assets/icons/settings.png'),
    contactUs: require('../assets/icons/contact-us.png'),
    delete: require('../assets/icons/delete.png'),
    communication: require('../assets/icons/communication.png'),
    comment: require('../assets/icons/comment.png'),
    cameraFilled: require('../assets/icons/camera-filled.png'),
    send: require('../assets/icons/send.png'),
    boederImgSend: require('../assets/icons/borderImg1.png'),
    boederImgReceive: require('../assets/icons/borderImg2.png'),
    textBoederImgSend: require('../assets/icons/textBorderImg1.png'),
    textBoederImgReceive: require('../assets/icons/textBorderImg2.png'),
    emptyAvatar: require('../assets/icons/empty-avatar.jpg'),
    checklist: require('../assets/icons/checklist.png'),
  },
};

export const HeaderButtonStyle = StyleSheet.create({
  container: {
    padding: 10,
  },
  image: {
    height: 35,
    justifyContent: 'center',
    margin: 6,
    width: 35,
  },
  multi: {
    flexDirection: 'row',
  },
  rightButton: {
    color: AppStyles.color.tint,
    fontFamily: AppStyles.fontName.main,
    fontWeight: 'normal',
    marginRight: 10,
  },
});

export const ListStyle = StyleSheet.create({
  avatarStyle: {
    height: 80,
    width: 80,
  },
  leftSubtitle: {
    flex: 2,
  },
  place: {
    color: AppStyles.color.location,
    fontWeight: 'bold',
  },
  price: {
    alignSelf: 'flex-end',
    color: AppStyles.color.subtitle,
    flex: 1,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 14,
    textAlign: 'right',
    textAlignVertical: 'bottom',
  },
  subtitleView: {
    flexDirection: 'row',
    marginLeft: 10,
    minHeight: 55,
    paddingTop: 5,
  },
  time: {
    color: AppStyles.color.description,
    flex: 1,
    fontFamily: AppStyles.fontName.main,
    textAlignVertical: 'bottom',
  },
  title: {
    color: AppStyles.color.subtitle,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export const TwoColumnListStyle = {
  listings: {
    marginTop: 15,
    width: '100%',
    flex: 1,
  },
  showAllButtonContainer: {
    borderWidth: 1,
    borderRadius: 5,
    borderColor: AppStyles.color.greenBlue,
    height: 50,
    width: '100%',
    marginBottom: 30,
  },
  showAllButtonText: {
    padding: 10,
    textAlign: 'center',
    color: AppStyles.color.greenBlue,
    fontFamily: AppStyles.fontName.bold,
    justifyContent: 'center',
  },
  listingItemContainer: {
    justifyContent: 'center',
    marginBottom: 30,
    marginRight: Configuration.home.listing_item.offset,
    width:
      (SCREEN_WIDTH - Configuration.home.listing_item.offset * 3) / numColumns,
  },
  photo: {
    // position: "absolute",
  },
  listingPhoto: {
    width:
      (SCREEN_WIDTH - Configuration.home.listing_item.offset * 3) / numColumns,
    height: Configuration.home.listing_item.height,
  },
  savedIcon: {
    position: 'absolute',
    top: Configuration.home.listing_item.saved.position_top,
    left:
      (SCREEN_WIDTH - Configuration.home.listing_item.offset * 3) / numColumns -
      Configuration.home.listing_item.offset -
      Configuration.home.listing_item.saved.size,
    width: Configuration.home.listing_item.saved.size,
    height: Configuration.home.listing_item.saved.size,
  },
  listingName: {
    fontSize: 15,
    fontFamily: AppStyles.fontName.bold,
    fontWeight: 'bold',
    color: AppStyles.color.categoryTitle,
    marginTop: 5,
  },
  listingPlace: {
    fontFamily: AppStyles.fontName.bold,
    color: AppStyles.color.subtitle,
    marginTop: 5,
  },
};

export const ModalSelectorStyle = {
  optionTextStyle: {
    color: AppStyles.color.subtitle,
    fontSize: 16,
    fontFamily: AppStyles.fontName.main,
  },
  selectedItemTextStyle: {
    fontSize: 18,
    color: AppStyles.color.blue,
    fontFamily: AppStyles.fontName.main,
    fontWeight: 'bold',
  },
  optionContainerStyle: {
    backgroundColor: AppStyles.color.white,
  },
  cancelContainerStyle: {
    backgroundColor: AppStyles.color.white,
    borderRadius: 10,
  },
  sectionTextStyle: {
    fontSize: 21,
    color: AppStyles.color.title,
    fontFamily: AppStyles.fontName.main,
    fontWeight: 'bold',
  },

  cancelTextStyle: {
    fontSize: 21,
    color: AppStyles.color.blue,
    fontFamily: AppStyles.fontName.main,
  },
};

export const ModalHeaderStyle = {
  bar: {
    height: 50,
    marginTop: Platform.OS === 'ios' ? 30 : 0,
    justifyContent: 'center',
  },
  title: {
    position: 'absolute',
    textAlign: 'center',
    width: '100%',
    fontWeight: 'bold',
    fontSize: 20,
    color: 'black',
    fontFamily: AppStyles.fontName.main,
  },
  rightButton: {
    top: 0,
    right: 0,
    backgroundColor: 'transparent',
    alignSelf: 'flex-end',
    color: AppStyles.color.tint,
    fontWeight: 'normal',
    fontFamily: AppStyles.fontName.main,
  },
};
