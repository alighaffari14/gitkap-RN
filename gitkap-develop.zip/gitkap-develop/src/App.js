import React, { Component } from 'react';
import { YellowBox } from 'react-native';
import { Provider } from 'react-redux';
import { initialMode, eventEmitter } from 'react-native-dark-mode';
import SplashScreen from 'react-native-splash-screen';
import configureStore from './redux/store';
import AppContainer from './screens/AppContainer';

const store = configureStore();
export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      mode: initialMode,
    };
  }

  componentDidMount() {
    SplashScreen.hide();
    YellowBox.ignoreWarnings(['Remote Debugger']);
    // console.disableYellowBox = true;

    eventEmitter.on('currentModeChanged', mode => {
      this.setState({ mode });
    });
  }

  render() {
    return (
      <Provider store={store}>
        <AppContainer screenProps={{ theme: this.state.mode }} />
      </Provider>
    );
  }
}

