import React from 'react';
import { Animated, Easing, Image, StyleSheet } from 'react-native';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { createSwitchNavigator } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import { createBottomTabNavigator } from 'react-navigation-tabs';
import HomeScreen from '../screens/home/HomeScreen';
import AdminDashboardScreen from '../screens/AdminDashboardScreen';
import CategoryScreen from '../screens/CategoryScreen';
import DetailScreen from '../screens/detail/DetailScreen';
import ListingScreen from '../screens/ListingScreen';
import MapScreen from '../screens/MapScreen';
import SavedListingScreen from '../screens/SavedListingScreen';
import MessageScreen from '../screens/MessageScreen';
import SearchScreen from '../screens/SearchScreen';
import PersonalMessageScreen from '../screens/PersonalMessageScreen';
import DynamicAppStyles from '../DynamicAppStyles';
import {
  LoadScreen,
  WalkthroughScreen,
  LoginScreen,
  WelcomeScreen,
  SignupScreen,
  SmsAuthenticationScreen,
} from '../Core/onboarding';
import DrawerContainer from '../components/DrawerContainer';
import ProfileModal from '../components/ProfileModal';
import MyListingModal from '../components/MyListingModal';
import ContactModal from '../components/ContactModal';
import AccountDetailModal from '../components/AccountDetailModal';
import SettingsModal from '../components/SettingsModal';
import ListingProfileModal from '../components/ListingProfileModal';
import ListingAppConfig from '../ListingAppConfig';
import { tabBarBuilder } from '../Core/ui';
import SearchLocationScreen from '../screens/searchLocation/SearchLocationScreen';
import MapScreenLocationFinder from '../../src/screens/map/MapScreen';

const noTransitionConfig = () => ({
  transitionSpec: {
    duration: 0,
    timing: Animated.timing,
    easing: Easing.step0,
  },
});

// login stack
const LoginStack = createStackNavigator(
  {
    Welcome: {
      screen: WelcomeScreen,
      navigationOptions: { header: null },
    },
    search: {
      screen: SearchLocationScreen,
      navigationOptions: () => ({
        headerStyle: authScreensStyles.headerStyle,
      }),
    },
    mapLocationFinder: {
      screen: MapScreenLocationFinder,
      navigationOptions: () => ({
        headerStyle: authScreensStyles.headerStyle,
      }),
    },
    Login: {
      screen: LoginScreen,
      navigationOptions: () => ({
        headerStyle: authScreensStyles.headerStyle,
      }),
    },
    Signup: {
      screen: SignupScreen,
      navigationOptions: () => ({
        headerStyle: authScreensStyles.headerStyle,
      }),
    },
    Sms: {
      screen: SmsAuthenticationScreen,
      navigationOptions: () => ({
        headerStyle: authScreensStyles.headerStyle,
      }),
    },
  },
  {
    initialRouteName: 'Login',
    initialRouteParams: {
      appStyles: DynamicAppStyles,
      appConfig: ListingAppConfig,
    },
    headerMode: 'float',
    headerBackTitleVisible: false,
    cardStyle: { backgroundColor: '#FFFFFF' },
    cardShadowEnabled: false,
  }
);

const DetailStack = createStackNavigator(
  {
    Detail: { screen: DetailScreen },
    ListingProfileModal: { screen: ListingProfileModal },
    DetailModal: { screen: DetailScreen },
  },
  {
    mode: 'modal',
    headerMode: 'float',
    // headerLayoutPreset: "center",
    // navigationOptions: ({ navigation }) => ({
    //   headerTintColor: "#21c064",
    //   headerTitleStyle: styles.headerTitleStyle
    // }),
    // cardStyle: { backgroundColor: "#FFFFFF" }
  }
);

const MainHomeStack = createStackNavigator(
  {
    Home: { screen: HomeScreen },
    Listing: { screen: ListingScreen },
    Detail: {
      screen: DetailScreen,
      navigationOptions: {
        header: null,
      },
    },
    findMap: { screen: MapScreenLocationFinder },
    Map: { screen: MapScreen },
  },
  {
    // initialRouteName: "Home",
    headerMode: 'float',
    headerLayoutPreset: 'center',
    navigationOptions: ({ navigation }) => ({
      headerTintColor: '#ff5a66',
      headerTitleStyle: styles.headerTitleStyle,
    }),
    cardStyle: { backgroundColor: '#FFFFFF' },
  }
);

const HomeStack = createStackNavigator(
  {
    Home: {
      screen: MainHomeStack,
      navigationOptions: { header: null },
    },
    ProfileModal: { screen: ProfileModal },
    MyListingModal: { screen: MyListingModal },
    SavedListingModal: { screen: SavedListingScreen },
    MyListingDetailModal: { screen: DetailScreen },
    Contact: { screen: ContactModal },
    Settings: { screen: SettingsModal },
    AdminDashboard: { screen: AdminDashboardScreen },
    AccountDetail: { screen: AccountDetailModal },
  },
  {
    mode: 'modal',
    headerMode: 'float',
    // headerLayoutPreset: "center",
    // navigationOptions: ({ navigation }) => ({
    //   headerTintColor: "#21c064",
    //   headerTitleStyle: styles.headerTitleStyle
    // }),
    // cardStyle: { backgroundColor: "#FFFFFF" }
  }
);

const CollectionStack = createStackNavigator(
  {
    Category: { screen: CategoryScreen },
    Listing: { screen: ListingScreen },
    Detail: {
      screen: DetailStack,
      navigationOptions: {
        header: null,
      },
    },
    Map: { screen: MapScreen },
  },
  {
    initialRouteName: 'Category',
    headerMode: 'float',
    headerLayoutPreset: 'center',
    cardStyle: { backgroundColor: '#FFFFFF' },
    navigationOptions: ({ navigation }) => ({
      headerTintColor: '#ff5a66',
      headerTitleStyle: styles.headerTitleStyle,
    }),
  }
);

const MessageStack = createStackNavigator(
  {
    Message: { screen: MessageScreen },
  },
  {
    initialRouteName: 'Message',
    headerMode: 'float',
    headerLayoutPreset: 'center',
    cardStyle: { backgroundColor: '#FFFFFF' },
    navigationOptions: ({ navigation }) => ({
      headerTintColor: '#ff5a66',
      headerTitleStyle: styles.headerTitleStyle,
    }),
  }
);

const SearchStack = createStackNavigator(
  {
    Search: { screen: SearchScreen },
    SearchDetail: {
      screen: DetailStack,
      navigationOptions: {
        header: null,
      },
    },
    Map: { screen: MapScreen },
  },
  {
    initialRouteName: 'Search',
    headerMode: 'float',
    headerLayoutPreset: 'center',
    cardStyle: { backgroundColor: '#FFFFFF' },
    navigationOptions: ({ navigation }) => ({
      headerTintColor: '#ff5a66',
      headerTitleStyle: styles.headerTitleStyle,
    }),
  }
);

const TabNavigator = createBottomTabNavigator(
  {
    Home: { screen: HomeStack },
    Categories: { screen: CollectionStack },
    Messages: { screen: MessageStack },
    Search: { screen: SearchStack },
  },
  {
    initialRouteName: 'Home',
    tabBarComponent: tabBarBuilder(ListingAppConfig.tabIcons, DynamicAppStyles),
    navigationOptions: ({ navigation }) => {
      const { routeName } = navigation.state.routes[navigation.state.index];

      return {
        headerTitle: routeName,
        header: null,
      };
    },
  }
);

// drawer stack
const DrawerStack = createDrawerNavigator(
  {
    Tab: TabNavigator,
  },
  {
    drawerPosition: 'left',
    initialRouteName: 'Tab',
    drawerWidth: 300,
    contentComponent: DrawerContainer,
    headerMode: 'screen',
    navigationOptions: ({ navigation }) => {
      const routeIndex = navigation.state.index;

      return {
        title: navigation.state.routes[routeIndex].key,
        header: null,
      };
    },
  }
);

// // Manifest of possible screens
// const RootNavigator = createStackNavigator(
//   {
//     LoginStack: {
//       screen: LoginStack,
//       navigationOptions: { header: null }
//     },
//     DrawerStack: {
//       screen: DrawerStack,
//       navigationOptions: { header: null }
//     },
//     PersonalMessage: {screen: PersonalMessageScreen}
//   },
//   {
//     // Default config for all screens
//     headerMode: "float",
//     initialRouteName: "DrawerStack",
//     transitionConfig: noTransitionConfig,
//     navigationOptions: ({ navigation }) => ({
//       headerTintColor: "#21c064",
//       headerTitleStyle: styles.headerTitleStyle
//     })
//   }
// );

export const MainNavigator = createStackNavigator(
  {
    DrawerStack: {
      screen: DrawerStack,
      navigationOptions: { header: null },
    },
    PersonalMessage: { screen: PersonalMessageScreen },
  },
  {
    // Default config for all screens
    headerMode: 'float',
    initialRouteName: 'DrawerStack',
    transitionConfig: noTransitionConfig,
    navigationOptions: ({ navigation }) => ({
      headerTintColor: '#ff5a66',
      headerTitleStyle: styles.headerTitleStyle,
    }),
  }
);

const RootNavigator = createSwitchNavigator(
  {
    LoadScreen: LoadScreen,
    Walkthrough: WalkthroughScreen,
    LoginStack: LoginStack,
    MainStack: MainNavigator,
  },
  {
    initialRouteName: 'LoadScreen',
    initialRouteParams: {
      appStyles: DynamicAppStyles,
      appConfig: ListingAppConfig,
    },
    cardStyle: {
      backgroundColor: DynamicAppStyles.colorSet.mainThemeBackgroundColor,
    },
    // navigationOptions: ({ _navigation }) => ({
    //   headerTintColor: '#21c064',
    //   headerTitleStyle: styles.headerTitleStyle
    // })
  }
);

const styles = StyleSheet.create({
  headerTitleStyle: {
    alignSelf: 'center',
    color: 'black',
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
  },

});

const authScreensStyles = StyleSheet.create({
  headerStyle: {
    borderBottomWidth: 0,
    elevation: 0,
    shadowColor: 'transparent',
    shadowOpacity: 0, // remove shadow on Android
  },
});

export { RootNavigator };
