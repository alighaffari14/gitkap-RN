export const INDIVIDUAL = 'Individual';
export const BUSINESS = 'Business';