export default {
  radius: {
    medium: 40,
  },
  fonts: {
    small: 18,
    xSmall: 16,
  },
  borderRadius: {
    medium: 35,
    small: 30,
  },
  /**
               * Paddings
               * @type {Object}
               */
  padding: {
    default: {
      horizontal: 16,
      vertical: 16,
    },
    primary: {
      horizontal: 10,
      vertical: 10,
    },
    defaultButton: {
      horizontal: 10,
      vertical: 5,
    },
    actionBar: {
      horizontal: 10,
      vertical: 20,
    },
  },
};
