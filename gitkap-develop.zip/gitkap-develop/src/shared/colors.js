export default {
  darkOrange: '#ED4F36',
  xDarkOrange: '#F98F6C',
  lightOrange: '#FFAD92',
  xOrange: '#FAB9A4',
  xLightOrange: '#F8D8CD',
  veryLightOrange: '#E5E5E5',
  lightPurple: '#323758',

  white: '#ffffff',
  gray: '#AFB0BC',
  lightGray: '#E8E8E8',
  xlightGray: '#C9C9C9',
  black: 'black',

  lightGreen: '#7BF4AF',
};
