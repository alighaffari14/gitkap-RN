// @flow
import {StyleSheet} from 'react-native';
import colors from '../../shared/colors';
import metrics from '../../shared/metrics';

const tag = {
  backgroundColor: colors.white,
  borderRadius: 5,
  paddingHorizontal: 5,
  paddingVertical: 2,
  paddingBottom: 4,
  position: 'absolute',
};

const style = StyleSheet.create({
  container: {
    flex: 1,
  },
  distance: {
    ...tag,
    bottom: 15,
    right: 30,
  },
  favMarker: {
    position: 'absolute',
    right: 20,
    top: 20,
  },
  favMarkerIcon: {
    height: 35,
    width: 35,
  },
  listingPhoto: {
    borderTopLeftRadius: metrics.borderRadius.medium,
    borderTopRightRadius: metrics.borderRadius.medium,
    height: 180,
  },
  openStatus: {
    ...tag,
    bottom: 15,
    left: 30,
  },
  textCloseStatus: {
    color: colors.darkOrange,
    fontWeight: 'bold',
  },
  textDistance: {
    fontWeight: 'bold',
  },
  textOpenStatus: {
    color: colors.lightGreen,
    fontWeight: 'bold',
  },
});

export default style;
