// @flow
import React from 'react';
import {View, Text, Image, TouchableOpacity} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';
import FastImage from 'react-native-fast-image';

import styles from './GeneralOfferImage.styles';

const marker = require('../../../assets/icons/marker.png');
const unMarker = require('../../../assets/icons/Unmarker.png');

type GeneralOfferImageProps = {};
type GeneralOfferImageState = {};

const DISTANCE = 'DISTANCE';
const OPEN_STATUS = 'OPEN_STATUS';

class GeneralOfferImageComponent extends React.PureComponent<GeneralOfferImageProps, GeneralOfferImageState> {
  static defaultProps: any

  constructor(props: GeneralOfferImageProps) {
    super(props);
  }

  async componentDidUpdate(prevProps) {

  }

  handleFavEnable = () => {
    const {onFavEnable} = this.props;
    onFavEnable();
  }

  renderTag = (type, text) => {
    let styleWrapper = null;
    let textStyle = null;

    if (type == DISTANCE) {
      styleWrapper = styles.distance;
      textStyle = styles.textDistance;
    } else {
      styleWrapper = styles.openStatus;
      textStyle = text == 'Close' ? styles.textCloseStatus : styles.textOpenStatus;
    }
    // textStyle = OPEN_STATUS && text == 'Close' ? styles.textCloseStatus : styles.textOpenStatus;

    return (
      <View style={styleWrapper}>
        <Text style={textStyle}>{text}</Text>
      </View>
    );
  }

  renderCheckedFavMarker = () => {
    return (
      <Image
        source={marker}
        style={styles.favMarkerIcon}
      />
    );
  }

  renderUnCheckedMarker = () => {
    return (
      <Image
        source={unMarker}
        style={styles.favMarkerIcon}
      />
    );
  }

  renderFavMarker = () => {
    const {favEnable} = this.props;
    const marker = favEnable ? this.renderCheckedFavMarker() : this.renderUnCheckedMarker();

    return (
      <TouchableOpacity
        onPress={this.handleFavEnable}
        style={styles.favMarker}
      >
        {marker}
      </TouchableOpacity>
    );
  }

  renderContent = (): ReactElement<any> => {
    const {item} = this.props;
    const distanceTag = this.renderTag(DISTANCE, `${item.distance && item.distance.toFixed(2)} Km`);
    const isOpened = item.active ? 'Open' : 'Close';

    const openStatus = this.renderTag(OPEN_STATUS, isOpened);
    const favMarker = this.renderFavMarker();

    const image = item.cover_photo ? (
      <FastImage
        source={{uri: item.cover_photo}}
        style={styles.listingPhoto}
      />
    ) : null;

    return (
      <View style={styles.container}>
        {image}
        {favMarker}
        {distanceTag}
        {openStatus}
      </View >
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

GeneralOfferImageComponent.propTypes = {
  favEnable: PropTypes.bool.isRequired,
  item: PropTypes.any.isRequired,
  onFavEnable: PropTypes.func.isRequired,
};

GeneralOfferImageComponent.defaultProps = {
};

export default GeneralOfferImageComponent;
