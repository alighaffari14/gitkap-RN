// @flow
import React from 'react';
import {View, Text, Image} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';

import {mapStyle} from '../../shared/base';

import styles from './MapView.styles';
import SearchLocationComponent from '../searchLocation/SearchLocation.component';
import colors from '../../shared/colors';

type MapViewProps = {};
type MapViewState = {};

const navigateImage = require('../../../assets/icons/navigate.png');

class MapViewComponent extends React.PureComponent<MapViewProps, MapViewState> {
  static defaultProps: any

  constructor(props: MapViewProps) {
    super(props);
  }

  renderXXCricle = () => {
    return (
      <View style={{backgroundColor: colors.xLightOrange, width: 40, height: 40, borderRadius: 20, position: 'absolute', top: 0, left: 0}} />
    );
  }

  renderXCricle = () => {
    return (
      <View style={{backgroundColor: colors.xOrange, width: 32, height: 32, borderRadius: 16, position: 'absolute', top: 4, left: 4}} />
    );
  }

  renderCricle = () => {
    return (
      <View style={{backgroundColor: colors.xDarkOrange, width: 24, height: 24, borderRadius: 12, position: 'absolute', top: 8, left: 8}} />
    );
  }

  renderInnerCricle = () => {
    return (
      <View style={{backgroundColor: colors.darkOrange, width: 12, height: 12, borderRadius: 6, position: 'absolute', top: 14, left: 14}} />
    );
  }

  onSelect = (locationObject) => {
  }

  renderContent = (): ReactElement<any> => {
    const {region, formatted_address} = this.props;

    return (
      <View style={styles.container}>
        <MapView
          customMapStyle={mapStyle}
          provider={PROVIDER_GOOGLE}
          region={region}
          showsMyLocationButton
          style={styles.mapView}
        >
          <Marker
            coordinate={region}
            description={formatted_address}
            draggable
            onDrag={this.onSelect}
            onMarkerPress={this.onSelect}
            onPress={() => console.log('Marker pressed')}
            title="Location"

            // onCalloutPress={() => {
            //     this.onPress(listing);
            // }}
            tracksViewChanges={false}
          >
            <Image
              source={navigateImage}
            />
            {this.renderXXCricle()}
            {this.renderXCricle()}
            {this.renderCricle()}
            {this.renderInnerCricle()}
          </Marker>
        </MapView>
      </View>
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

MapViewComponent.propTypes = {};

MapViewComponent.defaultProps = {};

export default MapViewComponent;
