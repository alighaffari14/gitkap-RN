import React from 'react';
import {
  StyleSheet,
  Text,
  Modal,
  View,
  TextInput,
  TouchableOpacity,
  BackHandler,
} from 'react-native';
import firebase from 'react-native-firebase';
import { KeyboardAwareView } from 'react-native-keyboard-aware-view';
import { connect } from 'react-redux';
import TextButton from 'react-native-button';
import { AppStyles } from '../AppStyles';
import ServerConfiguration from '../ServerConfiguration';
import { setUserData } from '../Core/onboarding/redux/auth';
import authDeviceStorage from '../Core/onboarding/utils/AuthDeviceStorage';
const regexForNames = /^[a-zA-Z]{2,25}$/;
const regexForPhoneNumber = /\d{9}$/;

class AccountDetailModal extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Account Details',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={styles.rightButton}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);

    console.log("User:", props.user)

    this.state = {
      email: props.user && props.user.email,
      firstName: props.user && props.user.firstName,
      lastName: props.user && props.user.lastName,
      phoneNumber: props.user && props.user.phoneNumber,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    this.userRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.USERS);
  }

  componentDidMount() {
    this.updateUserDetails();
    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  updateUserDetails = () => {
    const { user } = this.props;

    this.setState({
      email: user && user.email,
      firstName: user && user.firstName,
      lastName: user && user.lastName,
      phoneNumber: user && user.phoneNumber,
      aboutResturant: user && user.aboutResturant
    });
  };

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  isInvalid = (value, regex) => {
    const regexResult = regex.test(value);

    if (value.length > 0 && !regexResult) {
      return true;
    }
    if (value.length > 0 && regexResult) {
      return false;
    }
  };

  onSave = () => {
    const self = this;

    const isFitstNameInvalid = this.isInvalid(
      self.state.firstName,
      regexForNames
    );

    const isLastNameInvalid = this.isInvalid(
      self.state.lastName,
      regexForNames
    );

    const isPhoneNumberValid = this.isInvalid(
      self.state.phoneNumber,
      regexForPhoneNumber
    );



    if (!isFitstNameInvalid && !isLastNameInvalid && !isPhoneNumberValid) {
      const updatedData = {
        firstName: self.state.firstName,
        lastName: self.state.lastName,
        phoneNumber: self.state.phoneNumber,
        fullname: self.state.firstName,
        aboutResturant: self.state.aboutResturant
      };
      self.userRef
        .doc(this.props.user.id)
        .update(updatedData)
        .then(() => {

          let user = { ...self.props.user, ...updatedData }
          console.log("New User: ", JSON.stringify(user));

          authDeviceStorage.setUserData({ user: user })
          this.props.setUserData({ user: user })

          self.props.navigation.dispatch({
            type: 'UPDATE_USER_DATA',
            user: { ...self.props.user, ...updatedData },
          });
          self.props.navigation.goBack();
        });
    } else {
      alert(
        'An error occured while trying to update your account. Please make sure all fields are valid.'
      );
    }
  };

  onChangeFirstName = (text) => {
    this.setState({
      firstName: text,
    });
  };

  onChangeLastName = (text) => {
    this.setState({
      lastName: text,
    });
  };

  onChangePhoneNumber = (text) => {
    this.setState({
      phoneNumber: text,
    });
  };

  render() {
    return (
      <KeyboardAwareView style={styles.container}>
        <View style={styles.settingsTitleContainer}>
          <Text style={styles.settingsTitle}>PUBLIC PROFILE</Text>
        </View>
        <View style={styles.contentContainer}>
          <View
            style={[
              styles.settingsTypeContainer,
              styles.appSettingsTypeContainer,
            ]}
          >
            <Text style={styles.text}>First Name</Text>
            <TextInput
              editable
              onChangeText={this.onChangeFirstName}
              placeholder="Your first name"
              placeholderTextColor={styles.placeholderTextColor}
              style={[styles.text, { textAlign: 'right' }]}
              underlineColorAndroid="transparent"
              value={this.state.firstName}
            />
          </View>
          <View style={styles.divider} />
          <View
            style={[
              styles.settingsTypeContainer,
              styles.appSettingsTypeContainer,
            ]}
          >
            <Text style={styles.text}>Last Name</Text>
            <TextInput
              editable
              onChangeText={this.onChangeLastName}
              placeholder="Your last name"
              placeholderTextColor={styles.placeholderTextColor}
              style={[styles.text, { textAlign: 'right' }]}
              underlineColorAndroid="transparent"
              value={this.state.lastName}
            />
          </View>
        </View>
        <View style={styles.settingsTitleContainer}>
          <Text style={styles.settingsTitle}>PRIVATE DETAILS</Text>
        </View>
        <View style={styles.contentContainer}>
          <View
            style={[
              styles.settingsTypeContainer,
              styles.appSettingsTypeContainer,
            ]}
          >
            <Text style={styles.text}>E-mail Address</Text>
            <TextInput
              editable={false}
              placeholder="Your email"
              placeholderTextColor={styles.placeholderTextColor}
              style={styles.text}
              value={this.state.email}
            />
          </View>
          <View
            style={[
              styles.settingsTypeContainer,
              styles.appSettingsTypeContainer,
            ]}
          >
            <Text style={styles.text}>About Resturant</Text>
            <TextInput
              placeholder="About Resturant"
              placeholderTextColor={styles.placeholderTextColor}
              style={styles.text}
              onChangeText={(text) => this.setState({ aboutResturant: text })}
              value={this.state.aboutResturant}
            />
          </View>
          <View style={styles.divider} />
          <View
            style={[
              styles.settingsTypeContainer,
              styles.appSettingsTypeContainer,
            ]}
          >
            <Text style={styles.text}>Phone Number</Text>
            <TextInput
              editable
              onChangeText={this.onChangePhoneNumber}
              placeholder="Your phone number"
              placeholderTextColor={styles.placeholderTextColor}
              style={[styles.text, { textAlign: 'right' }]}
              underlineColorAndroid="transparent"
              value={this.state.phoneNumber}
            />
          </View>
        </View>
        <TouchableOpacity
          onPress={this.onSave}
          style={[
            styles.settingsTypeContainer,
            styles.appSettingsSaveContainer,
          ]}
        >
          <Text style={styles.settingsType}>Save</Text>
        </TouchableOpacity>
      </KeyboardAwareView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#efeff4',
    flex: 1,
  },
  rightButton: {
    color: AppStyles.color.main,
    marginRight: 10,
  },
  // Profile Settings
  settingsTitleContainer: {
    height: 55,
    justifyContent: 'flex-end',
    width: '100%',
  },
  settingsTitle: {
    color: AppStyles.color.text,
    fontSize: 14,
    fontWeight: '500',
    paddingBottom: 6,
    paddingLeft: 10,
  },
  settingsTypeContainer: {
    alignItems: 'center',
    borderBottomColor: '#f5f5f5',
    borderBottomWidth: 1,
    height: 50,
    justifyContent: 'center',
  },
  settingsType: {
    color: AppStyles.color.main,
    fontSize: 14,
    fontWeight: '500',
  },

  // Edit Profile
  contentContainer: {
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderColor: '#e0e0e0',
    borderTopWidth: 1,
    width: '100%',
  },
  divider: {
    alignSelf: 'flex-end',
    backgroundColor: '#e0e0e0',
    height: 0.5,
    width: '96%',
  },
  text: {
    color: AppStyles.color.text,
    fontSize: 14,
  },

  // app Settings
  appSettingsTypeContainer: {
    borderBottomWidth: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
  },
  appSettingsSaveContainer: {
    backgroundColor: '#ffffff',
    height: 45,
    marginTop: 50,
  },
  placeholderTextColor: { color: '#e0e0e0' },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps, { setUserData })(AccountDetailModal);
