import TopActionBar from './topActionBar/TopActionBar.component';
import SearchLocationComponent from './searchLocation/SearchLocation.component';
import MapViewComponent from './mapView/MapView.component';
import GeneralOfferItemComponent from './generalOfferItem/GeneralOfferItems';
import GeneralOfferImageComponent from './generalOfferImage/GeneralOfferImage.component';
import GeneralOfferDescriptionComponent from './generalOfferDescription/generalOfferDescription.component';

export default {
  TopActionBar,
  SearchLocationComponent,
  MapViewComponent,
  GeneralOfferItemComponent,
  GeneralOfferImageComponent,
  GeneralOfferDescriptionComponent,
};
