// @flow
import {StyleSheet} from 'react-native';
import colors from '../../shared/colors';
import metrics from '../../shared/metrics';
import {AppStyles} from '../../AppStyles';

const style = StyleSheet.create({
  bottomInfoText: {
    color: colors.gray,
  },
  container: {
    borderBottomLeftRadius: metrics.borderRadius.medium,
    borderBottomRightRadius: metrics.borderRadius.medium,
    borderColor: colors.lightGray,
    borderWidth: 1,
    flex: 1,
    justifyContent: 'center',
    paddingLeft: 15,
    paddingTop: 5,
  },
  discountInnerWrapper: {
    alignItems: 'flex-end',
    flexDirection: 'row',
  },
  discountWrapper: {
    position: 'absolute',
    right: 34,
    top: 30,
  },
  infoText: {
    color: colors.gray,
    fontFamily: AppStyles.fontName.bold,
    marginTop: 5,
  },
  itemNameText: {
    fontSize: 22, marginBottom: 10, maxHeight: 40,
  },
  lookContainer: {
    borderBottomRightRadius: metrics.borderRadius.medium,
    borderTopLeftRadius: metrics.borderRadius.medium,
    bottom: 0,
    height: 49,
    padding: 10,
    position: 'absolute',
    right: 0,
    width: 148,
  },
  lookText: {
    color: colors.white,
    fontSize: metrics.fonts.small,
    textAlign: 'center',
  },
  offText: {
    color: colors.darkOrange,
    paddingLeft: 6,
  },
  offerPercent: {
    color: colors.darkOrange,
    fontSize: 22,
    fontWeight: 'bold',
  },
  orderWrapper: {
    flexDirection: 'row',
    paddingBottom: 30,
  },
  star: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  start: {
    height: 15,
    width: 15,
  },
  upperInfoWrapper: {
    flexDirection: 'row',
  },
});

export default style;
