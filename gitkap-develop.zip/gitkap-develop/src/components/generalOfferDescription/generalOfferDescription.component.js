// @flow
import React from 'react';
import { View, Text, Image } from 'react-native';
import PropTypes from 'prop-types';
import type { Element as ReactElement } from 'react';
import LinearGradient from 'react-native-linear-gradient';
import Button from 'react-native-button';

import styles from './generalOfferDescription.styles';
import colors from '../../shared/colors';

const star = require('../../../assets/icons/star.png');

type GeneralOfferDescriptionProps = {};
type GeneralOfferDescriptionState = {};

const LOOK = 'Look';
class GeneralOfferDescriptionComponent extends React.PureComponent<GeneralOfferDescriptionProps, GeneralOfferDescriptionState> {
  static defaultProps: any

  constructor(props: GeneralOfferDescriptionProps) {
    super(props);
  }

  handleLook = () => {
    const { pressListingItem, item } = this.props;
    pressListingItem(item);
  }

  rederDiscountText = () => {
    const { item } = this.props;
    // console.log('item', item);
    const formattedPrice = `${item.price && item.price.replace(/\D+/g, '') * (item.discountRate / 100)} `;

    return (
      <View style={styles.discountWrapper}>
        <View style={styles.discountInnerWrapper}>
          <Text style={styles.offerPercent}>₺{formattedPrice && Number(formattedPrice).toFixed(2)}</Text>
        </View>
      </View >
    );
  }

  renderLookButton = () => {
    return (
      <LinearGradient
        colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
        style={styles.lookContainer}
      >
        <Button
          containerStyle={styles.lookContainer}
          onPress={this.handleLook}
          style={styles.lookText}
        >
          <Text style={styles.lookText}>{LOOK}</Text>
        </Button>
      </LinearGradient>
    );
  }

  renderStarImage = () => {
    return (
      <View style={styles.star}>
        <Image
          source={star}
          style={styles.start}
        />
      </View>
    );
  }

  renderInfoTexts = () => {
    const { item } = this.props;
    const openClosedTime = `${item.startTimer} - ${item.finishTimer}`;

    return (
      <View>
        <View style={styles.upperInfoWrapper}>
          <Text style={styles.infoText}>{item.place}</Text>
          <Text style={styles.infoText}> | {item.rating}</Text>
          {this.renderStarImage()}
          <Text style={styles.infoText}> ({item.favEnableCount})</Text>
        </View>

        <Text style={styles.itemNameText}>
          {item.name}
        </Text>
        <View style={styles.orderWrapper}>
          <Text style={styles.bottomInfoText}>{item.num_of_oppot}+ Oppot...</Text>
          <Text style={styles.bottomInfoText}> | {openClosedTime}</Text>
        </View>
        {/* <Text style={TwoColumnListStyle.listingPlace}>{timeAgoText}</Text> */}
      </View>
    );
  }

  renderContent = (): ReactElement<any> => {
    return (
      <View style={styles.container}>
        {this.renderInfoTexts()}
        {this.rederDiscountText()}
        {this.renderLookButton()}
      </View>
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

GeneralOfferDescriptionComponent.propTypes = {
  item: PropTypes.any.isRequired,
  pressListingItem: PropTypes.any.isRequired,
};

GeneralOfferDescriptionComponent.defaultProps = {};

export default GeneralOfferDescriptionComponent;
