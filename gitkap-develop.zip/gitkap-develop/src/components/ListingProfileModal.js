import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {
  View,
  Text,
  ActivityIndicator,
  StyleSheet,
  BackHandler,
  ScrollView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import firebase from 'react-native-firebase';
import FastImage from 'react-native-fast-image';
import {connect} from 'react-redux';
import SavedButton from '../components/SavedButton';
import StarRating from 'react-native-star-rating';
import TextButton from 'react-native-button';
import ProfileImageCard from './ProfileImageCard';
import {AppStyles, AppIcon, TwoColumnListStyle} from '../AppStyles';
import ServerConfiguration from '../ServerConfiguration';
import {Configuration} from '../Configuration';

class ListingProfileModal extends Component {
  static navigationOptions = ({navigation}) => ({
    title: 'Profile',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={styles.rightButton}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);
    this.state = {
      user: null,
      listings: [],
      data: null,
      reviews: [],
      isListingDetailVisible: false,
      selectedItem: null,
      loading: true,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    const item = props.navigation.getParam('item');

    this.userRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.USERS);
    this.listingRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);
    this.userListingsRef = this.listingRef
      .where('user_id', '==', item.user_id)
      .where('is_approved', '==', true);
    this.reviewsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.REVIEWS);
    this.listingItemActionSheet = React.createRef();
    this.listingsUnsubscribe = null;
  }

  componentDidMount() {
    const self = this;
    const item = this.props.navigation.getParam('item');

    self.userRef
      .doc(item.user_id)
      .get()
      .then((doc) => {
        if (doc.data()) {
          self.setState({
            user: doc.data(),
            loading: false,
          });
        } else {
          this.onGetUserError();
        }
      });

    this.listingsUnsubscribe = this.userListingsRef.onSnapshot(
      this.onListingsCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  onGetUserError = () => {
    this.setState({loading: false}, () => {
      alert(
        '0ops! an error occured  while loading profile. This user profile may be incomplete.'
      );
      this.props.navigation.goBack();
    });
  };

  componentWillUnmount() {
    if (this.listingsUnsubscribe) {
      this.listingsUnsubscribe();
    }
    if (this.unsubscribe) {
      this.unsubscribe();
    }
    if (this.reviewsUnsubscribe) {
      this.reviewsUnsubscribe();
    }

    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onListingsCollectionUpdate = (querySnapshot) => {
    const listings = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();

      listings.push({...listing, id: doc.id});
    });

    this.setState({
      listings,
    });
  };

  onPressListingItem = (item) => {
    this.unsubscribe = this.listingRef
      .doc(item.id)
      .onSnapshot(this.onDocUpdate);
    this.reviewsUnsubscribe = this.reviewsRef
      .where('listing_id', '==', item.id)
      .onSnapshot(this.onReviewsUpdate);
  };

  updateReviews = (reviews) => {
    this.setState({
      reviews: reviews,
    });
  };

  onDocUpdate = (doc) => {
    const listing = doc.data();

    this.setState(
      {
        data: {...listing, id: doc.id},
        loading: false,
      },
      () => {
        this.props.navigation.navigate('DetailModal', {
          item: {...listing, id: doc.id},
        });
      }
    );
  };

  onReviewsUpdate = (querySnapshot) => {
    const data = [];
    const updateReviews = this.updateReviews;

    querySnapshot.forEach((doc) => {
      const review = doc.data();

      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.USERS)
        .doc(review.user_id)
        .get()
        .then(function(userDoc) {
          data.push({...review, id: doc.id, name: userDoc.data().fullname});
          updateReviews(data);
        });
    });
  };

  // onListingDetailCancel = () => {
  //   this.setState({
  //     isListingDetailVisible: false,
  //   })
  // }

  onPressSavedIcon = (item) => {
    if (item.saved) {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('listing_id', '==', item.id)
        .where('user_id', '==', this.props.user.id)
        .get()
        .then(function(querySnapshot) {
          querySnapshot.forEach(function(doc) {
            doc.ref.delete();
          });
        });
    } else {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .add({
          user_id: this.props.user.id,
          listing_id: item.id,
        })
        .then(function(docRef) { })
        .catch(function(error) {
          alert(error);
        });
    }
  };

  renderListingItem = ({item}) => {
    return (
      <TouchableOpacity onPress={() => this.onPressListingItem(item)}>
        <View style={TwoColumnListStyle.listingItemContainer}>
          <FastImage
            source={{uri: item.cover_photo}}
            style={TwoColumnListStyle.listingPhoto}
          />
          <SavedButton
            item={item}
            onPress={() => this.onPressSavedIcon(item)}
            style={TwoColumnListStyle.savedIcon}
          />
          <Text
numberOfLines={1}
            style={TwoColumnListStyle.listingName}
          >
            {item.name}
          </Text>
          <Text style={TwoColumnListStyle.listingPlace}>{item.place}</Text>
          <StarRating
            containerStyle={styles.starRatingContainer}
            disabled
            emptyStar={AppIcon.images.starNoFilled}
            fullStar={AppIcon.images.starFilled}
            maxStars={5}
            rating={item.starCount}
            starSize={15}
            starStyle={styles.starStyle}
          />
        </View>
      </TouchableOpacity>
    );
  };

  render() {
    const {user} = this.state;

    if (this.state.loading) {
      return <ActivityIndicator color={AppStyles.color.main}
size="small" />;
    }

    if (!this.state.loading && !this.state.user) {
      return null;
    }

    return (
      <View style={styles.container}>
        <ScrollView style={styles.container}>
          <View style={styles.profileCardContainer}>
            <ProfileImageCard
disabled
              user={user}
            />
          </View>
          <View style={styles.profileItemContainer}>
            <View style={styles.detailContainer}>
              <Text style={styles.profileInfo}>Profile Info</Text>
              <View style={styles.profileInfoContainer}>
                <View style={styles.profileInfoTitleContainer}>
                  <Text style={styles.profileInfoTitle}>
                    Phone Number :
                  </Text>
                </View>
                <View style={styles.profileInfoValueContainer}>
                  <Text style={styles.profileInfoValue}>
                    {user.phoneNumber ? user.phoneNumber : ''}
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.gridContainer}>
              <Text style={styles.myListings}>Listings</Text>
              <FlatList
                data={this.state.listings}
                keyExtractor={(item) => `${item.id}`}
                numColumns={2}
                renderItem={this.renderListingItem}
                showsVerticalScrollIndicator={false}
                vertical
              />
            </View>
          </View>
        </ScrollView>
      </View>
    );
  }
}

ListingProfileModal.propTypes = {
  user: PropTypes.object,
  onModal: PropTypes.func,
  isProfileModalVisible: PropTypes.bool,
  presentationStyle: PropTypes.string,
};

const itemIconSize = 26;
const itemNavigationIconSize = 23;

const styles = StyleSheet.create({
  blank: {
    flex: 0.5,
  },
  cardContainer: {
    flex: 1,
  },
  cardImage: {
    borderRadius: 65,
    height: 130,
    width: 130,
  },
  cardImageContainer: {
    alignItems: 'center',
    flex: 4,
    justifyContent: 'center',
  },
  cardName: {
    color: AppStyles.color.text,
    fontSize: 19,
  },
  cardNameContainer: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
  },
  container: {
    backgroundColor: '#ffff',
    flex: 1,
  },
  detailContainer: {
    backgroundColor: '#efeff4',
    marginTop: 25,
    padding: 20,
  },
  footerButtonContainer: {
    flex: 2,
    justifyContent: 'flex-start',
    marginTop: 8,
  },
  footerContainerStyle: {
    // borderColor: AppStyles.color.grey
  },
  gridContainer: {
    marginTop: 10,
    padding: Configuration.home.listing_item.offset,
  },
  itemContainer: {
    alignSelf: 'center',
    flexDirection: 'row',
    height: 54,
    marginBottom: 10,
    width: '85%',
  },
  itemIcon: {
    height: itemIconSize,
    width: itemIconSize,
  },
  itemIconContainer: {
    alignItems: 'center',
    flex: 0.5,
    justifyContent: 'center',
  },
  itemNavigationIcon: {
    height: itemNavigationIconSize,
    tintColor: AppStyles.color.grey,
    width: itemNavigationIconSize,
  },
  itemNavigationIconContainer: {
    alignItems: 'center',
    flex: 0.5,
    justifyContent: 'center',
  },
  itemTitle: {
    color: AppStyles.color.text,
    fontSize: 17,
    paddingLeft: 20,
  },
  itemTitleContainer: {
    alignItems: 'flex-start',
    flex: 6,
    justifyContent: 'center',
  },
  myListings: {
    color: '#333333',
    fontSize: 17,
    fontWeight: '500',
    paddingBottom: 20,
    paddingTop: 5,
  },
  profileCardContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 15,
  },
  profileInfo: {
    color: '#333333',
    fontSize: 14,
    padding: 5,
  },
  profileInfoContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 5,
    width: '100%',
  },
  profileInfoTitle: {
    color: '#595959',
    fontSize: 12,
    padding: 5,
  },
  profileInfoTitleContainer: {
    flex: 1,
    // alignItems: "center",
    // backgroundColor: "green",
    justifyContent: 'center',
  },
  profileInfoValue: {
    color: '#737373',
    fontSize: 12,
    padding: 5,
  },
  profileInfoValueContainer: {
    flex: 2,
    // alignItems: "center",
    // backgroundColor: "yellow",
    justifyContent: 'center',
  },
  profileItemContainer: {
    marginTop: 6,
  },
  rightButton: {
    color: AppStyles.color.main,
    marginRight: 10,
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(ListingProfileModal);
