// @flow
import React from 'react';
import { View, Text, Dimensions } from 'react-native';
import PropTypes from 'prop-types';
import type { Element as ReactElement } from 'react';
import Button from 'react-native-button';
import LinearGradient from 'react-native-linear-gradient';

import styles from './DiscountPanel.styles';
import colors from '../../shared/colors';

const { width: viewportWidth } = Dimensions.get('window');

type DiscountPanelProps = {};
type DiscountPanelState = {};

class DiscountPanelComponent extends React.PureComponent<DiscountPanelProps, DiscountPanelState> {
  static defaultProps: any

  constructor(props: DiscountPanelProps) {
    super(props);
  }

  handleLook = () => {
    this.props.onLook();
  }

  renderTitleHeader = () => {
    const { data } = this.props;
    const formattedPrice = `${data.price && data.price.replace(/\D+/g, '') * (data.discountRate / 100)} `;

    return (
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={{ fontSize: 18, fontWeight: 'bold' }}>{data && data.name}</Text>
        <Text style={{ fontSize: 18, fontWeight: 'bold', color: colors.darkOrange }}>₺{formattedPrice && Number(formattedPrice).toFixed(2)}</Text>
      </View>
    );
  }

  renderOrderInfo = () => {
    const { data } = this.props;

    return (
      <View style={{ flexDirection: 'row' }}>
        <Text style={{ color: colors.gray }}>{data.num_of_oppot}+ Fırsat | </Text>
        <Text style={{ color: colors.gray }}> {data && data.startTimer} - {data.finishTimer}</Text>
      </View>
    );
  }

  rendeDescription = () => {
    const { data } = this.props;

    return (
      <Text style={{ paddingVertical: 20, color: colors.gray }}>
        {data && data.description}
      </Text>
    );
  }

  renderActiveStatus = () => {
    const { data } = this.props;
    const status = !data.active ? 'Close' : 'Open';
    const color = status ? { color: 'red' } : null;

    return (
      <Text style={[{ color: colors.lightGreen }, color]}>{status}</Text>
    );
  }

  renderButtons = () => {
    return (
      <LinearGradient
        colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
        style={styles.lookContainer}
      >
        <Button
          containerStyle={styles.lookContainer}
          onPress={this.handleLook}
          style={styles.lookText}
        >
          <Text style={styles.lookText}>GET THE OFFER</Text>
        </Button>
      </LinearGradient>
    );
  }

  renderContent = (): ReactElement<any> => {
    return (
      <View style={styles.container}>
        <View style={styles.panelWrapper}>
          {this.renderTitleHeader()}
          {this.renderOrderInfo()}
          {this.rendeDescription()}
          {this.renderActiveStatus()}
          {this.renderButtons()}
        </View>
      </View>
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

DiscountPanelComponent.propTypes = {};

DiscountPanelComponent.defaultProps = {};

export default DiscountPanelComponent;
