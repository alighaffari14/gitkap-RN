// @flow
import {StyleSheet, Dimensions} from 'react-native';
import metrics from '../../shared/metrics';
import colors from '../../shared/colors';

const {width: viewportWidth} = Dimensions.get('window');

const style = StyleSheet.create({
  container: {
    alignItems: 'center',
    flex: 1,
  },
  lookContainer: {
    borderBottomRightRadius: metrics.borderRadius.small,
    borderTopLeftRadius: metrics.borderRadius.small,
    bottom: 0,
    height: 49,
    padding: 10,
    position: 'absolute',
    right: 0,
    width: 148,
  },
  lookText: {
    color: colors.white,
    fontSize: metrics.fonts.xSmall,
    textAlign: 'center',
  },
  panelWrapper: {
    backgroundColor: colors.white,
    borderRadius: 30,
    marginTop: -30,
    padding: 20,
    width: viewportWidth - 50,
  },
});

export default style;
