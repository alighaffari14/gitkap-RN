import React, {useState} from 'react';
import PropTypes from 'prop-types';
import FastImage from 'react-native-fast-image';
import {View, Text, StyleSheet, TouchableOpacity} from 'react-native';
import {AppStyles, AppIcon} from '../AppStyles';

const defaultAvatar =
  'https://www.iosapptemplates.com/wp-content/uploads/2019/06/empty-avatar.jpg';

function ProfileImageCard(props) {
  const {user, onImagePress, disabled} = props;
  const [imgErr, setImgErr] = useState(false);
  const lastName = user && user.lastName ? user.lastName : '';
  const firstName = user && user.firstName ? user && user.firstName : user && user.fullname;
  const fullName = `${firstName} ${lastName}`;

  const onImageError = () => {
    setImgErr(true);
  };

  return (
    <View style={styles.cardContainer}>
      <TouchableOpacity
        disabled={disabled}
        onPress={onImagePress}
        style={styles.cardImageContainer}
      >
        <FastImage
          onError={onImageError}
          source={
            imgErr ? {uri: defaultAvatar} : {uri: props.defaultAvatar}
          }
          style={[
            styles.cardImage,
            !props.defaultAvatar && {tintColor: 'grey'},
          ]}
        />
      </TouchableOpacity>
      <View style={styles.cardNameContainer}>
        <Text style={styles.cardName}>{fullName}</Text>
      </View>
    </View>
  );
}

ProfileImageCard.propTypes = {
  title: PropTypes.string,
  navigation: PropTypes.object,
  onImagePress: PropTypes.func,
  extraData: PropTypes.object,
  user: PropTypes.object,
  disabled: PropTypes.bool,
};

const itemIconSize = 26;
const itemNavigationIconSize = 23;

const styles = StyleSheet.create({
  blank: {
    flex: 0.5,
  },
  cardContainer: {
    flex: 1,
  },
  cardImage: {
    borderRadius: 65,
    height: 130,
    width: 130,
  },
  cardImageContainer: {
    alignItems: 'center',
    flex: 4,
    justifyContent: 'center',
  },
  cardName: {
    color: AppStyles.color.text,
    fontSize: 19,
  },
  cardNameContainer: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    paddingTop: 12,
  },
  container: {
    flex: 1,
  },
  footerButtonContainer: {
    flex: 2,
    justifyContent: 'flex-start',
    marginTop: 8,
  },
  footerContainerStyle: {
    borderColor: AppStyles.color.grey,
  },
  itemContainer: {
    alignSelf: 'center',
    flexDirection: 'row',
    height: 54,
    marginBottom: 10,
    width: '85%',
  },
  itemIcon: {
    height: itemIconSize,
    width: itemIconSize,
  },
  itemIconContainer: {
    alignItems: 'center',
    flex: 0.5,
    justifyContent: 'center',
  },
  itemNavigationIcon: {
    height: itemNavigationIconSize,
    tintColor: AppStyles.color.grey,
    width: itemNavigationIconSize,
  },
  itemNavigationIconContainer: {
    alignItems: 'center',
    flex: 0.5,
    justifyContent: 'center',
  },
  itemTitle: {
    color: AppStyles.color.text,
    fontSize: 17,
    paddingLeft: 20,
  },
  itemTitleContainer: {
    alignItems: 'flex-start',
    flex: 6,
    justifyContent: 'center',
  },
  profileCardContainer: {
    flex: 3,
  },
  profileItemContainer: {
    flex: 5.9,
    marginTop: 16,
  },
});

export default ProfileImageCard;
