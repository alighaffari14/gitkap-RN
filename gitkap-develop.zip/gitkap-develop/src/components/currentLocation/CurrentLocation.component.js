// @flow
import React from 'react';
import { View, Image, TouchableOpacity, Alert } from 'react-native';
import PropTypes from 'prop-types';
import type { Element as ReactElement } from 'react';

import styles from './CurrentLocation.styles';

import roundIcon from "../../../assets/icons/round.png";
import navigateMapIcon from "../../../assets/icons/navigateMap.png";

type CurrentLocationProps = {};
type CurrentLocationState = {};

class CurrentLocationComponent extends React.PureComponent<CurrentLocationProps, CurrentLocationState> {
    static defaultProps: any

    constructor(props: CurrentLocationProps) {
        super(props);
    }

    handleCurrentLocation = () => {
        // this.props.currentLocation();
    }

    renderContent = (): ReactElement<any> => {
        return (
            <View style={styles.container}>
                <TouchableOpacity
                    hitSlop={{ top: 50, left: 50, right: 50, bottom: 50 }}
                    style={styles.rightContainer}
                    onPress={this.handleCurrentLocation}>
                    <Image
                        source={navigateMapIcon}
                        style={styles.roundIcon}
                        resizeMode="contain"
                    />
                    <Image
                        source={roundIcon}
                        style={styles.topActionBarImage}
                        resizeMode="contain"
                    />
                </TouchableOpacity>
            </View>
        );
    }

    render() {
        const content = this.renderContent();

        return content;
    }
}

CurrentLocationComponent.propTypes = {};

CurrentLocationComponent.defaultProps = {};

export default CurrentLocationComponent;
