// @flow
import { StyleSheet } from 'react-native';

const style = StyleSheet.create({
    container: {
        flex: 1,
    },
    topActionBarImage: {
        position: 'absolute', right: 0,
        width: 35,
        height: 35
    },
    roundIcon: {
        position: 'absolute',
        right: 9,
        top: 9,
        width: 20,
        height: 20
    },
    rightContainer: {
        backgroundColor: 'red'
    }
});

export default style;
