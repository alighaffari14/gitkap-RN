// @flow
import React from 'react';
import {
  View,
  Text,
} from 'react-native';
import PropTypes from 'prop-types';

import styles from './TopActionBar.styles';

function TopActionBar(props: any) {
  const centerItem = typeof props.title === 'string' ?
    (
      <Text
        numberOfLines={1}
        style={styles.titleText}
      >
        {props.title}
      </Text>
    ) : props.title;

  return (
    <View style={[styles.wrapper, !props.disableBorder ? styles.borderStyle : null]}>
      <View style={props.leftActionTop ? styles.leftItemWrapperTop : styles.leftItemWrapper}>
        {props.leftAction}
      </View>
      <View style={[styles.centerItemWrapper, props.leftTitle ? styles.titleLeftContainer : styles.titleCenterContainer]}>
        {centerItem}
      </View>
      <View style={styles.rightItemWrapper}>
        {props.rightAction}
      </View>
    </View>
  );
}

TopActionBar.propTypes = {
  disableBorder: PropTypes.any,
  leftAction: PropTypes.any,
  leftActionTop: PropTypes.bool,
  leftTitle: PropTypes.bool,
  rightAction: PropTypes.any,
  title: PropTypes.oneOfType([PropTypes.string, PropTypes.element]),
};

TopActionBar.defaultProps = {
  leftAction: null,
  leftActionTop: false,
  leftTitle: false,
  rightAction: null,
  disableBorder: false,
  title: null,
};

export default TopActionBar;
