import {StyleSheet} from 'react-native';

import {titleText} from '../../shared/base';
import metrics from '../../shared/metrics';
import colors from '../../shared/colors';

const styles = StyleSheet.create({
  borderStyle: {
    borderBottomWidth: 1,
    borderColor: colors.white,
  },
  centerItemWrapper: {
    justifyContent: 'center',
  },
  leftItemWrapper: {
    flex: 1,
    justifyContent: 'center',
  },
  leftItemWrapperTop: {
    flex: 1,
  },
  rightItemWrapper: {
    alignItems: 'flex-end',
    flex: 1,
    justifyContent: 'center',
  },
  titleCenterContainer: {
    alignItems: 'center',
    flex: 4,
  },
  titleLeftContainer: {
    alignItems: 'flex-start',
    flex: 10,
  },
  titleText: {
    ...titleText,
  },
  wrapper: {
    backgroundColor: colors.white,
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: metrics.padding.actionBar.horizontal,
    paddingVertical: metrics.padding.actionBar.vertical,
  },
});

export default styles;
