import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { TouchableOpacity, Image, Text, StyleSheet } from 'react-native';
import { AppStyles } from '../AppStyles';

export default class FooterButton extends Component {
  render() {
    const {
      title,
      onPress,
      disabled,
      footerTitleStyle,
      footerContainerStyle,
      iconSource,
      iconStyle
    } = this.props;

    return (
      <TouchableOpacity
        disabled={disabled}
        onPress={onPress}
        style={[styles.footerContainer, footerContainerStyle]}
      >
        {iconSource && <Image style={iconStyle} source={iconSource} />}
        <Text style={[styles.footerTitle, footerTitleStyle]}>{title}</Text>
      </TouchableOpacity>
    );
  }
}

FooterButton.propTypes = {
  title: PropTypes.string.isRequired,
  footerContainerStyle: PropTypes.object,
  footerTitleStyle: PropTypes.object,
  iconStyle: PropTypes.object,
  iconSource: PropTypes.any,
  onPress: PropTypes.func,
  disabled: PropTypes.bool
};

const styles = StyleSheet.create({
  footerContainer: {
    height: 50,
    width: '92%',
    margin: 5,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderRadius: 4,
    borderColor: AppStyles.color.main,
    marginBottom: 50,
    flexDirection: 'row'
  },
  footerTitle: {
    fontSize: 17,
    // padding: 10,
    color: AppStyles.color.text
  }
});
