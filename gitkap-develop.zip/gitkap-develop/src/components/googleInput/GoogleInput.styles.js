// @flow
import { StyleSheet } from 'react-native';
import colors from '../../shared/colors';

const style = StyleSheet.create({
    container: {
        flex: 1,
    },
    searchIcon: {
        marginTop: 20,
        marginRight: 20,
        paddingTop: 20,
        width: 25,
        backgroundColor: colors.white,
        height: 25
    }
});

export default style;
