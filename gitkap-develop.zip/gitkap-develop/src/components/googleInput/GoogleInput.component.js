// @flow
import React from 'react';
import {View, Image} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';

import styles from './GoogleInput.styles';

import searchMapIcon from '../../../assets/icons/searchMap.png';

type GoogleInputProps = {};
type GoogleInputState = {};

class GoogleInputComponent extends React.PureComponent<GoogleInputProps, GoogleInputState> {
    static defaultProps: any

    constructor(props: GoogleInputProps) {
      super(props);
    }

    handleGooglePlaceInput = (data, details) => {
      const {googleInputPlace} = this.props;
      googleInputPlace(data, details);
    }

    renderContent = (): ReactElement<any> => {
      return (
        <View
              style={{
            backgroundColor: 'rgba(0,0,0,0)',
            position: 'absolute',
            top: -10,
            left: 5,
            right: 5,
          }}
        >
          <GooglePlacesAutocomplete
            fetchDetails
            onPress={this.handleGooglePlaceInput}
            placeholder="Enter your location"
            query={{
              // available options: https://developers.google.com/places/web-service/autocomplete
              key: 'AIzaSyCK9195rpO4FJm0UvXImv28Dek6iEBHI4k',
              language: 'en', // language of the results
              types: 'address', // default: 'geocode'
              components: 'country:TUR', // added  manually
            }}
            // renderRightButton={() => <Image
            //     source={searchMapIcon}
            //     style={styles.searchIcon}
            // />}

            styles={{
              textInputContainer: {
                width: '100%',
                backgroundColor: 'rgba(0,0,0,0)',
                borderTopWidth: 0,
                borderBottomWidth: 0,
              },
              textInput: {
                marginLeft: 0,
                marginRight: 0,
                height: 38,
                color: '#5d5d5d',
                fontSize: 16,
              },
              description: {
                fontWeight: 'bold',
              },
              predefinedPlacesDescription: {
                color: '#1faadb',
              },
              listView: {
                backgroundColor: 'rgba(255,255,255,1)',
              },
            }}
          />
        </View>
      );
    }

    render() {
      const content = this.renderContent();

      return content;
    }
}

GoogleInputComponent.propTypes = {};

GoogleInputComponent.defaultProps = {};

export default GoogleInputComponent;
