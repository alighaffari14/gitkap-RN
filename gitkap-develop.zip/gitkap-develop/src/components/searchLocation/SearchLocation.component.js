// @flow
import React from 'react';
import {View, Alert, TouchableOpacity, Text, TouchableHighlight, Image} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';

import styles from './SearchLocation.styles';
import colors from '../../shared/colors';

type SearchLocationProps = {};
type SearchLocationState = {};

const navigateImage = require('../../../assets/icons/navigate.png');
const correctmarker = require('../../../assets/icons/correctmarker.png');

class SearchLocationComponent extends React.PureComponent<SearchLocationProps, SearchLocationState> {
  static defaultProps: any

  constructor(props: SearchLocationProps) {
    super(props);
    this.state = {
      circle: false,
      xCircle: false,
      xxCircle: false,
      timer: 0,
    };
  }

  componentWillMount() {
    this._intervalId = setInterval(this.myTimer, 1000);
  }

  componentWillUnmount() {
    clearInterval(this._intervalId);
  }

  _intervalId: null

  myTimer = () => {
    const {timer} = this.state;
    let xxCircle = false;
    let xCircle = false;
    let circle = false;
    let currentTimer = timer + 1;

    if (timer == 1) {
      circle = true;
    } else if (timer == 2) {
      circle = true;
      xCircle = true;
    } else if (timer == 3) {
      circle = true;
      xCircle = true;
      xxCircle = true;
      currentTimer = 0;
    }

    this.setState({
      timer: currentTimer,
      xxCircle,
      xCircle,
      circle,
    });
  }

  handleNavigate = () => {
    Alert.alert('handle');
  }

  handleSearchLocation = () => {
    this.props.onSearchLocation();
  }

  handleBack = () => {
    this.props.back();
  }

  renderXXCricle = () => {
    return (
      <View style={{backgroundColor: colors.xLightOrange, width: 320, height: 320, borderRadius: 160, position: 'absolute', top: 0, left: 0}} />
    );
  }

  renderXCricle = () => {
    return (
      <View style={{backgroundColor: colors.xOrange, width: 240, height: 240, borderRadius: 120, position: 'absolute', top: 40, left: 40}} />
    );
  }

  renderCricle = () => {
    return (
      <View style={{backgroundColor: colors.xDarkOrange, width: 160, height: 160, borderRadius: 80, position: 'absolute', top: 80, left: 80}} />
    );
  }

  renderContent = (): ReactElement<any> => {
    const {circle, xCircle, xxCircle} = this.state;
    const circleElement = circle ? this.renderCricle() : null;
    const xcircleElement = xCircle ? this.renderXCricle() : null;
    const xxcircleElement = xxCircle ? this.renderXXCricle() : null;
    const icon = this.props.from == 'detail' ? (
      <TouchableOpacity
        hitSlop={{left: 70, right: 70, top: 70, bottom: 70}}
        onPress={this.handleBack}
        style={{marginVertical: 30, marginHorizontal: 22}}
      >
        <Image
          source={correctmarker}
          style={{width: 43, height: 43}}
        />
      </TouchableOpacity>
    ) : (
      <TouchableOpacity
        hitSlop={{left: 70, right: 70, top: 70, bottom: 70}}
        onPress={this.handleSearchLocation}
        style={{marginVertical: 30, marginHorizontal: 22}}
      >
        <Image
          source={navigateImage}
        />
      </TouchableOpacity>);

    return (
      <View
        onPress={this.handleNavigate}
        style={styles.container}
      >

        {xxcircleElement}
        {xcircleElement}
        {circleElement}
        <View style={{backgroundColor: colors.darkOrange, width: 100, height: 100, borderRadius: 50, position: 'absolute', top: 110, left: 110}}>

          {icon}
        </View>
      </View >
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}
SearchLocationComponent.propTypes = {};

SearchLocationComponent.defaultProps = {};

export default SearchLocationComponent;
