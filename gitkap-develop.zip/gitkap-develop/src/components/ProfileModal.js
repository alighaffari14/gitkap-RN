import React, { Component, PureComponent } from 'react';
import PropTypes from 'prop-types';
import {
  View,
  ScrollView,
  StyleSheet,
  BackHandler,
  Platform,
} from 'react-native';
import firebase from 'react-native-firebase';
import { connect } from 'react-redux';
import TextButton from 'react-native-button';
import ActionSheet from 'react-native-actionsheet';
import ImagePicker from 'react-native-image-crop-picker';
import ProfileImageCard from './ProfileImageCard';
import ProfileItem from './ProfileItem';
import FooterButton from './FooterButton';
import PostModal from '../components/postModal/PostModal';
import { AppStyles, AppIcon } from '../AppStyles';
import { Configuration } from '../Configuration';
import ServerConfiguration from '../ServerConfiguration';
import authManager from '../Core/onboarding/utils/authManager';
import DynamicAppStyles from '../DynamicAppStyles';
import ListingAppConfig from '../ListingAppConfig';
import { logout } from '../Core/onboarding/redux/auth';
import authDeviceStorage from '../Core/onboarding/utils/AuthDeviceStorage';

const defaultAvatar =
  'https://www.iosapptemplates.com/wp-content/uploads/2019/06/empty-avatar.jpg';

class ProfileModal extends PureComponent<any, any> {
  static navigationOptions = ({ navigation }) => ({
    title: 'Profile',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={styles.rightButton}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);

    this.state = {
      activeSlide: 0,
      categories: [],
      listings: [],
      allListings: [],
      selectedCategoryName: '',
      savedListings: [],
      selectedItem: null,
      showedAll: false,
      isAddListingVisible: false,
      homeCategoryId: 'aaPdF5Dskd3DrHMWV3SwLs',
    };
    this.updatePhotoDialogActionSheet = React.createRef();
    this.photoUploadDialogActionSheet = React.createRef();

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    if (props.user) {
      this.userRef = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.USERS)
        .doc(props.user.id);
      this.listingsRef = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.LISTINGS)
        .where('is_approved', '==', true);
      if (this.props.user) {
        this.savedListingsRef = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
          .where('user_id', '==', this.props.user.id);
      } else this.savedListingsRef = firebase.firestore();
    }

    this.listingsUnsubscribe = null;
    this.savedListingsUnsubscribe = null;
  }

  componentDidMount() {
    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onListingsCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      if (this.state.savedListings.findIndex((k) => k == doc.id) >= 0) {
        listing.saved = true;
      } else {
        listing.saved = false;
      }
      data.push({ ...listing, id: doc.id });
    });

    this.setState({
      listings: data.slice(0, Configuration.home.initial_show_count),
      allListings: data,
      loading: false,
      showedAll: data.length <= Configuration.home.initial_show_count,
    });
  };

  onSavedListingsCollectionUpdate = (querySnapshot) => {
    const savedListingdata = [];
    querySnapshot.forEach((doc) => {
      const savedListing = doc.data();
      savedListingdata.push(savedListing.listing_id);
    });
    const listingsData = [];
    this.state.listings.forEach((listing) => {
      const temp = listing;
      if (savedListingdata.findIndex((k) => k == temp.id) >= 0) {
        temp.saved = true;
      } else {
        temp.saved = false;
      }
      listingsData.push(temp);
    });

    this.setState({
      savedListings: savedListingdata,
      listings: listingsData,
      loading: false,
    });
  };

  onModal = (modalVisible, callback) => {
    this.setState({ [modalVisible]: !this.state[modalVisible] }, () => {
      callback;
    });
  };

  onUpdatePhotoDialogDone = (index) => {
    if (index === 0) {
      this.photoUploadDialogActionSheet.current.show();
    }

    if (index === 1) {
      this.removePhoto();
    }
  };

  removePhoto = () => {
    const self = this;

    self.userRef
      .update({ profilePictureURL: defaultAvatar })
      .then(() => {
        self.setState({ loading: false });
        self.props.navigation.dispatch({
          type: 'UPDATE_USER_DATA',
          user: { ...self.props.user, profilePictureURL: defaultAvatar },
        });
      })
      .catch(function (error) {
        const { message } = error;
        self.setState({ loading: false });
      });
  };

  onPhotoUploadDialogDone = (index) => {
    if (index === 0) {
      this.onLaunchCamera();
    }

    if (index === 1) {
      this.onOpenPhotos();
    }
  };

  onLaunchCamera = () => {
    ImagePicker.openCamera({
      cropping: false,
    }).then((image) => {
      const source = image.path;

      this.setState({ loading: true });

      this.startUpload(source);
    });
  };

  onOpenPhotos = () => {
    ImagePicker.openPicker({
      cropping: false,
    }).then((image) => {
      const source = image.path;

      this.setState({ loading: true });
      this.startUpload(source);
    });
  };

  uploadPromise = (uri) => {
    return new Promise((resolve, reject) => {
      const filename = uri.substring(uri.lastIndexOf('/') + 1);
      const uploadUri =
        Platform.OS === 'ios' ? uri.replace('file://', '') : uri;
      firebase
        .storage()
        .ref(filename)
        .putFile(uploadUri)
        .then(function (snapshot) {
          resolve(snapshot.downloadURL);
        });
    });
  };

  startUpload = (source) => {
    const self = this;
    self
      .uploadPromise(source)
      .then((url) => {
        self.props.navigation.dispatch({
          type: 'UPDATE_USER_DATA',
          user: { ...self.props.user, profilePictureURL: url },
        });
        const data = {
          profilePictureURL: url,
        };

        self.updateUserInfo(data);
      })
      .catch(function (error) {
        self.setState({ loading: false });
      });
  };

  updateUserInfo = (data) => {
    const self = this;

    self.userRef
      .update(data)
      .then(() => {
        self.setState({ loading: false });
      })
      .catch(function (error) {
        const { message } = error;
        self.setState({ loading: false });
      });
  };

  onLogout() {
    authManager.logout(this.props.user);
    authDeviceStorage.setUserData('false');
    this.props.logout();
    this.props.navigation.navigate('LoadScreen', { appStyles: DynamicAppStyles, appConfig: ListingAppConfig });
  }

  render() {
    const { isAddListingVisible, categories } = this.state;

    return (
      <View style={styles.container}>
        <View style={styles.profileCardContainer}>
          <ProfileImageCard
            defaultAvatar={defaultAvatar}
            onImagePress={() =>
              this.updatePhotoDialogActionSheet.current.show()}
            user={this.props.user}
          />
        </View>
        <View style={styles.profileItemContainer}>
          <ScrollView style={styles.container}>
            <ProfileItem
              iconSource={AppIcon.images.list}
              itemIconStyle={{ tintColor: '#baa3f3' }}
              onPress={() => this.props.navigation.navigate('MyListingModal')}
              title="My Listings"
            />
            <ProfileItem
              iconSource={AppIcon.images.wishlistFilled}
              itemIconStyle={{ tintColor: '#df9292' }}
              onPress={() =>
                this.props.navigation.navigate('SavedListingModal')}
              title="My Favourites"
            />
            <ProfileItem
              iconSource={AppIcon.images.accountDetail}
              itemIconStyle={{ tintColor: '#6b7be8' }}
              onPress={() => this.props.navigation.navigate('AccountDetail')}
              title="Account Details"
            />
            <ProfileItem
              iconSource={AppIcon.images.settings}
              itemIconStyle={{ tintColor: '#a6a4b1' }}
              onPress={() => this.props.navigation.navigate('Settings')}
              title="Settings"
            />
            {this.props.isAdmin && (
              <ProfileItem
                iconSource={AppIcon.images.checklist}
                itemIconStyle={{ tintColor: '#8aced8' }}
                onPress={() => this.props.navigation.navigate('AdminDashboard')}
                title="Admin Dashboard"
              />
            )}
            <ProfileItem
              iconSource={AppIcon.images.contactUs}
              itemIconStyle={{ tintColor: '#9ee19f' }}
              onPress={() => this.props.navigation.navigate('Contact')}
              title="Contact Us"
            />
          </ScrollView>
        </View>
        <View style={styles.footerButtonContainer}>
          <FooterButton
            footerContainerStyle={styles.footerContainerStyle}
            onPress={() => {
              this.onLogout();
            }}
            title="Logout"
          />
        </View>
        {isAddListingVisible && (
          <PostModal
            categories={categories}
            isVisible={isAddListingVisible}
            onCancel={() => this.onModal('isAddListingVisible')}
          />
        )}
        <ActionSheet
          cancelButtonIndex={2}
          destructiveButtonIndex={1}
          onPress={this.onUpdatePhotoDialogDone}
          options={['Change Photo', 'Remove', 'Cancel']}
          ref={this.updatePhotoDialogActionSheet}
          title="Photo Dialog"
        />
        <ActionSheet
          cancelButtonIndex={2}
          onPress={this.onPhotoUploadDialogDone}
          options={['Camera', 'Library', 'Cancel']}
          ref={this.photoUploadDialogActionSheet}
          title="Photo Upload"
        />
      </View>
    );
  }
}

ProfileModal.propTypes = {
  title: PropTypes.string,
  presentationStyle: PropTypes.string,
  ProfileScreen: PropTypes.array,
  navigation: PropTypes.object,
  user: PropTypes.object,
  onModal: PropTypes.func,
  onProfileModalCancel: PropTypes.func,
  onSavedModalCancel: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
  },
  footerButtonContainer: {
    flex: 2,
    justifyContent: 'flex-start',
    marginTop: 8,
  },
  profileCardContainer: {
    flex: 5,
    marginTop: 5,
    paddingTop: 10,
  },
  profileItemContainer: {
    flex: 8.5,
    marginTop: 16,
  },
  rightButton: {
    color: AppStyles.color.main,
    marginRight: 10,
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
  // isAdmin: state.auth.user.isAdmin,
});

export default connect(mapStateToProps, {
  logout,
})(ProfileModal);
