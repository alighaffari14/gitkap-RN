import React from 'react';
import {Modal, Text, View, StyleSheet} from 'react-native';
import TextButton from 'react-native-button';
import MapView, {Marker, PROVIDER_GOOGLE} from 'react-native-maps';
import {AppStyles, ModalHeaderStyle, HeaderButtonStyle} from '../AppStyles';
import {Configuration} from '../Configuration';
import {mapStyle} from '../shared/base';

class SelectLocationModal extends React.PureComponent<any, any> {
  constructor(props) {
    super(props);
    const location = this.props.location;

    this.state = {
      latitude: location.latitude,
      longitude: location.longitude,
      latitudeDelta: Configuration.map.delta.latitude,
      longitudeDelta: Configuration.map.delta.longitude,
    };
  }

  onDone = () => {
    this.props.onDone({
      latitude: this.state.latitude,
      longitude: this.state.longitude,
    });
  };

  onCancel = () => {
    this.props.onCancel();
  };

  onPress = (event) => {
    this.setState({
      latitude: event.nativeEvent.coordinate.latitude,
      longitude: event.nativeEvent.coordinate.longitude,
    });
  };

  onRegionChange = (region) => {
    this.setState({
      latitude: region.latitude,
      longitude: region.longitude,
      latitudeDelta: region.latitudeDelta,
      longitudeDelta: region.longitudeDelta,
    });
  };

  render() {
    return (
      <Modal
        animationType="slide"
        onRequestClose={this.onCancel}
        transparent={false}
      >
        <View style={styles.body}>
          <MapView
            customMapStyle={mapStyle}
            onPress={this.onPress}
            onRegionChangeComplete={this.onRegionChange}
            provider={PROVIDER_GOOGLE}
            ref={(map) => (this.map = map)}
            region={{
              latitude: this.state.latitude,
              longitude: this.state.longitude,
              latitudeDelta: this.state.latitudeDelta,
              longitudeDelta: this.state.longitudeDelta,
            }}
            style={styles.mapView}
          >
            <Marker
              coordinate={{
                latitude: this.state.latitude,
                longitude: this.state.longitude,
              }}
              draggable
              onDragEnd={this.onPress}
            />
          </MapView>
          <View style={[ModalHeaderStyle.bar, styles.topbar]}>
            <TextButton
              onPress={this.onDone}
              style={[ModalHeaderStyle.rightButton, styles.rightButton]}
            >
              Done
            </TextButton>
          </View>
        </View>
      </Modal>
    );
  }
}

const styles = StyleSheet.create({
  body: {
    height: '100%',
    width: '100%',
  },
  mapView: {
    backgroundColor: AppStyles.color.grey,
    height: '100%',
    position: 'absolute',
    width: '100%',
  },
  rightButton: {
    paddingRight: 10,
  },
  topbar: {
    backgroundColor: 'transparent',
    position: 'absolute',
    width: '100%',
  },
});

export default SelectLocationModal;
