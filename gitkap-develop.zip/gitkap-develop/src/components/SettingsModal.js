import React from 'react';
import {
  StyleSheet,
  Text,
  Modal,
  View,
  Switch,
  TouchableOpacity,
  BackHandler
} from 'react-native';
import TextButton from 'react-native-button';
import { AppStyles } from '../AppStyles';

export default class SettingsModal extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Settings',
    headerLeft: null,
    headerRight: (
      <TextButton
        style={[styles.rightButton]}
        onPress={() => navigation.goBack()}
      >
        Cancel
      </TextButton>
    )
  });

  constructor(props) {
    super(props);
    this.state = {
      allowPushNotification: true,
      enableTouchId: false
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      payload =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      payload =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  toggleBoolState = (stateKey, callback) => {
    this.setState({ [stateKey]: !this.state[stateKey] }, () => {
      callback;
    });
  };

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  renderSettingsType = ({ title, value, stateKey }) => (
    <View
      style={[styles.settingsTypeContainer, styles.appSettingsTypeContainer]}
    >
      <Text style={styles.text}>{title}</Text>
      <Switch
        value={value}
        onValueChange={value => this.toggleBoolState(stateKey)}
        style={{ transform: [{ scaleX: 0.8 }, { scaleY: 0.8 }] }}
      />
    </View>
  );

  render() {
    const { isVisible, presentationStyle, onCancel } = this.props;
    return (
      <View style={styles.container}>
        <View style={styles.settingsTitleContainer}>
          <Text style={styles.settingsTitle}>{'GENERAL'}</Text>
        </View>
        <View style={styles.settingsTypesContainer}>
          {this.renderSettingsType({
            title: 'Allow Push Notifications',
            value: this.state.allowPushNotification,
            stateKey: 'allowPushNotification'
          })}
          {/* <View style={styles.divider} />
          {this.renderSettingsType({
            title: "Enable Face/Touch ID",
            value: this.state.enableTouchId,
            stateKey: "enableTouchId"
          })} */}
        </View>
        <TouchableOpacity
          style={[
            styles.settingsTypeContainer,
            styles.appSettingsSaveContainer
          ]}
        >
          <Text style={styles.settingsType}>{'Save'}</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#efeff4'
  },
  rightButton: {
    marginRight: 10,
    color: AppStyles.color.main
  },
  //Profile Settings
  settingsTitleContainer: {
    width: '100%',
    height: 55,
    justifyContent: 'flex-end'
  },
  settingsTitle: {
    color: AppStyles.color.text,
    paddingLeft: 10,
    fontSize: 14,
    paddingBottom: 6,
    fontWeight: '500'
  },
  settingsTypesContainer: {
    backgroundColor: '#ffffff'
  },
  settingsTypeContainer: {
    borderBottomColor: '#f5f5f5',
    borderBottomWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: 50
  },
  settingsType: {
    color: AppStyles.color.main,
    fontSize: 14,
    fontWeight: '500'
  },

  //Edit Profile
  contentContainer: {
    width: '100%',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#e0e0e0',
    backgroundColor: '#ffffff'
  },
  divider: {
    height: 0.5,
    width: '96%',
    alignSelf: 'flex-end',
    backgroundColor: '#e0e0e0'
  },
  text: {
    fontSize: 14,
    color: AppStyles.color.text
  },

  //app Settings
  appSettingsTypeContainer: {
    flexDirection: 'row',
    borderBottomWidth: 0,
    justifyContent: 'space-between',
    paddingHorizontal: 15
  },
  appSettingsSaveContainer: {
    marginTop: 50,
    height: 45,
    backgroundColor: '#ffffff'
  },
  placeholderTextColor: { color: '#e0e0e0' }
});
