import React, {Component} from 'react';
import PropTypes from 'prop-types';
import {
  TouchableOpacity,
  View,
  Text,
  Image,
  StyleSheet,
  Dimensions,
} from 'react-native';
import {AppStyles, AppIcon} from '../AppStyles';

const {width, height} = Dimensions.get('window');

export default class ProfileItem extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    const {title, onPress, iconSource, itemIconStyle} = this.props;

    return (
      <TouchableOpacity onPress={onPress} style={styles.itemContainer}>
        <View style={styles.itemIconContainer}>
          <Image source={iconSource} style={[styles.itemIcon, itemIconStyle]} />
        </View>
        <View style={styles.itemTitleContainer}>
          <Text style={styles.itemTitle}>{title}</Text>
        </View>
        <View style={styles.itemNavigationIconContainer}>
          <Image
            source={AppIcon.images.rightArrow}
            style={styles.itemNavigationIcon}
          />
        </View>
      </TouchableOpacity>
    );
  }
}

ProfileItem.propTypes = {
  title: PropTypes.string,
  onPress: PropTypes.func,
  navigation: PropTypes.object,
  iconSource: PropTypes.any,
  itemIconStyle: PropTypes.object,
};
const itemIconSize = 26;
const itemNavigationIconSize = 23;

const styles = StyleSheet.create({
  blank: {
    flex: 0.5
  },
  footerButtonContainer: {
    flex: 2,
    justifyContent: 'flex-start',
    marginTop: 8
  },
  footerContainerStyle: {
    borderColor: AppStyles.color.grey
  },
  itemContainer: {
    flexDirection: 'row',
    height: height * 0.057,
    width: '85%',
    alignSelf: 'center',
    marginBottom: 10
  },
  itemIcon: {
    height: itemIconSize,
    width: itemIconSize
  },
  itemIconContainer: {
    flex: 0.5,
    justifyContent: 'center',
    alignItems: 'center'
  },
  itemNavigationIcon: {
    height: itemNavigationIconSize,
    width: itemNavigationIconSize,
    tintColor: AppStyles.color.grey
  },
  itemNavigationIconContainer: {
    flex: 0.5,
    justifyContent: 'center',
    alignItems: 'center'
  },
  itemTitle: {
    color: AppStyles.color.text,
    fontSize: 17,
    paddingLeft: 20
  },
  itemTitleContainer: {
    flex: 6,
    justifyContent: 'center',
    alignItems: 'flex-start'
  },
});
