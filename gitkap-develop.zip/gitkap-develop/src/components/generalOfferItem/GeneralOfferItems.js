// @flow
import React from 'react';
import {View} from 'react-native';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';
import firebase from 'react-native-firebase';

import styles from './GeneralOfferItems.styles';
import GeneralOfferImageComponent from '../generalOfferImage/GeneralOfferImage.component';
import GeneralOfferDescriptionComponent from '../generalOfferDescription/generalOfferDescription.component';
import ServerConfiguration from '../../ServerConfiguration';

type GeneralOfferItemProps = {};
type GeneralOfferItemState = {};

class GeneralOfferItemComponent extends React.PureComponent<GeneralOfferItemProps, GeneralOfferItemState> {
  static defaultProps: any

  constructor(props: GeneralOfferItemProps) {
    super(props);
    this.state = {
      favEnable: props.item.favouriteEnable,
    };

    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);

    this.listFavourite = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.FAVOURITE);
  }

  handleFavEnable = () => {
    const {item, user} = this.props;
    const formattedUser = JSON.parse(user);
    const currentUserId = formattedUser.userID;
    const itemId = item.id;
    const favEnable = !this.state.favEnable;

    const docRef = this.listFavourite.doc(currentUserId + itemId);
    const docListingRef = this.listingsRef.doc(itemId);

    docRef.get().then(function(thisDoc) {
      if (thisDoc.exists) {
        favEnable ? docRef.update({userId: currentUserId, itemId, favEnable, itemName: item.name}) : docRef.delete();
      } else {
        favEnable ? docRef.set({userId: currentUserId, itemId, favEnable, itemName: item.name}) : null;
      }
    });

    docListingRef.get().then(function(thisDoc) {
      if (thisDoc.exists) {
        const favEnableCount = thisDoc._data.favEnableCount;
        if (favEnable) {
          favEnableCount && favEnableCount >= 0 ? docListingRef.update({favEnableCount: favEnableCount + 1}) : docListingRef.update({favEnableCount: 1});
        } else {
          favEnableCount && favEnableCount >= 0 ? docListingRef.update({favEnableCount: favEnableCount - 1}) : docListingRef.update({favEnableCount: 1});
        }
      }
    });

    this.setState({
      favEnable: !this.state.favEnable,
    });
  }

  // handleLongPress = () => {
  //   const {onLongPressListingItem, item} = this.props;

  //   onLongPressListingItem(item);
  // }

  // handlePress = () => {
  //   const { onPressListingItem, item } = this.props;

  //   onPressListingItem(item);
  // }

  onHandlePressListingItem = (item) => {
    const {pressListingItem} = this.props;
    const {favEnable} = this.state;

    pressListingItem(item, favEnable);
  }

  renderDetailedDescription = () => {
    const {timeAgoText, item, favEnableCount} = this.props;

    return (
      <GeneralOfferDescriptionComponent
        favEnableCount={favEnableCount}
        item={item}
        pressListingItem={this.onHandlePressListingItem}
        timeAgoText={timeAgoText}
      />);
  }

  renderContent = (): ReactElement<any> => {
    const {item} = this.props;

    const {favEnable} = this.state;
    const detailDescription = this.renderDetailedDescription();

    return (
      <View style={styles.container}>
        <View style={styles.listingItemContainer}>
          <GeneralOfferImageComponent
            favEnable={favEnable}
            item={item}
            onFavEnable={this.handleFavEnable}
          />
          {detailDescription}
        </View>
      </View>
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

GeneralOfferItemComponent.propTypes = {
  item: PropTypes.any.isRequired,
  pressListingItem: PropTypes.func.isRequired,
  timeAgoText: PropTypes.string.isRequired,
  user: PropTypes.any.isRequired,
};

GeneralOfferItemComponent.defaultProps = {};

export default GeneralOfferItemComponent;
