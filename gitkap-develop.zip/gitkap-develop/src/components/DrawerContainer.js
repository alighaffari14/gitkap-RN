import React from 'react';
import {StyleSheet, View} from 'react-native';
import {connect} from 'react-redux';
import MenuButton from '../components/MenuButton';
import {AppIcon} from '../AppStyles';

class DrawerContainer extends React.Component {
  render() {
    const {navigation} = this.props;

    return (
      <View style={styles.content}>
        <View style={styles.container}>
          <MenuButton
            onPress={() => {
              navigation.dispatch({ type: 'Logout' });
            }}
            source={AppIcon.images.logout}
            title="LOG OUT"
          />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'flex-start',
    paddingHorizontal: 20
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
});

const mapStateToProps = (state) => ({
  // isAdmin: state.auth.user.isAdmin
});

export default connect(mapStateToProps)(DrawerContainer);
