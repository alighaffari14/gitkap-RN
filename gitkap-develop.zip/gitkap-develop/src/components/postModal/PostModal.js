/* eslint-disable react/jsx-max-depth */
import React from 'react';
import {
  Modal, ScrollView, ActivityIndicator, TouchableOpacity, TextInput, Text, View, Image,
} from 'react-native';
import firebase from 'react-native-firebase';
import Geolocation from '@react-native-community/geolocation';
import ModalSelector from 'react-native-modal-selector';
import TextButton from 'react-native-button';
import FastImage from 'react-native-fast-image';
import { connect } from 'react-redux';
// import Icon from 'react-native-vector-icons/FontAwesome';
import ImagePicker from 'react-native-image-picker';
import ActionSheet from 'react-native-actionsheet';
import Geocoder from 'react-native-geocoding';
import TimePicker from 'react-native-24h-timepicker';
import LinearGradient from 'react-native-linear-gradient';

import { AppStyles, ModalHeaderStyle, ModalSelectorStyle } from '../../AppStyles';
import { Configuration } from '../../Configuration';
import FilterViewModal from '../FilterViewModal';
import SelectLocationModal from '../SelectLocationModal';
import ServerConfiguration from '../../ServerConfiguration';
import { firebaseStorage } from '../../Core/firebase/storage';
import ListingAppConfig from '../../ListingAppConfig';

import styles from './PostModal.styles';
import colors from '../../shared/colors';
import authDeviceStorage from '../../Core/onboarding/utils/AuthDeviceStorage';

const cameraIcon = require('../../../assets/icons/attach.png');

class PostModal extends React.PureComponent<any, any> {
  static navigationOptions = ({ navigation }) => ({
    title: 'Home',
  });

  constructor(props) {
    super(props);

    Geocoder.init(ListingAppConfig.reverseGeoCodingAPIKey);

    const { selectedItem, categories } = this.props;
    // const category = {name: 'Select...'};
    let title = '';
    let description = '';
    let location = {
      latitude: Configuration.map.origin.latitude,
      longitude: Configuration.map.origin.longitude,
    };
    let localPhotos = [];
    let photoUrls = [];
    let price = '';
    const oppotunity = '';
    const discountRate = '';
    const textInputValue = '';


    let filter = {};
    const filterValue = 'Select...';
    let address: 'Checking...';
    const category = '';

    // if (categories.length > 0) category = categories[0];
    if (selectedItem) {
      const {
        name,
        latitude,
        longitude,
        list_of_photos,
        mapping,
        place,
      } = selectedItem;

      // category = categories.find(
      //   (category) => selectedItem.category_id === category.id
      // );
      title = name;
      description = selectedItem.description;
      location = {
        latitude,
        longitude,
      };
      localPhotos = list_of_photos;
      photoUrls = list_of_photos;
      price = selectedItem.price;
      filter = mapping;
      address = place;
    }

    this.state = {
      categories: categories,
      category: category,
      title,
      oppotunity: oppotunity,
      discountRate: discountRate,
      description,
      location,
      localPhotos,
      photoUrls,
      price,
      textInputValue,
      filter,
      filterValue,
      address,
      filterModalVisible: false,
      locationModalVisible: false,
      loading: false,
      currentLocation: null,
      startTime: '',
      endTime: '',
      about: ''
    };
  }

  componentDidMount() {
    this.resolveCurrentLocation();

    // this.setFilterString(this.state.filter);
    Geolocation.getCurrentPosition(
      (position) => {
        this.setState({ location: position.coords });
        this.onChangeLocation(position.coords);
      },
      (error) => alert(error.message),
      { enableHighAccuracy: false, timeout: 1000 }
    );
  }

  selectLocation = () => {
    this.setState({ locationModalVisible: true });
  };

  onChangeLocation = (location) => {
    Geocoder.from(location.latitude, location.longitude)
      .then((json) => {
        const addressComponent = json.results[0].formatted_address;
        this.setState({ address: addressComponent });
      })
      .catch((error) => {
        this.setState({ address: 'Unknown' });
      });
  };

  resolveCurrentLocation = async () => {
    const currentLocation = await authDeviceStorage.getUserLocation();
    this.setState({ currentLocation });
  }

  setFilterString = (filter) => {
    let filterValue = '';
    Object.keys(filter).forEach(function (key) {
      if (filter[key] != 'Any' && filter[key] != 'All') {
        filterValue += ' ' + filter[key];
      }
    });

    if (filterValue == '') {
      if (Object.keys(filter).length > 0) {
        filterValue = 'Any';
      } else {
        filterValue = 'Select...';
      }
    }

    this.setState({ filterValue: filterValue });
  };

  onSelectLocationDone = (location) => {
    this.setState({ location: location });
    this.setState({ locationModalVisible: false });
    this.onChangeLocation(location);
  };

  onSelectLocationCancel = () => {
    this.setState({ locationModalVisible: false });
  };

  selectFilter = () => {
    if (!this.state.category.id) {
      alert('You must choose a category first.');
    } else {
      this.setState({ filterModalVisible: true });
    }
  };

  onSelectFilterCancel = () => {
    this.setState({ filterModalVisible: false });
  };

  onSelectFilterDone = (filter) => {
    this.setState({ filter: filter });
    this.setState({ filterModalVisible: false });
    this.setFilterString(filter);
  };

  onPressAddPhotoBtn = () => {
    // More info on all the options is below in the API Reference... just some common use cases shown here
    const options = {
      title: 'Select a photo',
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };

    /**
     * The first arg is the options object for customization (it can also be null or omitted for default options),
     * The second arg is the callback which sends object: response (more info in the API Reference)
     */
    ImagePicker.showImagePicker(options, (response) => {
      if (response.didCancel) {
      } else if (response.error) {
      } else if (response.customButton) {
      } else {
        this.setState({
          localPhotos: [...this.state.localPhotos, response.uri],
        });
      }
    });
  };

  onCancel = () => {
    this.props.onCancel();
  };

  handlePost = () => {
    const { user, location } = this.props;
    const self = this;
    // console.log('location', location.formattedAddress);
    const formattedUser = this.props.user;
    // console.log('user.JobDescription', formattedUser);

    const onCancel = self.onCancel;

    // console.log('currentLocation', currentLocation);

    if (!self.state.title) {
      alert('Title was not provided.');

      return;
    }
    if (!self.state.oppotunity) {
      alert('Oppotunity is empty.');

      return;
    }

    if (!self.state.category) {
      alert('General category is empty.');

      return;
    }

    // if (!self.state.startTimer) {
    //   alert('Start timer is empty.');

    //   return;
    // }

    // if (!self.state.finishTimer) {
    //   alert('Finish timer is empty.');

    //   return;
    // }

    if (!self.state.discountRate) {
      alert('Discount rate is empty.');

      return;
    }

    if (!self.state.description) {
      alert('Description was not set.');

      return;
    }

    if (self.state.localPhotos.length == 0) {
      alert('Please choose at least one photo.');

      return;
    }

    // if (Object.keys(self.state.filter).length == 0) {
    //   alert('Please set the filters.');

    //   return;
    // }

    self.setState({ loading: true });

    let photoUrls = [];

    if (this.props.selectedItem) {
      photoUrls = [...this.props.selectedItem.list_of_photos];
    }

    const uploadPromiseArray = [];
    self.state.localPhotos.forEach((uri) => {
      if (!uri.startsWith('https://')) {
        uploadPromiseArray.push(
          new Promise((resolve, reject) => {
            firebaseStorage
              .uploadImage(uri)
              .then((response) => {
                if (response.downloadURL) {
                  photoUrls.push(response.downloadURL);
                }
                resolve();
              });
          })
        );
      }
    });
    console.log("Selected Item: ", this.props.selectedItem.id)
    let edit = this.props.selectedItem


    // Promise.all(uploadPromiseArray)
    //   .then((values) => {
    const uploadObject = {
      is_approved: !ServerConfiguration.isApprovalProcessEnabled,
      user_id: formattedUser.id,
      name: self.state.title,
      oppotunity: self.state.oppotunity,
      category: self.state.category,
      price: self.state.price,
      finishTimer: self.state.endTime,
      startTimer: self.state.startTime,
      discountRate: self.state.discountRate,
      // category_id: self.state.category.id,
      description: self.state.description,
      latitude: self.state.location.latitude,
      longitude: self.state.location.longitude,
      // mapping: self.state.filter,
      coordinate: new firebase.firestore.GeoPoint(
        self.state.location.latitude,
        self.state.location.longitude
      ),
      phone_num: formattedUser.phoneNumber,
      num_of_oppot: Number(self.state.oppotunity),
      post_time: firebase.firestore.FieldValue.serverTimestamp(),
      createdAt: firebase.firestore.FieldValue.serverTimestamp(),
      // TODO:
      // place: location.formattedAddress,
      cover_photo: photoUrls.length > 0 ? photoUrls[0] : null,
      list_of_photos: photoUrls,
      aboutResturant: self.props.user.aboutResturant,
    };
    const listingRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);

    console.log("Editing: ", edit.id)
    if (edit) {
      console.log("Editing: ", edit.id)
      listingRef
        .doc(edit.id)
        .update({ ...uploadObject, cover_photo: photoUrls[0] })
        .then(function (docRef) {
          onCancel();
        })
        .catch(function (error) {
          alert(error);
        });
    } else {
      listingRef
        .add(uploadObject)
        .then(function (docRef) {
          if (docRef.id) {
            listingRef
              .doc(docRef.id)
              .update({ id: docRef.id, cover_photo: photoUrls[0] });
          }
          self.setState(
            { loading: false },
            () => {
              onCancel();
            }
          );
        })
        .catch(function (error) {
          alert(error);
        });
    }
    // })
    // .catch((reason) => {
    //   // console.log('reason', reason);
    // });
  };

  showActionSheet = (index) => {
    this.setState({
      selectedPhotoIndex: index,
    });
    this.ActionSheet.show();
  };

  onActionDone = (index) => {
    if (index == 0) {
      const array = [...this.state.localPhotos];
      array.splice(this.state.selectedPhotoIndex, 1);
      this.setState({ localPhotos: array });
    }
  };

  // onConfirmStart(hour, minute) {
  //   this.setState({startTimer: `${hour}:${minute}`});
  //   this.startTimePicker.close();
  // }

  // onConfirmFinsh(hour, minute) {
  //   this.setState({finishTimer: `${hour}:${minute}`});
  //   this.finishTimePicker.close();
  // }

  // renderStartTimePicker = () => {
  //   return (
  //     <TimePicker
  //       onCancel={() => this.onCancel()}
  //       onConfirm={(hour, minute) => this.onConfirmStart(hour, minute)}
  //       ref={(ref) => {
  //         this.startTimePicker = ref;
  //       }}
  //     />
  //   );
  // }

  // renderFinishTimePicker = () => {
  //   return (
  //     <TimePicker
  //       onCancel={() => this.onCancel()}
  //       onConfirm={(hour, minute) => this.onConfirmFinsh(hour, minute)}
  //       ref={(ref) => {
  //         this.finishTimePicker = ref;
  //       }}
  //     />
  //   );
  // }

  // renderTimePickerText = () => {
  //   const {startTimer, finishTimer} = this.state;

  //   return (
  //     <View style={{flexDirection: 'row', justifyContent: 'space-around'}}>
  //       <TouchableOpacity
  //         onPress={() => this.startTimePicker.open()}
  //         style={styles.timePicker}
  //       >
  //         <Text style={styles.buttonText}>Open Time</Text>
  //         <Text style={styles.buttonText}>{startTimer}</Text>
  //       </TouchableOpacity>
  //       <TouchableOpacity
  //         onPress={() => this.finishTimePicker.open()}
  //         style={styles.timePicker}
  //       >
  //         <Text style={styles.buttonText}>Close Time</Text>
  //         <Text style={styles.buttonText}>{finishTimer}</Text>
  //       </TouchableOpacity>
  //     </View>
  //   );
  // }

  render() {
    const { title, oppotunity, discountRate, category, description, about } = this.state;
    const categoryData = this.state.categories.map((category, index) => ({
      key: category.id,
      label: category.name,
    }));
    categoryData.unshift({ key: 'section', label: 'Category', section: true });

    const photos = this.state.localPhotos.map((photo, index) => (
      <TouchableOpacity
        key={index}
        onPress={() => {
          this.showActionSheet(index);
        }}
      >
        <FastImage
          source={{ uri: photo }}
          style={styles.photo}
        />
      </TouchableOpacity>
    ));

    return (
      <Modal
        animationType="slide"
        onRequestClose={this.onCancel}
        transparent={false}
        visible={this.props.isVisible}
      >
        <View style={ModalHeaderStyle.bar}>
          <Text style={ModalHeaderStyle.title}>Add Listing</Text>
          <TextButton
            onPress={this.onCancel}
            style={[ModalHeaderStyle.rightButton, styles.rightButton]}
          >
            Cancel
          </TextButton>
        </View>
        <ScrollView style={styles.body}>
          <View style={styles.section}>
            <TextInput
              onChangeText={(text) => this.setState({ title: text })}
              placeholder="Title"
              placeholderTextColor={AppStyles.color.grey}
              style={styles.input}
              underlineColorAndroid="transparent"
              value={title}
            />
          </View>
          {/* <View style={styles.divider} /> */}
          <View style={styles.section}>
            <TextInput
              keyboardType="numeric"
              onChangeText={(text) => this.setState({ oppotunity: text })}
              placeholder="Oppotunity"
              placeholderTextColor={AppStyles.color.grey}
              style={styles.input}
              underlineColorAndroid="transparent"
              value={oppotunity}
            />
          </View>
          {/* <View style={styles.divider} /> */}
          <View style={styles.section}>
            <TextInput
              onChangeText={(text) => this.setState({ category: text })}
              placeholder="General Category - Ex:-bakery or steak house"
              placeholderTextColor={AppStyles.color.grey}
              style={styles.input}
              underlineColorAndroid="transparent"
              value={category}
            />
          </View>
          <View style={styles.section}>
            <TextInput
              keyboardType="numeric"
              onChangeText={(text) => this.setState({ price: text })}
              placeholder="Price - Ex:- ₺1000"
              placeholderTextColor={AppStyles.color.grey}
              style={styles.input}
              underlineColorAndroid="transparent"
              value={this.state.price}
            />
            {/* {this.renderTimePickerText()} */}
            <View style={styles.section}>
              <TextInput
                onChangeText={(text) => this.setState({ discountRate: text })}
                placeholder="Discount Rate - Ex: - 30"
                placeholderTextColor={AppStyles.color.grey}
                style={styles.input}
                underlineColorAndroid="transparent"
                value={discountRate}
              />
            </View>
            <View style={styles.section}>
              <TextInput
                onChangeText={(text) => this.setState({ startTime: text })}
                placeholder="Start Time - Ex: - 12:30"
                placeholderTextColor={AppStyles.color.grey}
                style={styles.input}
                underlineColorAndroid="transparent"
                value={this.state.startTime}
              />
            </View>
            <View style={styles.section}>
              <TextInput
                onChangeText={(text) => this.setState({ endTime: text })}
                placeholder="End Time - Ex: - 12:30"
                placeholderTextColor={AppStyles.color.grey}
                style={styles.input}
                underlineColorAndroid="transparent"
                value={this.state.endTime}
              />
            </View>
            <View style={styles.section}>
              <TextInput
                multiline
                numberOfLines={2}
                onChangeText={(text) => this.setState({ description: text })}
                placeholder="Short Description about the offer"
                placeholderTextColor={AppStyles.color.grey}
                style={styles.input}
                underlineColorAndroid="transparent"
                value={description}
              />
            </View>
            {/* {this.renderStartTimePicker()}
            {this.renderFinishTimePicker()} */}
            {/* <ModalSelector
              backdropPressToClose
              cancelContainerStyle={ModalSelectorStyle.cancelContainerStyle}
              cancelText="Cancel"
              cancelTextStyle={ModalSelectorStyle.cancelTextStyle}
              data={categoryData}
              initValue={this.state.category.name}
              onChange={(option) => {
                this.setState((prevState) => ({
                  category: {id: option.key, name: option.label},
                  filterValue:
                    prevState.category.id === option.key
                      ? this.state.filterValue
                      : 'Select...',
                  filter:
                    prevState.category.id === option.key
                      ? this.state.filter
                      : {},
                }));
              }}
              optionContainerStyle={ModalSelectorStyle.optionContainerStyle}
              optionTextStyle={ModalSelectorStyle.optionTextStyle}
              sectionTextStyle={ModalSelectorStyle.sectionTextStyle}
              selectedItemTextStyle={ModalSelectorStyle.selectedItemTextStyle}
              touchableActiveOpacity={0.9}
            >
              <View style={styles.row}>
                <Text style={styles.title}>Category</Text>
                <Text style={styles.value}>{this.state.category.name}</Text>
              </View>
            </ModalSelector> */}
            {/* <TouchableOpacity onPress={this.selectFilter}>
              <View style={styles.row}>
                <Text style={styles.title}>Filters</Text>
                <Text style={styles.value}>{this.state.filterValue}</Text>
              </View>
            </TouchableOpacity>*/}
            {/* <TouchableOpacity onPress={this.selectLocation}>
              <View style={styles.row}>
                <Text style={styles.title}>Location</Text>
                <View style={styles.location}>
                  <Text style={styles.value}>{this.state.address}</Text>
                </View>
              </View>
            </TouchableOpacity> */}
            <Text style={styles.addPhotoTitle}>Add Photos</Text>
            <ScrollView
              horizontal
              style={styles.photoList}
            >
              {photos}
              <TouchableOpacity onPress={this.onPressAddPhotoBtn.bind(this)}>
                <View style={[styles.addButton, styles.photo]}>
                  <Image
                    source={cameraIcon}
                    style={{ width: 55, height: 30 }}
                  />
                  {/* <Icon
                    color="white"
                    name="camera"
                    size={30}
                  /> */}
                </View>
              </TouchableOpacity>
            </ScrollView>
          </View>
          {/* {this.state.filterModalVisible && (
            <FilterViewModal
              category={this.state.category}
              onCancel={this.onSelectFilterCancel}
              onDone={this.onSelectFilterDone}
              value={this.state.filter}
            />
          )} */}
          {/* {this.state.locationModalVisible && (
            <SelectLocationModal
              location={this.state.location}
              onCancel={this.onSelectLocationCancel}
              onDone={this.onSelectLocationDone}
            />
          )} */}
        </ScrollView>
        {this.state.loading ? (
          <View style={styles.activityIndicatorContainer}>
            <ActivityIndicator
              color={AppStyles.color.main}
              size="large"
            />
          </View>
        ) : (
            <LinearGradient
              colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
              style={styles.signupContainer}
            >
              {/* <TextButton
            containerStyle={styles.addButtonContainer}
            onPress={this.onPost}
            style={styles.signupText}
            >
              Post Listing
          </TextButton> */}
              <TouchableOpacity
                containerStyle={styles.signupContainer}
                onPress={this.handlePost}
                style={styles.signupText}
                title="SAVE"
              >
                <Text style={styles.signupText}>SAVE</Text>
              </TouchableOpacity>
            </LinearGradient>
          )}
        <ActionSheet
          cancelButtonIndex={1}
          destructiveButtonIndex={0}
          onPress={(index) => {
            this.onActionDone(index);
          }}
          options={['Confirm', 'Cancel']}
          ref={(o) => (this.ActionSheet = o)}
          title="Confirm to delete?"
        />
      </Modal>
    );
  }
}

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(PostModal);
