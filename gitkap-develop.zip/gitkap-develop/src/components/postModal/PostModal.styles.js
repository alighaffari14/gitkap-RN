// @flow
import {StyleSheet, I18nManager} from 'react-native';
import colors from '../../shared/colors';
import {AppStyles} from '../../AppStyles';
import metrics from '../../shared/metrics';

const style = StyleSheet.create({
  activityIndicatorContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
    width: '100%',
  },
  addButton: {
    alignItems: 'center',
    // backgroundColor: AppStyles.color.tint,
    justifyContent: 'center',
  },
  addButtonContainer: {
    backgroundColor: AppStyles.color.tint,
    borderRadius: 5,
    margin: 10,
    marginVertical: 27,
    padding: 15,
  },
  addButtonText: {
    color: AppStyles.color.white,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 15,
    fontWeight: 'bold',
  },
  addPhotoTitle: {
    color: colors.gray,
    fontFamily: AppStyles.fontName.bold,
    fontSize: metrics.fonts.xSmall,
    fontWeight: 'bold',
    margin: 10,
    paddingLeft: 10,
  },
  body: {
    backgroundColor: AppStyles.color.white,
    flex: 1,
  },
  container: {
    alignItems: 'center',
    borderBottomColor: AppStyles.color.grey,
    borderBottomWidth: 1,
    flexDirection: 'row',
    height: 65,
    justifyContent: 'center',
  },
  divider: {
    backgroundColor: AppStyles.color.background,
    height: 10,
  },
  input: {
    alignItems: 'center',
    alignSelf: 'center',
    borderColor: colors.lightGray,
    borderRadius: 5,
    borderWidth: 1,
    color: colors.gray,
    height: 52,
    marginTop: 20,
    paddingLeft: 20,
    textAlign: I18nManager.isRTL ? 'right' : 'left',
    width: '90%',
  },
  location: {
    alignItems: 'center',
    width: '50%',
  },
  photo: {
    borderRadius: 10,
    height: 70,
    marginLeft: 20,
    width: 70,
  },
  photoIcon: {
    height: 50,
    width: 50,
  },
  photoList: {
    height: 70,
    marginRight: 10,
    marginTop: 20,
  },
  priceInput: {
    borderColor: AppStyles.color.grey,
    borderRadius: 5,
    borderWidth: 0.5,
    color: AppStyles.color.text,
    flex: 1,
    fontFamily: AppStyles.fontName.main,
    height: 40,
    paddingRight: 5,
    textAlign: 'right',
  },
  rightButton: {
    marginRight: 10,
  },
  row: {
    alignItems: 'center',
    flexDirection: 'row',
    height: 50,
    paddingLeft: 10,
    paddingRight: 10,
  },
  section: {
    backgroundColor: colors.white,
    marginBottom: 10,
  },
  sectionTitle: {
    alignItems: 'center',
    color: AppStyles.color.title,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 19,
    fontWeight: 'bold',
    padding: 10,
    paddingBottom: 7,
    paddingTop: 15,
    textAlign: 'left',
    // borderBottomWidth: 2,
    // borderBottomColor: AppStyles.color.grey
  },

  signupContainer: {
    alignItems: 'center',
    alignSelf: 'center',
    backgroundColor: colors.darkOrange,
    borderRadius: metrics.radius.medium,
    height: 49,
    justifyContent: 'center',
    // marginTop: 50,
    margin: 10,
    // padding: 10,
    width: 178,
  },
  signupText: {
    // backgroundColor: colors.darkOrange,
    color: colors.white,
  },
  timePicker: {
    alignItems: 'center',
    alignSelf: 'center',
    borderColor: colors.lightGray,
    borderRadius: 5,
    borderWidth: 1,
    color: colors.gray,
    height: 52,
    justifyContent: 'center',
    marginTop: 20,
    paddingLeft: 20,
    textAlign: I18nManager.isRTL ? 'right' : 'left',
    width: '40%',
  },
  title: {
    alignItems: 'center',
    color: AppStyles.color.title,
    flex: 2,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 19,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  value: {
    color: AppStyles.color.description,
    fontFamily: AppStyles.fontName.main,
    textAlign: 'right',
  },
});

export default style;
