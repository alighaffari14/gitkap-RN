import React, { Component } from 'react';
import {
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Linking,
  Modal,
  StyleSheet,
  BackHandler
} from 'react-native';
import TextButton from 'react-native-button';
import { AppStyles } from '../AppStyles';

export default class ContactModal extends Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Contact Us',
    headerLeft: null,
    headerRight: (
      <TextButton
        style={[styles.rightButton]}
        onPress={() => navigation.goBack()}
      >
        Cancel
      </TextButton>
    )
  });

  constructor(props) {
    super(props);
    this.state = {};

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      payload =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      payload =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  render() {
    return (
      <View style={styles.container}>
        <ScrollView style={styles.body}>
          <View style={styles.labelView}>
            <Text style={styles.label}>CONTACT</Text>
          </View>
          <View style={styles.contentView}>
            <View style={styles.addressView}>
              <Text style={[styles.text, { paddingBottom: 4 }]}>
                Our address
              </Text>
              <Text style={styles.textcaption}>
                1412 Steiner Street, San Francisco, CA, 94115
              </Text>
            </View>
            <View style={styles.divider} />
            <View style={styles.itemView}>
              <Text style={styles.text}>E-mail us</Text>
              <Text style={styles.placeholderText}>
                {'office@listing.com >'}
              </Text>
            </View>
          </View>
          <View style={styles.captionView}>
            <Text style={styles.caption}>
              {'Our business hours are Mon - Fri, 10am - 5pm, PST.\n'}
            </Text>
          </View>
          <View style={styles.contentView}>
            <TouchableOpacity
              onPress={() => Linking.openURL(`tel:${11234567890}`)}
              style={styles.itemButton}
            >
              <Text style={[styles.text, { color: AppStyles.color.main }]}>
                Call Us
              </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.labelView} />
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#efeff4'
  },
  rightButton: {
    marginRight: 10,
    color: AppStyles.color.main
  },
  body: {
    width: '100%'
  },
  labelView: {
    width: '100%',
    height: 60,
    padding: 10,
    justifyContent: 'flex-end',
    alignItems: 'flex-start'
  },
  captionView: {
    width: '100%',
    padding: 10,
    justifyContent: 'flex-start',
    alignItems: 'flex-start'
  },
  contentView: {
    width: '100%',
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#cccccc',
    backgroundColor: '#ffffff'
  },
  itemView: {
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10
  },
  addressView: {
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 10
  },
  itemButton: {
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10
  },
  text: {
    fontSize: 16
  },
  textcaption: {
    fontSize: 13
  },
  divider: {
    height: 0.5,
    width: '96%',
    alignSelf: 'flex-end',
    backgroundColor: '#e0e0e0'
  },
  placeholderText: {
    fontSize: 18,
    color: '#cccccc'
  },
  label: {
    fontSize: 14,
    color: AppStyles.color.text
  },
  caption: {
    fontSize: 13,
    color: AppStyles.color.subtitle
  }
});
