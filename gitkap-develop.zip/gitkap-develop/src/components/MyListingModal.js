import React from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  BackHandler,
  Alert,
} from 'react-native';
import TextButton from 'react-native-button';
import firebase from 'react-native-firebase';
import { connect } from 'react-redux';
import FastImage from 'react-native-fast-image';
import StarRating from 'react-native-star-rating';
import ActionSheet from 'react-native-actionsheet';
import SavedButton from './SavedButton';
import PostModal from '../components/postModal/PostModal';
import ServerConfiguration from '../ServerConfiguration';
import { AppStyles, AppIcon, TwoColumnListStyle } from '../AppStyles';
import { Configuration } from '../Configuration';

class MyListingModal extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'My Listings',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={styles.rightButton}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);

    this.state = {
      listings: [],
      savedListings: [],
      selectedItem: null,
      postModalVisible: false,
      categories: [],
    };

    this.listingItemActionSheet = React.createRef();

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);

    this.savedListingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
      .where('user_id', '==', this.props.user && this.props.user.id);
    this.categoriesRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CATEGORIES);
  }

  componentDidMount() {
    this.savedListingsUnsubscribe = this.savedListingsRef.onSnapshot(
      this.onSavedListingsCollectionUpdate
    );

    this.listingsUnsubscribe = this.listingsRef
      .where('user_id', '==', this.props.user && this.props.user.id)
      .where('is_approved', '==', true)
      .onSnapshot(this.onListingsCollectionUpdate);

    this.categoriesUnsubscribe = this.categoriesRef.onSnapshot(
      this.onCategoriesCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    if (this.listingsUnsubscribe) {
      this.listingsUnsubscribe();
    }

    if (this.savedListingsUnsubscribe) {
      this.savedListingsUnsubscribe();
    }

    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onSavedListingsCollectionUpdate = (querySnapshot) => {
    const savedListingdata = [];
    querySnapshot.forEach((doc) => {
      const savedListing = doc.data();
      savedListingdata.push(savedListing.listing_id);
    });

    this.setState({
      savedListings: savedListingdata,
    });
  };

  onCategoriesCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const category = doc.data();
      data.push({ ...category, id: doc.id });
    });
    this.setState({
      categories: data,
    });
  };

  onListingsCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      if (this.state.savedListings.findIndex((k) => k == doc.id) >= 0) {
        listing.saved = true;
      } else {
        listing.saved = false;
      }
      data.push({ ...listing, id: doc.id });
    });

    this.setState({
      listings: data,
      loading: false,
    });
  };

  onPressListingItem = (item) => {
    this.props.navigation.navigate('Detail', { item: item, userData: this.props.user, favEnable: true });
  };

  onLongPressListingItem = (item) => {
    if (item.user_id === this.props.user.id && this.props.user.id) {
      this.setState({ selectedItem: item }, () => {
        this.listingItemActionSheet.current.show();
      });
    }
  };

  onLisingItemActionDone = (index) => {
    if (index == 0) {
      this.setState({
        postModalVisible: true,
      });
    }

    if (index == 1) {
      Alert.alert(
        'Delete Listing',
        'Are you sure you want to remove this listing?',
        [
          {
            text: 'Yes',
            onPress: this.removeListing,
            style: 'destructive',
          },
          { text: 'No' },
        ],
        { cancelable: false }
      );
    }
  };

  removeListing = () => {
    const self = this;

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(self.state.selectedItem.id)
      .delete()
      .then(function () {
        const realEstateSavedQuery = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
          .where('listing_id', '==', self.state.selectedItem.id);
        realEstateSavedQuery.get().then(function (querySnapshot) {
          querySnapshot.forEach(function (doc) {
            doc.ref.delete();
          });
        });
        alert('The listing was successfully deleted.');
      })
      .catch(function (error) {
        alert('Oops! an error while deleting listing. Please try again later.');
      });
  };

  onPostCancel = () => {
    this.setState({ postModalVisible: false });
  };

  onPressSavedIcon = (item) => {
    if (item.saved) {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('listing_id', '==', item.id)
        .where('user_id', '==', this.props.user && this.props.user.id)
        .get()
        .then(function (querySnapshot) {
          querySnapshot.forEach(function (doc) {
            doc.ref.delete();
          });
        });
    } else {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .add({
          user_id: this.props.user && this.props.user.id,
          listing_id: item.id,
        })
        .then(function (docRef) { })
        .catch(function (error) {
          alert(error);
        });
    }
  };

  renderListingItem = ({ item }) => {
    return (
      <TouchableOpacity
        onLongPress={() => this.onLongPressListingItem(item)}
        onPress={() => this.onPressListingItem(item)}
      >
        <View style={TwoColumnListStyle.listingItemContainer}>
          <FastImage
            source={{ uri: item.cover_photo }}
            style={TwoColumnListStyle.listingPhoto}
          />
          <SavedButton
            item={item}
            onPress={() => this.onPressSavedIcon(item)}
            style={TwoColumnListStyle.savedIcon}
          />
          <Text
            numberOfLines={1}
            style={TwoColumnListStyle.listingName}
          >
            {item.name}
          </Text>
          <Text style={TwoColumnListStyle.listingPlace}>{item.place}</Text>
          <StarRating
            containerStyle={styles.starRatingContainer}
            disabled
            emptyStar={AppIcon.images.starNoFilled}
            fullStar={AppIcon.images.starFilled}
            maxStars={5}
            rating={item.starCount}
            starSize={15}
            starStyle={styles.starStyle}
          />
        </View>
      </TouchableOpacity>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <FlatList
          data={this.state.listings}
          keyExtractor={(item) => `${item.id}`}
          numColumns={2}
          renderItem={this.renderListingItem}
          showsVerticalScrollIndicator={false}
          vertical
        />
        {this.state.postModalVisible && (
          <PostModal
            categories={this.state.categories}
            onCancel={this.onPostCancel}
            selectedItem={this.state.selectedItem}
          />
        )}
        <ActionSheet
          cancelButtonIndex={2}
          destructiveButtonIndex={1}
          onPress={(index) => {
            this.onLisingItemActionDone(index);
          }}
          options={['Edit Listing', 'Remove Listing', 'Cancel']}
          ref={this.listingItemActionSheet}
          title="Confirm"
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    padding: Configuration.home.listing_item.offset,
  },
  rightButton: {
    color: AppStyles.color.main,
    marginRight: 10,
  },
  starRatingContainer: {
    marginTop: 10,
    width: 90,
  },
  starStyle: {
    tintColor: AppStyles.color.tint,
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(MyListingModal);
