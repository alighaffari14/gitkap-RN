// @flow
import {StyleSheet, Dimensions} from 'react-native';
import {AppStyles} from '../../AppStyles';
import colors from '../../shared/colors';

const {width: viewportWidth} = Dimensions.get('window');

const style = StyleSheet.create({
  aboutText: {
    fontSize: 18,
  },
  aboutWrapper: {
    marginVertical: 20,

  },
  addToFavouriteWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  addressWrapper: {
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    width: viewportWidth - 70,
  },
  backIcon: {
    height: 20,
    width: 20,
  },
  border: {
    backgroundColor: colors.darkOrange,
    borderColor: colors.darkOrange,
    borderWidth: 2,
    width: 60,
  },
  callIcon: {
    height: 25, width: 25,
  },
  contactDescription: {
    alignSelf: 'center',
    color: colors.gray, marginBottom: 40,
    width: viewportWidth - 70,
  },
  contactHeaderWrapper: {
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 20,
    width: viewportWidth - 70,
  },
  container: {
    backgroundColor: colors.lightGray,
    flex: 1,
  },
  description: {
    color: AppStyles.color.description,
    fontFamily: AppStyles.fontName.bold,
    padding: 10,
  },
  detail: {
    flex: 1,
    paddingLeft: 10,
  },
  extra: {
    padding: 30,
    paddingTop: 10,
    paddingBottom: 0,
    marginBottom: 30,
  },
  extraKey: {
    color: AppStyles.color.title,
    flex: 2,
    fontWeight: 'bold',
  },
  extraRow: {
    flexDirection: 'row',
    paddingBottom: 10,
  },
  extraValue: {
    color: '#bcbfc7',
    flex: 1,
  },
  favMarkerIcon: {
    height: 35,
    width: 35,
  },
  favouriteIcon: {
    height: 25,
    width: 25,
  },
  headerIcon: {
    height: 17,
    tintColor: AppStyles.color.tint,
    width: 17,
  },
  headerIconContainer: {
    // padding: 6,
  },
  horizontalLine: {
    alignSelf: 'center',
    borderColor: colors.xlightGray,
    borderWidth: 1,
    width: viewportWidth - 70,
  },
  imageIcon: {
    height: 25, width: 25,
  },
  info: {
    flexDirection: 'row',
  },
  innerContainer: {
    alignSelf: 'center',
    width: viewportWidth - 70,
  },
  intro: {
    color: colors.gray, marginVertical: 20,
  },
  loadingMap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapView: {
    height: 200,
    width: '100%',
    // backgroundColor: AppStyles.color.grey
  },
  offerInfo: {
    flexDirection: 'row',
  },
  offerText: {
    fontSize: 18, fontWeight: 'bold',
  },
  paginationContainer: {
    alignSelf: 'center',
    flex: 1,
    marginTop: 220,
    paddingVertical: 8,
    position: 'absolute',
  },
  paginationDot: {
    borderRadius: 0,
    height: 4,
    width: 40,
  },
  photoItem: {
    backgroundColor: AppStyles.color.grey,
    height: 250,
    width: '100%',
  },
  ratedForResturant: {
    fontSize: 18, fontWeight: 'bold',
  },
  reviewContent: {
    color: AppStyles.color.title,
    marginTop: 10,
  },
  reviewItem: {
    marginLeft: 10,
    padding: 10,
  },
  reviewTime: {
    color: '#bcbfc7',
    fontSize: 12,
  },
  reviewTitle: {
    paddingTop: 0,
  },
  starImage: {
    height: 18, marginHorizontal: 5, width: 18,
  },
  starRatingContainer: {
    padding: 10,
  },
  starStyle: {
    tintColor: AppStyles.color.tint,
  },
  title: {
    color: AppStyles.color.title,
    fontFamily: AppStyles.fontName.bold,
    fontSize: 25,
    fontWeight: 'bold',
    padding: 10,
  },
  userPhoto: {
    // borderRadius: 22,
    height: 28,
    width: 28,
  },
  username: {
    color: AppStyles.color.title,
    fontWeight: 'bold',
  },
});

export default style;
