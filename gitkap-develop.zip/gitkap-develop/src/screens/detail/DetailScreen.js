import React from 'react';
import {
  Dimensions,
  ScrollView,
  TouchableOpacity,
  Text,
  View,
  Alert,
  BackHandler,
  Image,
  FlatList,
  ActivityIndicator
} from 'react-native';
import firebase from 'react-native-firebase';
import FastImage from 'react-native-fast-image';
import Carousel, { Pagination } from 'react-native-snap-carousel';
import { connect } from 'react-redux';
import TextButton from 'react-native-button';
import call from 'react-native-phone-call';
import Modal from 'react-native-modal';

import HeaderButton from '../../components/HeaderButton';
import ReviewModal from '../../components/ReviewModal';
import ServerConfiguration from '../../ServerConfiguration';
import TopActionBar from '../../components/topActionBar/TopActionBar.component';

import colors from '../../shared/colors';
import { AppStyles, AppIcon, HeaderButtonStyle } from '../../AppStyles';
import styles from './Details.styles';

import backIcon from '../../../assets/icons/back.png';
import mapIcon from '../../../assets/icons/mapIconProfile.png';
import DiscountPanelComponent from '../../components/discountPanel/DiscountPanel.component';
import SearchLocationComponent from '../../components/searchLocation/SearchLocation.component';

// const heartIcon = require('../../../assets/icons/heart.png');
const callIcon = require('../../../assets/icons/phoneCall.png');
const star = require('../../../assets/icons/star.png');
const marker = require('../../../assets/icons/marker.png');
const unMarker = require('../../../assets/icons/Unmarker.png');

const { width: viewportWidth } = Dimensions.get('window');

class DetailsScreen extends React.PureComponent<any, any> {
  // static navigationOptions = ({navigation}) => {
  static navigationOptions = ({ navigation }) => ({
    header: null,
    headerLeft: null,
    headerRight: null,
  });

  constructor(props) {
    super(props);

    const { navigation } = props;
    const item = navigation.getParam('item');
    const userData = navigation.getParam('userData');
    const favEnable = navigation.getParam('favEnable');
    // console.log('item', item);

    // const userData = navigation.getParam('userData');

    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);

    this.listFavourite = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.FAVOURITE);

    this.ref = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(item.id);
    this.unsubscribe = null;
    this.restaurantDetails = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CATEGORIES)
      .where('id', '==', item.category_id);
    this.reviewsUnsubscribe = null;
    this.userDataSubscribe = null;

    this.savedListingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
      .where('user_id', '==', userData.id)
      .where('listing_id', '==', item.id);
    this.channelPaticipationRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNEL_PARTICIPATION)
      .where('user', '==', userData.id);
    this.channelsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNELS)
      .orderBy('lastMessageDate', 'desc');

    // this.listingRef = firebase
    //   .firestore()
    //   .collection(ServerConfiguration.database.collection.LISTINGS);

    this.channelPaticipationUnsubscribe = null;
    this.channelsUnsubscribe = null;
    this.savedListingUnsubscribe = null;

    this.state = {
      activeSlide: 0,
      data: item ? item : {},
      photo: item.photo,
      reviews: [],
      saved: false,
      user: {},
      channels: [],
      channelParticipations: [],
      reviewModalVisible: false,
      isProfileModalVisible: false,
      didFinishAnimation: false,
      resturantData: [],
      user: userData,
      favEnable: favEnable,
      userData,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.props.navigation.setParams({
      onDelete: this.onDelete,
      onPressReview: this.onPressReview,
      onPressSave: this.onPressSave,
      saved: this.state.saved,
      onPersonalMessage: this.onPersonalMessage,
      onProfileModal: this.onProfileModal,
      isAdmin: this.props.isAdmin,
      isUser: this.state.user.id === this.state.data.user_id,
      headerLeft: this.getBackButton(),
    });

    // setTimeout(() => {
    //   this.setState({didFinishAnimation: true});
    // }, 500);

    this.upDateUserInfo();
    this.unsubscribe = this.ref.onSnapshot(this.onDocUpdate);
    this.reviewsUnsubscribe = this.restaurantDetails.onSnapshot(this.onResturantUpdate);
    this.savedListingsUnsubscribe = this.savedListingsRef.onSnapshot(this.onSavedListingsCollectionUpdate);
    this.channelPaticipationUnsubscribe = this.channelPaticipationRef.onSnapshot(
      this.onChannelParticipationCollectionUpdate
    );
    this.channelsUnsubscribe = this.channelsRef.onSnapshot(
      this.onChannelCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.unsubscribe();
    this.reviewsUnsubscribe();
    this.savedListingsUnsubscribe();
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    const customLeft = this.props.navigation.getParam('customLeft');
    const routeName = this.props.navigation.getParam('routeName');

    if (customLeft) {
      this.props.navigation.navigate(routeName);
    } else {
      this.props.navigation.goBack();
    }

    return true;
  };

  getBackButton = () => {
    const customLeft = this.props.navigation.getParam('customLeft');
    const routeName = this.props.navigation.getParam('routeName');

    if (customLeft) {
      return (
        <TextButton
          onPress={() => {
            this.setState({ didFinishAnimation: false }, () => {
              this.props.navigation.navigate(routeName);
            });
          }}
          style={{ marginLeft: 10, color: AppStyles.color.main }}
        >
          Cancel
        </TextButton>
      );
    }
  };

  onChannelParticipationCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const user = doc.data();
      user.id = doc.id;

      if (user.id != this.state.user.id) {
        data.push(user);
      }
    });

    const channels = this.state.channels.filter((channel) => {
      return (
        data.filter((participation) => channel.id == participation.channel)
          .length > 0
      );
    });

    this.setState({
      channels: channels,
      channelParticipations: data,
    });

    if (this.channelsUnsubscribe) {
      this.channelsUnsubscribe();
    }
    this.channelsUnsubscribe = this.channelsRef.onSnapshot(
      this.onChannelCollectionUpdate
    );
  };

  onChannelCollectionUpdate = (querySnapshot) => {
    const data = [];
    const channelPromiseArray = [];
    querySnapshot.forEach((doc) => {
      channelPromiseArray.push(
        new Promise((channelResolve, channelReject) => {
          const channel = doc.data();
          channel.id = doc.id;
          channel.participants = [];
          const filters = this.state.channelParticipations.filter(
            (item) => item.channel == channel.id
          );
          if (filters.length > 0) {
            firebase
              .firestore()
              .collection(
                ServerConfiguration.database.collection.CHANNEL_PARTICIPATION
              )
              .where('channel', '==', channel.id)
              .onSnapshot((participationSnapshot) => {
                const userPromiseArray = [];
                participationSnapshot.forEach((participationDoc) => {
                  const participation = participationDoc.data();
                  participation.id = participationDoc.id;
                  if (participation.user != this.state.user.id) {
                    userPromiseArray.push(
                      new Promise((userResolve, userReject) => {
                        firebase
                          .firestore()
                          .collection('users')
                          .doc(participation.user)
                          .get()
                          .then((user) => {
                            if (user.data()) {
                              const userData = user.data();
                              userData.id = user.id;
                              userData.participationId = participation.id;
                              channel.participants = [
                                ...channel.participants,
                                userData,
                              ];
                            }
                            userResolve();
                          });
                      })
                    );
                  }
                });
                Promise.all(userPromiseArray).then((values) => {
                  data.push(channel);
                  channelResolve();
                });
              });
          } else {
            channelResolve();
          }
        })
      );
    });

    Promise.all(channelPromiseArray).then((values) => {
      const sortedData = data.sort((a, b) => {
        return b.lastMessageDate - a.lastMessageDate;
      });

      this.setState(
        {
          channels: sortedData,
        },
        () => {
          this.props.navigation.setParams({
            chatReady: true,
          });
        }
      );
    });
  };

  upDateUserInfo = () => {
    const self = this;

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.USERS)
      .doc(self.state.data.user_id)
      .get()
      .then(function (userDoc) {
        self.setState({
          user: { ...userDoc.data(), id: userDoc.id },
        });
      });
  };

  onPersonalMessage = () => {
    const friend = this.state.user;
    const one2OneChannel = this.state.channels.filter((channel) => {
      return (
        channel.participants.length == 1 &&
        !channel.name &&
        channel.participants[0].id == friend.id
      );
    });
    let channel;
    const channelName = friend.firstName ? friend.firstName : friend.fullname;
    if (one2OneChannel.length > 0) {
      channel = one2OneChannel[0];
    } else {
      channel = {
        name: channelName ? channelName : '',
        id: null,
        participants: [friend],
      };
    }

    if (channelName) {
      this.props.navigation.navigate('PersonalMessage', { channel });
    } else {
      alert(
        '0ops! an error occured  while loading profile. This user profile may be incomplete.'
      );
    }
  };

  onDocUpdate = (doc) => {
    const listing = doc.data();

    this.setState({
      data: { ...listing, id: doc.id },
      loading: false,
    });
  };

  updateReviews = (reviews) => {
    this.setState({
      reviews: reviews,
    });
  };

  onReviewsUpdate = (querySnapshot) => {
    const data = [];
    const updateReviews = this.updateReviews;

    const state = this.state;
    querySnapshot.forEach((doc) => {
      const review = doc.data();

      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.USERS)
        .doc(review.user_id)
        .get()
        .then(function (userDoc) {
          data.push({ ...review, id: doc.id, name: userDoc.data().fullname });
          updateReviews(data);
        });
    });
  };

  onResturantUpdate = (querySnapshot) => {
    let savedResturantData = null;
    querySnapshot.forEach((doc) => {
      savedResturantData = doc.data();
    });

    this.setState({
      resturantData: savedResturantData,
    });
  }

  onSavedListingsCollectionUpdate = (querySnapshot) => {
    const savedListingdata = [];
    querySnapshot.forEach((doc) => {
      const savedListing = doc.data();
      savedListingdata.push(savedListing);
    });

    this.setState({
      saved: savedListingdata.length > 0,
    });

    this.props.navigation.setParams({
      saved: this.state.saved,
    });
  };

  onPressReview = () => {
    this.setState({ reviewModalVisible: true });
  };

  onDelete = () => {
    Alert.alert(
      'Delete Listing',
      'Are you sure you want to remove this listing?',
      [
        {
          text: 'Yes',
          onPress: this.removeListing,
          style: 'destructive',
        },
        { text: 'No' },
      ],
      { cancelable: false }
    );
  };

  handleBack = () => {
    this.props.navigation.goBack();
  }

  removeListing = () => {
    const self = this;
    const customLeft = this.props.navigation.getParam('customLeft');
    const routeName = this.props.navigation.getParam('routeName');

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(self.state.data.id)
      .delete()
      .then(function () {
        const realEstateSavedQuery = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
          .where('listing_id', '==', self.state.data.id);
        realEstateSavedQuery.get().then(function (querySnapshot) {
          querySnapshot.forEach(function (doc) {
            doc.ref.delete();
          });
        });
        alert('The listing was successfully deleted.');
        if (customLeft) {
          self.props.navigation.navigate(routeName);
        } else {
          self.props.navigation.goBack();
        }
      })
      .catch(function (error) {
        alert('Error deleting listing!');
      });
  };

  onReviewCancel = () => {
    this.setState({ reviewModalVisible: false });
  };

  onProfileModal = (isVisible) => {
    this.setState({ [isVisible]: !this.state[isVisible] });
  };

  onPressSave = () => {
    if (this.state.saved) {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('listing_id', '==', this.state.data.id)
        .where('user_id', '==', this.star.user.id)
        .get()
        .then(function (querySnapshot) {
          querySnapshot.forEach(function (doc) {
            doc.ref.delete();
          });
        });
    } else {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .add({
          user_id: this.star.user.id,
          listing_id: this.state.data.id,
        })
        .then(function (docRef) { })
        .catch(function (error) {
          alert(error);
        });
    }
  };

  renderItem = ({ item }) => {
    if (!item) {
      return null;
    }

    return (
      <TouchableOpacity>
        {item.startsWith('https://') ? (
          <FastImage
            resizeMode={FastImage.resizeMode.cover}
            source={{ uri: item }}
            style={styles.photoItem}
          />
        ) : (
            <FastImage
              resizeMode={FastImage.resizeMode.cover}
              source={{ uri: 'https//:' }}
              style={styles.photoItem}
            />
          )}
      </TouchableOpacity>
    );
  }

  renderSeparator = () => {
    return (
      <View
        style={{
          width: 10,
          height: '100%',
        }}
      />
    );
  };

  renderHorizontalCorousel = () => {
    const { activeSlide, data } = this.state;
    const SLIDE_WIDTH = Math.round(viewportWidth / 2.6);
    const ITEM_HORIZONTAL_MARGIN = 75;

    return (
      <View>
        <Carousel
          activeSlideAlignment="start"
          autoplay
          autoplayDelay={500}
          autoplayInterval={3000}
          data={this.state.data.list_of_photos}
          firstItem={0}
          inactiveSlideOpacity={1}
          // hasParallaxImages={true}
          inactiveSlideScale={0.5}
          itemWidth={viewportWidth}
          loop
          loopClonesPerSide={2}
          onSnapToItem={(index) => this.setState({ activeSlide: index })}
          ref={(c) => {
            this._slider1Ref = c;
          }}
          renderItem={this.renderItem}
          sliderWidth={viewportWidth}
        />
        <View>
          <Pagination
            activeDotIndex={activeSlide}
            carouselRef={this._slider1Ref}
            // containerStyle={styles.paginationContainer}
            dotColor={colors.darkOrange}
            dotsLength={this.state.data.list_of_photos.length}
            dotStyle={styles.paginationDot}
            inactiveDotColor={colors.gray}
            inactiveDotOpacity={0.4}
            inactiveDotScale={1}
            inactiveDotStyle={styles.paginationDot}
            tappableDots={!!this._slider1Ref}
          />
        </View>
      </View>
    );
  }

  headerLeft = () => {
    return (
      <TouchableOpacity
        onPress={this.handleBack}
      >
        <FastImage
          resizeMode={FastImage.resizeMode.contain}
          source={backIcon}
          style={styles.backIcon}
        />
      </TouchableOpacity>
    );
  }

  headerRight = () => {
    // const addIcon = this.props.user.type == INDIVIDUAL ? null : this.renderAddIcon();

    return (
      <View style={[HeaderButtonStyle.multi, { flex: 1, justifyContent: 'flex-end' }]}>
        {/* {addIcon} */}
        <HeaderButton
          customStyle={AppIcon.containerMapBtn}
          icon={AppIcon.images.map}
          onPress={() => {
            this.props.navigation.navigate('Map');
          }}
        />
      </View>
    );
  }

  handleCall = () => {
    const { data } = this.state;
    const args = {
      number: data && data.phone_num, // String value with the number to call
      prompt: true, // Optional boolean property. Determines if the user should be prompt prior to the call
    };

    if (data && data.phone_num) {
      // call(args).catch(console.error);
    } else {
      Alert.alert('No Phone Number is added');
    }
  }

  closeModal = () => {
    this.setState({
      modalVisible: false,
    });
  }

  handleMap = () => {
    const { data } = this.state;
    this.props.navigation.navigate('findMap', { from: 'fromDetail', latitude: data.coordinate._latitude, longitude: data.coordinate._longitude });
  }

  handleLook = () => {
    const { userData, data } = this.state;
    const formattedUser = JSON.parse(userData);

    const docRef = this.ref;
    docRef.get().then(function (thisDoc) {
      const numOfCurrentOpp = thisDoc['_data'].num_of_oppot;
      docRef.update({ num_of_oppot: numOfCurrentOpp - 1 });
    });
    this.setState({
      modalVisible: true,
    });
  }

  handleFavEnable = () => {
    const { userData, data } = this.state;
    // const formattedUser = JSON.parse(userData);
    const formattedUser = this.props.user

    const currentUserId = formattedUser.id;
    const itemId = data.id;
    const item = data;
    const favEnable = !this.state.favEnable;

    console.log("Favourite: ", currentUserId + itemId)

    const docRef = this.listFavourite.doc(currentUserId + itemId);
    const docListingRef = this.listingsRef.doc(itemId);

    docRef.get().then(function (thisDoc) {
      if (thisDoc.exists) {
        favEnable ? docRef.update({ userId: currentUserId, itemId, favEnable, itemName: item.name }) : docRef.delete();
      } else {
        favEnable ? docRef.set({ userId: currentUserId, itemId, favEnable, itemName: item.name }) : null;
      }
    });

    docListingRef.get().then(function (thisDoc) {
      if (thisDoc.exists) {
        const favEnableCount = thisDoc._data.favEnableCount;
        if (favEnable) {
          favEnableCount && favEnableCount >= 0 ? docListingRef.update({ favEnableCount: favEnableCount + 1 }) : docListingRef.update({ favEnableCount: 1 });
        } else {
          favEnableCount && favEnableCount >= 0 ? docListingRef.update({ favEnableCount: favEnableCount - 1 }) : docListingRef.update({ favEnableCount: 1 });
        }
      }
    });

    this.setState({
      favEnable: !this.state.favEnable,
    });
  }

  handleCloseModal = () => {
    this.closeModal();
  }

  renderTopActionBar = () => {
    return (
      <View>
        <TopActionBar
          leftAction={this.headerLeft()}
          rightAction={null}
          title="Catch The Opportunity"
        />
      </View>
    );
  }

  renderDiscountPanel = () => {
    const { data } = this.state;

    return (
      <DiscountPanelComponent
        data={data}
        onLook={this.handleLook}
      />
    );
  }

  renderContactHeader = () => {
    const { resturantData, data, user } = this.state;

    return (
      <View style={styles.contactHeaderWrapper}>
        <TouchableOpacity onPress={this.onPressReview} style={styles.offerInfo}>
          <Text style={styles.offerText}>{user.name}</Text>
          {/* <Text style={styles.ratedForResturant}>{4.9}</Text> */}
          <Image
            source={star}
            style={styles.starImage}
          />
          <Text style={{ color: colors.gray }}> ({data.favEnableCount})</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={this.handleCall}
        >
          {/* <Text style={{color: colors.gray}}> (232)</Text> */}
          <Image
            source={callIcon}
            style={styles.callIcon}
          />
        </TouchableOpacity>
      </View>
    );
  }

  renderContactDescription = () => {
    const { data } = this.state;

    return (
      <Text style={styles.contactDescription}>
        {data && data.category}
      </Text>
    );
  }

  renderHorizontalLine = () => {
    return (
      <View style={styles.horizontalLine} />
    );
  }

  renderAddress = () => {
    const { data } = this.state;

    return (
      <View style={styles.addressWrapper}>
        <Text style={{ color: colors.gray }}>{data && data.place}</Text>
        <TouchableOpacity
          onPress={this.handleMap}
        >
          <Image
            source={mapIcon}
            style={styles.imageIcon}
          />
        </TouchableOpacity>
      </View>
    );
  }

  renderCheckedFavMarker = () => {
    return (
      <Image
        source={marker}
        style={styles.favMarkerIcon}
      />
    );
  }

  renderUnCheckedMarker = () => {
    return (
      <Image
        source={unMarker}
        style={styles.favMarkerIcon}
      />
    );
  }

  renderFavMarker = () => {
    const { favEnable } = this.state;
    const marker = favEnable ? this.renderCheckedFavMarker() : this.renderUnCheckedMarker();

    return (
      <TouchableOpacity
        onPress={this.handleFavEnable}
      // style={styles.favMarker}
      >
        {marker}
      </TouchableOpacity>
    );
  }

  renderFavourite = () => {
    const favMarker = this.renderFavMarker();

    return (
      <View style={styles.addToFavouriteWrapper}>
        <Text style={{ color: colors.gray }}>Add to Favorites</Text>

        {favMarker}
      </View>
    );
  }

  renderAboutDescription = () => {
    const { data } = this.state;
    // console.log('data', data)

    return (
      <View style={styles.aboutWrapper}>
        <Text style={styles.aboutText}>About Resturant</Text>
        <View style={styles.border} />
        <Text style={styles.intro}>
          {data.aboutResturant}
        </Text>
      </View>
    );
  }

  renderCongratsModal = () => {
    return (
      <View>
        <Modal
          isVisible={this.state.modalVisible}
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.8)', borderRadius: 4, margin: 0, // This is the important style you need to set

          }}
          transparent
        >
          <View style={{ flex: 1 }}>
            <TouchableOpacity
              onPress={this.closeModal}
              style={{ position: 'absolute', top: 20, left: 20 }}
            >
              <Image
                source={backIcon}
                style={{ width: 20, height: 20 }}
              />
            </TouchableOpacity>
            <View style={{ position: 'absolute', top: 120, left: 30 }}>
              <Text style={{ fontSize: 34 }}>You had</Text>
              <Text style={{ fontSize: 32, fontWeight: 'bold' }}>the opportunity!</Text>
              <Text style={{ width: '60%', fontSize: 15 }}>Congratulations! Your products are being prepared to be presented to you in our Restaurant.</Text>
            </View>
            <View style={{ flex: 1, justifyContent: 'center', marginBottom: 170, marginLeft: 50 }}>
              <SearchLocationComponent
                back={this.handleCloseModal}
                from="detail"
              />
            </View>
          </View>
        </Modal>
      </View >
    );
  }

  render() {
    let extraInfoArr = null;
    if (this.state.data.mapping) {
      const mapping = this.state.data.mapping;
      extraInfoArr = Object.keys(mapping).map(function (key) {
        if (mapping[key] != 'Any' && mapping[key] != 'All') {
          return (
            <View style={styles.extraRow}>
              <Text style={styles.extraKey}>{key}</Text>
              <Text style={styles.extraValue}>{mapping[key]}</Text>
            </View>
          );
        }
      });
    }

    return (
      <ScrollView style={styles.container}>
        {this.renderTopActionBar()}
        {this.renderHorizontalCorousel()}
        {this.renderDiscountPanel()}
        <View style={styles.innerContainer}>
          {this.renderContactHeader()}
          {this.renderContactDescription()}
          {this.renderHorizontalLine()}
          {this.renderAddress()}
          {this.renderHorizontalLine()}
          {this.renderFavourite()}
          {this.renderHorizontalLine()}
          {this.renderAboutDescription()}
          {this.renderCongratsModal()}
        </View>


        <Text style={styles.title}> {this.state.data.name} </Text>
        <Text style={styles.description}> {this.state.data.description} </Text>
        <Text style={styles.title}> Location </Text>
        {this.state.data.coordinate && this.state.didFinishAnimation ? (
          <MapView
            initialRegion={{
              latitude:
                this.state.data.coordinate &&
                this.state.data.coordinate._latitude,
              longitude:
                this.state.data.coordinate &&
                this.state.data.coordinate._longitude,
              latitudeDelta: LATITUDEDELTA,
              longitudeDelta: LONGITUDEDELTA,
            }}
            style={styles.mapView}
          >
            <Marker
              coordinate={{
                latitude:
                  this.state.data.coordinate &&
                  this.state.data.coordinate._latitude,
                longitude:
                  this.state.data.coordinate &&
                  this.state.data.coordinate._longitude,
              }}
            />
          </MapView>
        ) : (
            <View style={[styles.mapView, styles.loadingMap]}>
              <ActivityIndicator
                color={AppStyles.color.main}
                size="small"
              />
            </View>
          )}
        <Text style={styles.title}> Extra info </Text>
        {extraInfoArr && <View style={styles.extra}>{extraInfoArr}</View>}
        {this.state.reviews.length > 0 && (
          <Text style={[styles.title, styles.reviewTitle]}> Reviews </Text>
        )}
        <FlatList
          data={this.state.reviews}
          initialNumToRender={5}
          keyExtractor={(item) => `${item.id}`}
          renderItem={this.renderReviewItem}
        />
        {this.state.reviewModalVisible && (
          <ReviewModal
            listing={this.state.data}
            onCancel={this.onReviewCancel}
            onDone={this.onReviewCancel}
          />
        )}
      </ScrollView>
    );
  }
}

const mapStateToProps = (state) => ({
  user: state.auth.user,
  // isAdmin: state.auth.user.isAdmin,
});

export default connect(mapStateToProps)(DetailsScreen);
