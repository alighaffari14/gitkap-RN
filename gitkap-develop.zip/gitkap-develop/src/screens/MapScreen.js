import React from 'react';
import {StyleSheet, BackHandler} from 'react-native';
import firebase from 'react-native-firebase';
import MapView, {Marker} from 'react-native-maps';
import {AppIcon, AppStyles} from '../AppStyles';
import HeaderButton from '../components/HeaderButton';
import {Configuration} from '../Configuration';
import ServerConfiguration from '../ServerConfiguration';

class MapScreen extends React.Component {
  static navigationOptions = ({navigation}) => ({
    title: 'Map View',
    // headerRight: <HeaderButton icon={AppIcon.images.map} onPress={() => { navigation.goBack(null) }} />,
  });

  constructor(props) {
    super(props);

    const {navigation} = props;
    const item = navigation.getParam('item');

    if (item) {
      this.ref = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.LISTINGS)
        .where('category_id', '==', item.id);
    } else {
      this.ref = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.LISTINGS);
    }

    this.unsubscribe = null;

    this.state = {
      category: item,
      loading: false,
      data: [],
      page: 1,
      seed: 1,
      error: null,
      latitude: Configuration.map.origin.latitude,
      longitude: Configuration.map.origin.longitude,
      latitudeDelta: Configuration.map.delta.latitude,
      longitudeDelta: Configuration.map.delta.longitude,
      refreshing: false,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.unsubscribe = this.ref.onSnapshot(this.onCollectionUpdate);
    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.unsubscribe();
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onCollectionUpdate = (querySnapshot) => {
    const data = [];
    let max_latitude = -400;
    let min_latitude = 400;
    let max_longitude = -400;
    let min_logitude = 400;
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      if (max_latitude < listing.coordinate._latitude) {
max_latitude = listing.coordinate._latitude;
}
      if (min_latitude > listing.coordinate._latitude) {
min_latitude = listing.coordinate._latitude;
}
      if (max_longitude < listing.coordinate._longitude) {
max_longitude = listing.coordinate._longitude;
}
      if (min_logitude > listing.coordinate._longitude) {
min_logitude = listing.coordinate._longitude;
}
      data.push({...listing, id: doc.id});
    });

    this.setState({
      data,
      latitude: (max_latitude + min_latitude) / 2,
      longitude: (max_longitude + min_logitude) / 2,
      latitudeDelta: Math.abs(
        (max_latitude - (max_latitude + min_latitude) / 2) * 3
      ),
      longitudeDelta: Math.abs(
        (max_longitude - (max_longitude + min_logitude) / 2) * 3
      ),
      loading: false,
    });
  };

  onPress = (item) => {
    this.props.navigation.navigate('Detail', {
      item: item,
      customLeft: true,
      headerLeft: null,
      routeName: 'Map',
    });
  };

  render() {
    markerArr = this.state.data.map((listing) => (
      <Marker
        coordinate={{
          latitude: listing.coordinate._latitude,
          longitude: listing.coordinate._longitude,
        }}
        description={listing.description}
        onCalloutPress={() => {
          this.onPress(listing);
        }}
        title={listing.name}
      />
    ));

    return (
      <MapView
        region={{
          latitude: this.state.latitude,
          longitude: this.state.longitude,
          latitudeDelta: this.state.latitudeDelta,
          longitudeDelta: this.state.longitudeDelta,
        }}
        style={styles.mapView}
      >
        {markerArr}
      </MapView>
    );
  }
}

const styles = StyleSheet.create({
  mapView: {
    backgroundColor: AppStyles.color.grey,
    height: '100%',
    width: '100%',
  },
});

export default MapScreen;
