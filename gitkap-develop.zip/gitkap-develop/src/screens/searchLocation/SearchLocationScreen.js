// @flow
import React from 'react';
import {View, Text} from 'react-native';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import type {Element as ReactElement} from 'react';

import styles from './SearchLocation.styles';
import SearchLocationComponent from '../../components/searchLocation/SearchLocation.component';

type SearchLocationProps = {};
type SearchLocationState = {};

class SearchLocationScreen extends React.PureComponent<SearchLocationProps, SearchLocationState> {
  static defaultProps: any
  static navigationOptions = ({navigation}) => ({
    //   header: null,
    headerLeft: null,
    //   headerRight: null,
  });

  constructor(props: SearchLocationProps) {
    super(props);
  }

  searchOnLocation = () => {
    const {navigation} = this.props;

    const appStyles = (navigation.state.params.appStyles || this.props.navigation.getParam('appStyles'));
    const appConfig = (navigation.state.params.appConfig || this.props.navigation.getParam('appConfig'));

    // console.log('this.props.navigation.getPa', this.props.navigation.getParam('userData'));
    const userData = this.props.navigation.getParam('userData');

    this.props.navigation.navigate('mapLocationFinder', {appStyles: appStyles, appConfig: appConfig, userData: userData});
  }

  renderContent = (): ReactElement<any> => {
    return (
      <View style={styles.container}>
        <View style={{flex: 1}}>
          <View style={{padding: 30}}>
            <Text style={{fontSize: 30}}>Take the</Text>
            <Text style={{fontSize: 30, fontWeight: 'bold'}}>Oppotunity!</Text>
            <Text style={{fontSize: 15, lineHeight: 20, paddingTop: 5}}>
              Specify your location and be aware of the opportunities near you
            </Text>
          </View>
        </View>
        <View style={{flex: 3, marginHorizontal: 50}}>
          <SearchLocationComponent
            onSearchLocation={this.searchOnLocation}
          />
        </View>
      </View >
    );
  }

  render() {
    const content = this.renderContent();

    return content;
  }
}

SearchLocationScreen.propTypes = {};

SearchLocationScreen.defaultProps = {};

const mapStateToProps = (state: any, ownProps: SearchLocationProps) => {
  return {
    // TODO: Map additional props here
  };
};

export default connect(mapStateToProps)(SearchLocationScreen);
