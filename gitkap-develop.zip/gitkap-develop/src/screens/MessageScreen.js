import React from 'react';
import {
  View,
  StyleSheet,
  Text,
  FlatList,
  ActivityIndicator,
  BackHandler
} from 'react-native';
import PropTypes from 'prop-types';
import firebase from 'react-native-firebase';
import { connect } from 'react-redux';
import ChatItem from '../components/ChatItem';
import { AppStyles } from '../AppStyles';
import ServerConfiguration from '../ServerConfiguration';

class MessageScreen extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Messages'
  });

  constructor(props) {
    super(props);
    this.state = {
      channels: [],
      channelParticipations: [],
      loading: true
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      payload =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    this.channelPaticipationRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNEL_PARTICIPATION)
      .where('user', '==', this.props.user.id);
    this.channelPaticipationUnsubscribe = null;

    this.channelsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNELS)
      .orderBy('lastMessageDate', 'desc');
    this.channelsUnsubscribe = null;
  }

  componentDidMount() {
    this.channelPaticipationUnsubscribe = this.channelPaticipationRef.onSnapshot(
      this.onChannelParticipationCollectionUpdate
    );
    this.channelsUnsubscribe = this.channelsRef.onSnapshot(
      this.onChannelCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      payload =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.channelPaticipationUnsubscribe();
    this.channelsUnsubscribe();

    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    BackHandler.exitApp();
    return true;
  };

  onChannelParticipationCollectionUpdate = querySnapshot => {
    const data = [];
    querySnapshot.forEach(doc => {
      const user = doc.data();
      user.id = doc.id;

      if (user.id != this.props.user.id) {
        data.push(user);
      }
    });

    const channels = this.state.channels.filter(channel => {
      return (
        data.filter(participation => channel.id == participation.channel)
          .length > 0
      );
    });

    this.setState({
      channels: channels,
      channelParticipations: data
    });

    if (this.channelsUnsubscribe) {
      this.channelsUnsubscribe();
    }
    this.channelsUnsubscribe = this.channelsRef.onSnapshot(
      this.onChannelCollectionUpdate
    );
  };

  onChannelCollectionUpdate = querySnapshot => {
    const data = [];
    const channelPromiseArray = [];
    querySnapshot.forEach(doc => {
      channelPromiseArray.push(
        new Promise((channelResolve, channelReject) => {
          const channel = doc.data();
          channel.id = doc.id;
          channel.participants = [];
          const filters = this.state.channelParticipations.filter(
            item => item.channel == channel.id
          );
          if (filters.length > 0) {
            firebase
              .firestore()
              .collection(
                ServerConfiguration.database.collection.CHANNEL_PARTICIPATION
              )
              .where('channel', '==', channel.id)
              .onSnapshot(participationSnapshot => {
                const userPromiseArray = [];
                participationSnapshot.forEach(participationDoc => {
                  const participation = participationDoc.data();
                  participation.id = participationDoc.id;
                  if (participation.user != this.props.user.id) {
                    userPromiseArray.push(
                      new Promise((userResolve, userReject) => {
                        firebase
                          .firestore()
                          .collection(
                            ServerConfiguration.database.collection.USERS
                          )
                          .doc(participation.user)
                          .get()
                          .then(user => {
                            if (user.data()) {
                              const userData = user.data();
                              userData.id = user.id;
                              userData.participationId = participation.id;
                              channel.participants = [
                                ...channel.participants,
                                userData
                              ];
                            }
                            userResolve();
                          });
                      })
                    );
                  }
                });
                Promise.all(userPromiseArray).then(values => {
                  data.push(channel);
                  channelResolve();
                });
              });
          } else {
            channelResolve();
          }
        })
      );
    });

    Promise.all(channelPromiseArray).then(values => {
      const sortedData = data.sort((a, b) => {
        return b.lastMessageDate - a.lastMessageDate;
      });

      this.setState({
        channels: sortedData,
        loading: false
      });
    });
  };

  onPressFriend = chat => {

    this.props.navigation.navigate('PersonalMessage', { channel: chat });
  };

  formatMessage = item => {
    if (item.lastMessage.startsWith('https://firebasestorage.googleapis.com')) {
      return 'Someone sent a photo.';
    } else {
      return item.lastMessage;
    }
  };

  renderChatItem = ({ item }) => (
    <ChatItem
      formatMessage={this.formatMessage}
      onChatItemPress={this.onPressFriend}
      item={item}
    />
  );

  render() {
    const { channels } = this.state;
    if (this.state.loading) {
      return <ActivityIndicator size="small" color={AppStyles.color.main} />;
    }

    return (
      <View style={styles.chatsChannelContainer}>
        {channels.length > 0 ? (
          <FlatList
            vertical
            showsVerticalScrollIndicator={false}
            data={channels}
            renderItem={this.renderChatItem}
            keyExtractor={item => `${item.id}`}
          />
        ) : (
            <View style={styles.container}>
              <Text style={styles.noMessage}>You have no message.</Text>
            </View>
          )}
      </View>
    );
  }
}

MessageScreen.propTypes = {
  onSendInput: PropTypes.func,
  user: PropTypes.object
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ffffff',
    flex: 1
  },
  noMessage: {
    textAlign: 'center',
    color: AppStyles.color.subtitle,
    fontSize: 18,
    // fontWeight: "500",
    padding: 15
  },
  chatsChannelContainer: {
    flex: 1,
    padding: 10
  }
});

const mapStateToProps = state => ({
  user: state.auth.user
});

export default connect(mapStateToProps)(MessageScreen);
