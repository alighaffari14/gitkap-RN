import React from 'react';
import {StyleSheet, BackHandler, Text, View, Image, TouchableOpacity, Platform, Alert} from 'react-native';
import firebase from 'react-native-firebase';
import {Configuration} from '../../Configuration';
import ServerConfiguration from '../../ServerConfiguration';
import Button from 'react-native-button';
import Geolocation from '@react-native-community/geolocation';
import RNAndroidLocationEnabler from 'react-native-android-location-enabler';
import Geocoder from 'react-native-geocoding';

import LinearGradient from 'react-native-linear-gradient';
import colors from '../../shared/colors';
import metrics from '../../shared/metrics';
import MapViewComponent from '../../components/mapView/MapView.component';
import TopActionBarComponent from '../../components/topActionBar/TopActionBar.component';
import CurrentLocationComponent from '../../components/currentLocation/CurrentLocation.component';

import backIcon from '../../../assets/icons/back.png';
import GoogleInputComponent from '../../components/googleInput/GoogleInput.component';
import authDeviceStorage from '../../Core/onboarding/utils/AuthDeviceStorage';

Geolocation.setRNConfiguration({
  distanceFilter: 0.5,
  desiredAccuracy: {
    ios: 'best',
    android: 'highAccuracy',
  },
  headingOrientation: 'portrait',
  // Android ONLY
  androidProvider: 'auto',
  interval: 5000, // Milliseconds
  fastestInterval: 10000, // Milliseconds
  maxWaitTime: 5000, // Milliseconds
  // IOS ONLY
  allowsBackgroundLocationUpdates: false,
  headingFilter: 1, // Degrees
  pausesLocationUpdatesAutomatically: false,
  showsBackgroundLocationIndicator: false,
});

Geocoder.init('AIzaSyCK9195rpO4FJm0UvXImv28Dek6iEBHI4k'); // use a valid API key

class MapScreenLocationFinder extends React.PureComponent<any, any> {
  static navigationOptions = ({navigation}) => ({
    header: null,
    // headerStyle: styles.headerStyle,
    // headerTitle: <Text>Home</Text>,
    headerLeft: null,
    headerRight: null,
  });

  constructor(props) {
    super(props);

    const {navigation} = props;
    const item = navigation.getParam('item');

    if (item) {
      this.ref = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.LISTINGS)
        .where('category_id', '==', item.id);
    } else {
      this.ref = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.LISTINGS);
    }

    this.unsubscribe = null;

    this.state = {
      latitude: Configuration.map.origin.latitude,
      longitude: Configuration.map.origin.longitude,
      formattedAddress: null,
      from: props.navigation.state.params,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    const {from} = this.state;

    if (from && from.latitude) {
      this.setState({
        latitude: from.latitude,
        longitude: from.longitude,
      });
    } else {
      this.getCurrentLocation();
    }

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  getCurrentLocation() {
    if (Platform.OS == 'android') {
      RNAndroidLocationEnabler.promptForEnableLocationIfNeeded({enableHighAccuracy: true, timeout: 60000, maximumAge: 110})
        .then((data) => {
          setTimeout(() => {
            Geolocation.getCurrentPosition((info) => {
              this.setState({
                latitude: info.coords.latitude,
                longitude: info.coords.longitude,
              });

              Geocoder.from(info.coords.latitude, info.coords.longitude)
                .then((json) => {
                  const addressComponent = json.results[0].formatted_address;
                  this.setState({
                    formattedAddress: addressComponent,
                  });
                })
                .catch((error) => console.warn(error));
            });
          }, 2000);
        }).catch((err) => {
          // TODO: hadnle Error
        });
    }
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onNavigateToSuccessMap = () => {

  }

  onPress = (item) => {
    this.props.navigation.navigate('Detail', {
      item: item,
      customLeft: true,
      headerLeft: null,
      routeName: 'Map',
    });
  };

  onApprove = () => {
    const {formattedAddress, latitude, longitude} = this.state;
    const {navigation} = this.props;

    // TODO:
    // if (formattedAddress) {
    const locationDetails = {
      formattedAddress,
      latitude,
      longitude,
    };

    authDeviceStorage.setUserLocation(locationDetails);

    navigation.navigate('MainStack');
    // }
    // Alert.alert('Please wait until get your location');
  }

  renderLeftElement = () => {
    return (
      <Text>Render Lef</Text>
    );
  }

  handleNavigateBack = () => {
    const {navigation} = this.props;
    navigation.goBack();
  }

  handleGoogleInputPlace = (data, details) => {
    const address = data.description; // selected address
    this.setState({
      formattedAddress: address,
      latitude: details.geometry.location.lat,
      longitude: details.geometry.location.lng,
    });
  }

  renderTopActionBar = () => {
    const leftAction = (
      <TouchableOpacity
        onPress={this.handleNavigateBack}
        style={{padding: 10}}
      >
        <Image
          source={backIcon}
          style={styles.topActionBarImage}
        />
      </TouchableOpacity>
    );

    const rightAction = (
      <CurrentLocationComponent
        currentLocation={this.getCurrentLocation}
      />
    );

    return (
      <TopActionBarComponent
        leftAction={leftAction}
        rightAction={rightAction}
        title={null}
      />
    );
  }

  render() {
    const {formattedAddress, from} = this.state;
    const approveButton = from && from.from ? null : (
      <LinearGradient
        colors={[colors.lightOrange, colors.lightOrange, colors.darkOrange]}
        style={styles.signupContainer}
      >
        <Button
          onPress={this.onApprove}
          style={styles.signupText}
        >
          Approve
        </Button>
      </LinearGradient>
    );

    const region = {
      latitude: this.state.latitude,
      longitude: this.state.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    };

    return (
      <View style={{flex: 1}}>
        <View style={styles.topActionBar}>
          {this.renderTopActionBar()}
        </View>
        <View style={{flex: 1}}>
          <MapViewComponent
            formattedAddress={formattedAddress}
            region={region}
          />
          <GoogleInputComponent
            googleInputPlace={this.handleGoogleInputPlace}
          />
        </View>
        <View
          style={{
            position: 'absolute', // use absolute position to show button on top of the map
            top: '75%', // for center align
            alignSelf: 'center', // for align to right
          }}
        >
          {approveButton}

        </View>
      </View >
    );
  }
}

const styles = StyleSheet.create({
  mapView: {
    flex: 1,
  },
  signupContainer: {
    alignSelf: 'center',
    width: 178,
    backgroundColor: colors.darkOrange,
    // backgroundColor: appStyles.colorSet.mainThemeForegroundColor,
    // borderRadius: appStyles.sizeSet.radius,
    borderRadius: metrics.radius.medium,
    padding: 10,
    height: 49,
    marginTop: 50,
  },
  signupText: {
    color: colors.lightGray,
  },
  topActionBar: {
    padding: 10,
  },
  topActionBarImage: {
    height: 20,
    width: 20,
  },
});

export default MapScreenLocationFinder;
