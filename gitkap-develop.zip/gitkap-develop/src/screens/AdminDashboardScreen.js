import React from 'react';
import {
  FlatList,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Platform,
  Alert,
  ActivityIndicator,
  BackHandler,
} from 'react-native';

import Button from 'react-native-button';
import FastImage from 'react-native-fast-image';
import firebase from 'react-native-firebase';
import {connect} from 'react-redux';
import ActionSheet from 'react-native-actionsheet';
import {
  AppIcon,
  AppStyles,
  HeaderButtonStyle,
  TwoColumnListStyle,
} from '../AppStyles';
import SavedButton from '../components/SavedButton';
import {Configuration} from '../Configuration';
import TextButton from 'react-native-button';
import ServerConfiguration from '../ServerConfiguration';

class AdminDashboardScreen extends React.Component {
  static navigationOptions = ({navigation}) => ({
    title: 'Admin Dashboard',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={[styles.rightButton]}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);

    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .where('is_approved', '==', false);
    this.listingsUnsubscribe = null;
    this.listingItemActionSheet = React.createRef();

    this.state = {
      activeSlide: 0,
      categories: [],
      listings: [],
      allListings: [],
      selectedCategoryName: '',
      savedListings: [],
      selectedItem: null,
      showedAll: false,
      postModalVisible: false,
      isProfileModalVisible: false,
      isSavedModalVisible: false,
      isAccountDetailModalVisible: false,
      isSettingsModalVisible: false,
      isContactModalVisible: false,
      isMyListingVisible: false,
      isAddListingVisible: false,
      loading: true,
      homeCategoryId: 'aaPdF5Dskd3DrHMWV3SwLs',
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.listingsUnsubscribe = this.listingsRef.onSnapshot(
      this.onListingsCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.listingsUnsubscribe();
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onListingsCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      if (this.state.savedListings.findIndex((k) => k == doc.id) >= 0) {
        listing.saved = true;
      } else {
        listing.saved = false;
      }
      data.push({...listing, id: doc.id});
    });

    this.setState({
      listings: data.slice(0, Configuration.home.initial_show_count),
      allListings: data,
      loading: false,
      showedAll: data.length <= Configuration.home.initial_show_count,
    });
  };

  onPressListingItem = (item) => {
    this.props.navigation.navigate('MyListingDetailModal', {
      item: item,
    });
  };

  onLongPressListingItem = (item) => {
    this.setState({selectedItem: item}, () => {
      this.listingItemActionSheet.current.show();
    });
  };

  onShowAll = () => {
    this.setState({
      showedAll: true,
      listings: this.state.allListings,
    });
  };

  onLisingItemActionDone = (index) => {
    if (index === 0) {
      this.approveListing();
    }

    if (index == 1) {
      Alert.alert(
        'Delete Listing',
        'Are you sure you want to remove this listing?',
        [
          {
            text: 'Yes',
            onPress: this.removeListing,
            style: 'destructive',
          },
          {text: 'No'},
        ],
        {cancelable: false}
      );
    }
  };

  removeListing = () => {
    const self = this;

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(self.state.selectedItem.id)
      .delete()
      .then(function() {
        const realEstateSavedQuery = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
          .where('listing_id', '==', self.state.selectedItem.id);
        realEstateSavedQuery.get().then(function(querySnapshot) {
          querySnapshot.forEach(function(doc) {
            doc.ref.delete();
          });
        });
        alert('The listing was successfully deleted.');
      })
      .catch(function(error) {
        alert('There was an error deleting listing!');
      });
  };

  approveListing = () => {
    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(this.state.selectedItem.id)
      .update({is_approved: true})
      .then(function() {
        alert('Listing successfully approved!');
      })
      .catch(function(error) {
        alert('Error approving listing!');
      });
  };

  renderListingItem = ({item}) => {
    return (
      <TouchableOpacity
        onLongPress={() => this.onLongPressListingItem(item)}
        onPress={() => this.onPressListingItem(item)}
      >
        <View style={TwoColumnListStyle.listingItemContainer}>
          <FastImage
            source={{ uri: item.cover_photo }}
            style={TwoColumnListStyle.listingPhoto}
          />
          <SavedButton
            item={item}
            onPress={() => this.onPressSavedIcon(item)}
            style={TwoColumnListStyle.savedIcon}
          />
          <Text style={{...TwoColumnListStyle.listingName, maxHeight: 40}}>
            {item.name}
          </Text>
          <Text style={TwoColumnListStyle.listingPlace}>{item.place}</Text>
        </View>
      </TouchableOpacity>
    );
  };

  renderListingFooter = () => {
    return (
      <Button
        containerStyle={TwoColumnListStyle.showAllButtonContainer}
        onPress={() => this.onShowAll()}
        style={TwoColumnListStyle.showAllButtonText}
      >
        Show all ({this.state.allListings.length})
      </Button>
    );
  };

  render() {
    if (this.state.loading) {
      return <ActivityIndicator size="small"
color={AppStyles.color.main} />;
    }

    return (
      <View style={{flex: 1}}>
        {this.state.listings.length > 0 ? (
          <ScrollView style={styles.container}>
            <Text style={[styles.title, styles.listingTitle]}>
              Awaiting Approval
            </Text>
            <FlatList
              data={this.state.listings}
              keyExtractor={item => `${item.id}`}
              ListFooterComponent={
                this.state.showedAll ? '' : this.renderListingFooter
              }
              numColumns={2}
              renderItem={this.renderListingItem}
              showsVerticalScrollIndicator={false}
              vertical
            />
          </ScrollView>
        ) : (
          <View style={styles.container}>
            <Text style={styles.noMessage}>
                You have no listing awaitng approval.
              </Text>
          </View>
        )}
        <ActionSheet
          cancelButtonIndex={2}
          destructiveButtonIndex={1}
          onPress={index => {
            this.onLisingItemActionDone(index);
          }}
          options={['Approve', 'Delete', 'Cancel']}
          ref={this.listingItemActionSheet}
          title={'Confirm'}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    padding: Configuration.home.listing_item.offset,
  },
  listingTitle: {
    marginTop: 10,
    marginBottom: 15
  },
  noMessage: {
    textAlign: 'center',
    color: AppStyles.color.subtitle,
    fontSize: 18,
    padding: 15
  },
  rightButton: {
    marginRight: 10,
    color: AppStyles.color.main
  },
  title: {
    fontFamily: AppStyles.fontName.bold,
    fontWeight: 'bold',
    color: AppStyles.color.title,
    fontSize: 22
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(AdminDashboardScreen);
