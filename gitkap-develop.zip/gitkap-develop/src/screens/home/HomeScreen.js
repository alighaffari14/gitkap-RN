/* eslint-disable react/jsx-max-depth */
import React from 'react';
import {
  FlatList,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  Alert,
  BackHandler,
  TextInput,
  RefreshControl,
  Dimensions,
} from 'react-native';
import Button from 'react-native-button';
import FastImage from 'react-native-fast-image';
import firebase from 'react-native-firebase';
import {connect} from 'react-redux';
import ActionSheet from 'react-native-actionsheet';
import Carousel, {Pagination} from 'react-native-snap-carousel';
import Moment from 'moment';

import TopActionBar from '../../components/topActionBar/TopActionBar.component';
import HeaderButton from '../../components/HeaderButton';
import PostModal from '../../components/postModal/PostModal';
import GeneralOfferItemComponent from '../../components/generalOfferItem/GeneralOfferItems';

import {
  AppIcon,
  HeaderButtonStyle,
  TwoColumnListStyle,
} from '../../AppStyles';
import {Configuration} from '../../Configuration';
import ServerConfiguration from '../../ServerConfiguration';

import {INDIVIDUAL} from '../../shared/strings';
import styles from './Home.styles';
import colors from '../../shared/colors';
import authDeviceStorage from '../../Core/onboarding/utils/AuthDeviceStorage';

Moment.locale('en');

class HomeScreen extends React.PureComponent<any, any> {
  static navigationOptions = ({navigation}) => ({
    header: null,
    headerLeft: null,
    headerRight: null,
  });

  constructor(props) {
    super(props);
    this.categoriesRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CATEGORIES)
      .orderBy('order');
    if (this.props.user) {
      this.savedListingsRef = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('user_id', '==', this.props.user.id);
    } else {
      this.savedListingsRef = firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS);
    }
    this.categoriesUnsubscribe = null;
    this.listingsUnsubscribe = null;
    this.savedListingsUnsubscribe = null;
    this.listingItemActionSheet = React.createRef();

    this.state = {
      activeSlide: 0,
      categories: [],
      listings: [],
      allListings: [],
      savedListings: [],
      latestLimitedList: [],
      currentLocation: null,
      selectedItem: null,
      showedAll: false,
      postModalVisible: false,
      homeCategoryId: ServerConfiguration.database.homeCategoryId,
      userData: this.resolveUserData(),
      refreshing: false,
      userType: this.resolvUserType(),
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  async componentDidMount() {
    this.resolveCurrentLocation();
    // await this.resolveUserData();
    this.categoriesUnsubscribe = this.categoriesRef.onSnapshot(
      this.onCategoriesCollectionUpdate
    );
    this.savedListingsUnsubscribe = this.savedListingsRef.onSnapshot(
      this.onSavedListingsCollectionUpdate
    );

    this.props.navigation.setParams({
      onPressPost: this.onPressPost,
      menuIcon: this.state.userData.profilePictureURL,
      onModal: this.onModal,
    });

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.categoriesUnsubscribe();
    this.listingsUnsubscribe();
    this.savedListingsUnsubscribe();
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  resolveUserData = async () => {
    const userData = await authDeviceStorage.getUserData();
    this.setState({userData: userData});
  }

  resolvUserType = async () => {
    const userData = await authDeviceStorage.getUserData();

    const userType = JSON.parse(userData).type;

    this.setState({
      userType,
    });
  }

  onBackButtonPressAndroid = () => {
    BackHandler.exitApp();

    return true;
  };

  onCategoriesCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const category = doc.data();

      data.push({...category, id: doc.id});
    });
    this.setState({
      categories: data,
      loading: false,
    });

    if (data.length > 0) {
      this.showFirstCategoryItem(data[0]);
      //   for (let index = 0; index <= this.showFirstCategoryItem.length; index++) {
      //     this.showFirstCategoryItem(data[index]);

      // }
    }
  };

  onListingsCollectionUpdate = async (querySnapshot) => {
    const formattedUserData = JSON.parse(this.state.userData);

    const favouriteSnapshot = await firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.FAVOURITE)
      .where('userId', '==', formattedUserData.id).get();

    const favouriteData = favouriteSnapshot.docs.map((doc) => doc.data().itemId);

    const {currentLocation} = this.state;
    const savedLocation = JSON.parse(currentLocation);
    const currentLatitude = savedLocation && savedLocation.latitude;
    const currentLongitude = savedLocation && savedLocation.longitude;

    const format = 'hh:mm';

    // var time = moment() gives you current time. no format required.

    const currentTime = Moment().format(format);
    const time = Moment(currentTime, format);

    const data = [];
    const latestLimitedList = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      const latitude = listing.latitude;
      const longitude = listing.longitude;

      const distance = this.getDistanceFromLatLonInKm(currentLatitude, currentLongitude, latitude, longitude);
      listing.distance = distance;
      listing.favouriteEnable = favouriteData.includes(listing.id);
      if (this.state.savedListings.findIndex((k) => k == doc.id) >= 0) {
        listing.saved = true;
      } else {
        listing.saved = false;
      }

      if (listing.startTimer && listing.finishTimer) {
        if (time.isBetween(listing.startTimer, listing.finishTimer)) {
          listing.active = true;
        } else {
          listing.active = false;
        }
      }

      // console.log('listing', listing.startTimer, listing.finishTimer);

      latestLimitedList.length < 4 ? latestLimitedList.push({...listing, id: doc.id}) : null;
      data.push({...listing, id: doc.id});
    });

    data.sort((a, b) => (a.distance > b.distance) ? 1 : -1);

    // const addedData = this.state.listings.concat(data);

    this.setState({
      listings: data,
      latestLimitedList,
      allListings: data,
      loading: false,
      showedAll: data.length <= Configuration.home.initial_show_count,
    });
  };

  getDistanceFromLatLonInKm(lat1, lon1, lat2, lon2) {
    const R = 6371; // Radius of the earth in km
    const dLat = this.deg2radiant(lat2 - lat1); // deg2rad below
    const dLon = this.deg2radiant(lon2 - lon1);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.deg2radiant(lat1)) * Math.cos(this.deg2radiant(lat2)) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2)
      ;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const d = R * c; // Distance in km

    return d;
  }

  deg2radiant = (deg) => {
    return deg * Math.PI / 180;
  }

  resolveCurrentLocation = async () => {
    const currentLocation = await authDeviceStorage.getUserLocation();
    this.setState({currentLocation});
  }

  onSavedListingsCollectionUpdate = (querySnapshot) => {
    const savedListingdata = [];
    querySnapshot.forEach((doc) => {
      const savedListing = doc.data();
      savedListingdata.push(savedListing.listing_id);
    });
    const listingsData = [];
    this.state.listings.forEach((listing) => {
      const temp = listing;
      if (savedListingdata.findIndex((k) => k == temp.id) >= 0) {
        temp.saved = true;
      } else {
        temp.saved = false;
      }
      listingsData.push(temp);
    });

    this.setState({
      savedListings: savedListingdata,
      listings: listingsData,
      loading: false,
    });
  };

  onPressPost = () => {
    this.setState({
      selectedItem: null,
      postModalVisible: true,
    });
  };

  onPostCancel = () => {
    this.setState({postModalVisible: false});
  };

  onPressCategoryItem = (item) => {
    this.props.navigation.navigate('Listing', {item: item});
  };

  showFirstCategoryItem = (item) => {
    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .orderBy('createdAt', 'DESC');

    this.listingsUnsubscribe = this.listingsRef.onSnapshot(
      this.onListingsCollectionUpdate
    );
  };

  onPressListingItem = (item, favEnable) => {
    this.props.navigation.navigate('Detail', {item: item, userData: this.state.userData, favEnable});
  };

  // onLongPressListingItem = (item) => {
  //   if (item.user_id === this.props.user.id) {
  //     this.setState({ selectedItem: item }, () => {
  //       this.listingItemActionSheet.current.show();
  //     });
  //   }
  // };

  onShowAll = () => {
    this.setState({
      showedAll: true,
      listings: this.state.allListings,
    });
  };

  onPressSavedIcon = (item) => {
    if (item.saved) {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('listing_id', '==', item.id)
        .where('user_id', '==', this.props.user.id)
        .get()
        .then(function(querySnapshot) {
          querySnapshot.forEach(function(doc) {
            doc.ref.delete();
          });
        });
    } else {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .add({
          user_id: this.props.user.id,
          listing_id: item.id,
        })
        .then(function(docRef) { })
        .catch(function(error) {
          alert(error);
        });
    }
  };

  onModal = (modalVisible, callback) => {
    this.setState({[modalVisible]: !this.state[modalVisible]}, () => {
      callback;
    });
  };

  onAddListing = () => {
    this.onModal('isMyListingVisible', this.onModal('isAddListingVisible'));
  };

  onLisingItemActionDone = (index) => {
    if (index == 0) {
      this.setState({
        postModalVisible: true,
      });
    }

    if (index == 1) {
      Alert.alert(
        'Delete Listing',
        'Are you sure you want to remove this listing?',
        [
          {
            text: 'Yes',
            onPress: this.removeListing,
            style: 'destructive',
          },
          {text: 'No'},
        ],
        {cancelable: false}
      );
    }
  };

  removeListing = () => {
    const self = this;

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS)
      .doc(self.state.selectedItem.id)
      .delete()
      .then(function() {
        const realEstateSavedQuery = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
          .where('listing_id', '==', self.state.selectedItem.id);
        realEstateSavedQuery.get().then(function(querySnapshot) {
          querySnapshot.forEach(function(doc) {
            doc.ref.delete();
          });
        });
        alert('The listing was successfully deleted.');
      })
      .catch(function(error) {
        alert('There was an error deleting listing!');
      });
  };

  renderCategoryItem = ({item}) => (
    <TouchableOpacity onPress={() => this.onPressCategoryItem(item)}>
      <View style={styles.categoryItemContainer}>
        <FastImage
          source={{uri: item.photo}}
          style={styles.categoryItemPhoto}
        />
        <Text style={styles.categoryItemTitle}>{item.name}</Text>
      </View>
    </TouchableOpacity>
  );

  renderCategorySeparator = () => {
    return (
      <View
        style={{
          width: 10,
          height: '100%',
        }}
      />
    );
  };

  timeAgoText = (timeDifference) => {
    const diffDays = Math.floor(timeDifference / 86400000); // days
    const diffHrs = Math.floor((timeDifference % 86400000) / 3600000); // hours
    const diffMins = Math.round(((timeDifference % 86400000) % 3600000) / 60000); // minutes

    if (diffDays != 0) {
      return diffDays + ' days ago';
    } else if (diffHrs != 0) {
      return diffHrs + ' hours ago';
    } else {
      return diffMins + ' minutes ago';
    }
  }

  renderListingItem = ({item}) => {
    const dateObject = item.createdAt && item.createdAt.toDate();
    const currentDate = new Date();
    let timeAgoText = '';

    let timeDifference = null;
    if (dateObject) {
      timeDifference = currentDate - dateObject;
    }

    timeAgoText = this.timeAgoText(timeDifference);

    return (
      <GeneralOfferItemComponent
        item={item}
        pressListingItem={this.onPressListingItem}
        timeAgoText={timeAgoText}
        user={this.state.userData}
      />
    );
  };

  renderListingFooter = () => {
    return (
      <Button
        containerStyle={TwoColumnListStyle.showAllButtonContainer}
        onPress={() => this.onShowAll()}
        style={TwoColumnListStyle.showAllButtonText}
      >
        Show all ({this.state.allListings.length})
      </Button>
    );
  };

  headerLeft = () => {
    return (
      <TouchableOpacity
        onPress={() => this.props.navigation.navigate('ProfileModal', {userData: this.state.userData})}
        style={{flex: 1}}
      >
        {this.props.navigation.state.params && this.props.navigation.state.params.menuIcon ? (
          <FastImage
            resizeMode={FastImage.resizeMode.cover}
            source={{uri: this.props.navigation.state.params.menuIcon}}
            style={styles.userPhoto}
          />
        ) : (
          <FastImage
            resizeMode={FastImage.resizeMode.cover}
            source={AppIcon.images.defaultUser}
            style={styles.userPhoto}
          />
        )}
      </TouchableOpacity>
    );
  }

  headerRight = () => {
    const addIcon = this.state.userType == INDIVIDUAL ? null : this.renderAddIcon();

    return (
      <View style={[HeaderButtonStyle.multi, {flex: 1, justifyContent: 'flex-end'}]}>
        {addIcon}
        <HeaderButton
          customStyle={AppIcon.containerMapBtn}
          icon={AppIcon.images.map}
          onPress={() => {
            this.props.navigation.navigate('Map');
          }}
        />
      </View>
    );
  }

  renderLocation = () => {
    const {state: {params}} = this.props.navigation;
    const {currentLocation} = this.state;
    const location = JSON.parse(currentLocation);

    return (
      <TouchableOpacity
        onPress={this.handleSearchMap}
        style={{borderWidth: 1, padding: 3, borderRadius: 8, paddingHorizontal: 15}}
      >
        <View>
          {/* <Image source={backi} /> */}
          <Text
            numberOfLines={2}
            style={{width: 140}}
          >{location && location.formattedAddress}
          </Text>
        </View>
      </TouchableOpacity>
    );
  }

  renderAddIcon = () => {
    return (
      <HeaderButton
        customStyle={AppIcon.containerAddListingBtn}
        icon={AppIcon.images.compose}
        onPress={() => {
          this.props.navigation.state.params.onPressPost();
        }}
      />
    );
  }

  onCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      const text =
        this.searchedText != null ? this.searchedText.toLowerCase() : '';
      const index = listing.name.toLowerCase().search(text);
      if (index != -1) {
        data.push({...listing, id: doc.id});
      }
    });

    this.setState({
      listings: data,
      loading: false,
    });
  };

  handleSearch = (text) => {
    this.ref = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);
    this.searchedText = text;

    this.unsubscribe = this.ref.onSnapshot(this.onCollectionUpdate);
  }

  handleSearchMap = () => {
    const {navigation} = this.props;
    // TODO:
    // navigation.navigate("mapLocationFinder", {});
  }

  handleRefresh = () => {
    this.setState({refreshing: false});
  }

  renderSearchBar = () => {
    return (
      <TextInput
        onChangeText={this.handleSearch}
        // containerStyle={{
        //   backgroundColor: 'transparent',
        //   borderBottomColor: 'transparent',
        //   borderTopColor: 'transparent',
        //   // flex: 1
        // }}
        // inputStyle={{
        //   backgroundColor: 'rgba(0.9, 0.9, 0.9, 0.1)',
        //   borderRadius: 10,
        //   color: 'black'
        // }}
        // showLoading
        // clearIcon={true}
        // searchIcon={true}
        placeholder="Enter food name"
        // onClear={alert('onClear')}
        style={styles.searchBar}
      />
    );
  }

  renderTopActionBar = () => {
    return (
      <TopActionBar
        leftAction={this.headerLeft()}
        rightAction={this.headerRight()}
        title={this.renderLocation()}
      />
    );
  }

  renderHorizontalCorousel = () => {
    const {latestLimitedList, activeSlide} = this.state;

    const {width: viewportWidth, height: viewportHeight} = Dimensions.get('window');
    const SLIDE_WIDTH = Math.round(viewportWidth / 2.6);
    const ITEM_HORIZONTAL_MARGIN = 75;
    const ITEM_WIDTH = SLIDE_WIDTH + ITEM_HORIZONTAL_MARGIN * 2;
    const SLIDER_WIDTH = viewportWidth;

    return (
      <View>
        <Carousel
          activeSlideAlignment="start"
          autoplay
          autoplayDelay={500}
          autoplayInterval={3000}
          data={latestLimitedList}
          firstItem={0}
          // hasParallaxImages
          inactiveSlideOpacity={1}
          inactiveSlideScale={0.85}
          itemWidth={ITEM_WIDTH}
          loop
          loopClonesPerSide={2}
          onSnapToItem={(index) => this.setState({activeSlide: index})}
          ref={(c) => {
            this._slider1Ref = c;
          }}
          renderItem={this.renderListingItem}
          sliderWidth={SLIDER_WIDTH}
        />
        <Pagination
          activeDotIndex={activeSlide}
          carouselRef={this._slider1Ref}
          containerStyle={styles.paginationContainer}
          dotColor={colors.darkOrange}
          dotsLength={latestLimitedList && latestLimitedList.length}
          dotStyle={styles.paginationDot}
          inactiveDotColor={colors.gray}
          inactiveDotOpacity={0.4}
          inactiveDotScale={1}
          inactiveDotStyle={styles.paginationDot}
          tappableDots={!!this._slider1Ref}
        />
      </View>
    );
  }

  renderLatestOfferHeader = () => {
    const {listings} = this.state;

    return (
      <View style={styles.latestOfferHeader}>
        <View>
          <Text style={styles.title}>Latest Offers</Text>
          <View style={styles.horizontalLine} />
        </View>
        <Text>All ({listings.length})</Text>
      </View>
    );
  }

  renderNearestOfferHeader = () => {
    const {listings} = this.state;

    return (
      <View style={styles.latestOfferHeader}>
        <View>
          <Text style={styles.title}>Nearest Offers</Text>
          <View style={styles.horizontalLine} />
        </View>
        <Text>All ({listings.length}) | Active</Text>
      </View>
    );
  }

  render() {
    const {currentLocation} = this.state;
    const myLocation = JSON.parse(currentLocation);

    return (
      <View style={{flex: 1}}>
        {this.renderTopActionBar()}

        <View style={styles.headerTitle}>
          {this.renderSearchBar()}
        </View>
        <ScrollView
          refreshControl={
            <RefreshControl
              onRefresh={this.handleRefresh}
              refreshing={this.state.refreshing}
            />
          }
          style={styles.container}
        >
          {this.renderLatestOfferHeader()}
          {this.renderHorizontalCorousel()}
          {/* <View style={styles.categories}>
            <FlatList
              data={this.state.categories}
              horizontal
              initialNumToRender={4}
              ItemSeparatorComponent={this.renderCategorySeparator}
              keyExtractor={(item) => `${item.id}`}
              renderItem={this.renderCategoryItem}
              showsHorizontalScrollIndicator
            />
          </View> */}
          {this.renderNearestOfferHeader()}
          <View style={styles.listings}>
            <FlatList
              data={this.state.listings}
              keyExtractor={(item) => `${item.id}`}
              ListFooterComponent={
                !this.state.showedAll ? this.renderListingFooter : ''
              }
              numColumns={1}
              renderItem={this.renderListingItem}
              showsVerticalScrollIndicator={false}
              vertical
            />
          </View>
          {this.state.postModalVisible && (
            <PostModal
              categories={this.state.categories}
              location={myLocation}
              onCancel={this.onPostCancel}
              selectedItem={this.state.selectedItem}
              user={this.state.userData}
            />
          )}
          <ActionSheet
            cancelButtonIndex={2}
            destructiveButtonIndex={1}
            onPress={(index) => {
              this.onLisingItemActionDone(index);
            }}
            options={['Edit Listing', 'Remove Listing', 'Cancel']}
            ref={this.listingItemActionSheet}
            title="Confirm"
          />
        </ScrollView>
      </View >
    );
  }
}

const mapStateToProps = (state) => ({
  // user: state.auth.user,
});

export default connect(mapStateToProps)(HomeScreen);
