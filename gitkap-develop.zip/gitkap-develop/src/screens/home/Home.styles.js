// @flow
import {StyleSheet, Platform} from 'react-native';

import {Configuration} from '../../Configuration';

import {
  AppStyles, TwoColumnListStyle,
} from '../../AppStyles';
import metrics from '../../shared/metrics';
import colors from '../../shared/colors';

const styles = StyleSheet.create({
  categories: {
    marginTop: 7,
  },
  categoryItemContainer: {
    borderColor: colors.gray,
    borderRadius: 5,
    borderWidth: Platform.OS === 'ios' ? 0.2 : 1,
    paddingBottom: 10,
  },
  categoryItemPhoto: {
    borderTopLeftRadius: 5,
    borderTopRightRadius: 5,
    height: 60,
    width: 110,
  },
  categoryItemTitle: {
    color: AppStyles.color.categoryTitle,
    fontFamily: AppStyles.fontName.bold,
    fontWeight: 'bold',
    margin: 10,
  },
  container: {
    flex: 1,
    padding: 15,
  },
  // container: {
  //   backgroundColor: colors.white,
  //   flex: 1,
  // },
  headerTitle: {
    alignItems: 'center',
  },
  horizontalLine: {
    backgroundColor: colors.darkOrange,
    borderColor: colors.darkOrange,
    borderWidth: 2,
    width: 60,
  },
  latestOfferHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    padding: 20,
  },
  listingTitle: {
    marginBottom: 50,
    marginTop: 10,
  },
  paginationDot: {
    borderRadius: 0,
    height: 4,
    width: 40,
  },
  searchBar: {
    borderColor: colors.lightGray,
    borderRadius: 50,
    borderWidth: 1,
    fontSize: metrics.fonts.small,
    padding: 8,
    paddingLeft: 23,
    width: '90%',
  },
  title: {
    color: AppStyles.color.title,
    fontSize: 25,
    fontWeight: 'bold',
  },
  userPhoto: {
    borderRadius: 20,
    height: 40,
    marginLeft: 5,
    width: 40,
  },
});

export default styles;
