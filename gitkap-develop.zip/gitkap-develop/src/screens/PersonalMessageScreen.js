import React, {Component} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Text,
  BackHandler,
} from 'react-native';
import PropTypes from 'prop-types';
import {connect} from 'react-redux';
import ActionSheet from 'react-native-actionsheet';
import TextButton from 'react-native-button';
import {KeyboardAwareView} from 'react-native-keyboard-aware-view';
import ImageView from 'react-native-image-view';
import ImagePicker from 'react-native-image-crop-picker';
import firebase from 'react-native-firebase';
import DialogInput from 'react-native-dialog-input';
import BottomInput from '../components/BottomInput';
import MessageThread from '../components/MessageThread';
import ServerConfiguration from '../ServerConfiguration';

const HIT_SLOP = {top: 15, left: 15, right: 15, bottom: 15};

class PersonalMessageScreen extends React.Component {
  static navigationOptions = ({navigation}) => {
    let title = navigation.state.params.channel.name;
    let isOne2OneChannel = false;
    if (!title) {
      isOne2OneChannel = true;
      title = navigation.state.params.channel.participants[0].firstName
        ? navigation.state.params.channel.participants[0].firstName
        : navigation.state.params.channel.participants[0].fullname;
    }
    const options = {
      title,
    };

    // if (!isOne2OneChannel) {
    //   options.headerRight = (
    //     <TextButton
    //       style={{
    //         marginRight: 10,
    //       }}
    //       onPress={() => navigation.state.params.onSetting()}
    //     >
    //       Settings
    //     </TextButton>
    //   );
    // }
    return options;
  };

  constructor(props) {
    super(props);
    const channel = props.navigation.getParam('channel');
    this.state = {
      isRenameDialogVisible: false,
      threads: [],
      channel,
      value: '',
      photo: 'null',
      downloadUrl: '',
      isImageViewerVisible: false,
      tappedImageIndex: null,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );

    this.threadsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNELS)
      .doc(channel.id)
      .collection('threads')
      .orderBy('created', 'desc');
    this.threadsUnscribe = null;
    this.photoUploadDialogActionSheet = React.createRef();
  }

  componentDidMount() {
    this.threadsUnscribe = this.threadsRef.onSnapshot(
      this.onThreadsCollectionUpdate
    );
    this.props.navigation.setParams({
      onSetting: this.onSetting,
    });

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    this.threadsUnscribe();
    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  existSameSentMessage = (messages, newMessage) => {
    for (let i = 0; i < messages.length; i ++) {
      const temp = messages[i];
      if (
        newMessage.senderID == temp.senderID &&
        temp.content == newMessage.content &&
        temp.created == newMessage.created
      ) {
        return true;
      }
    }

    return false;
  };

  formatViewerImages = () => {
    const images = this.state.threads.map((item) => {
      if (item.url != '') {
        return {
          id: item.id,
          source: {
            uri: item.url,
          },
          width: Dimensions.get('window').width,
          height: Math.floor(Dimensions.get('window').height * 0.6),
        };
      }
    });

    this.cleanedChatImages = images.filter((image) => {
      if (image) {
        return image;
      }
    });

    return this.cleanedChatImages;
  };

  closeButton = () => (
    <TouchableOpacity
      hitSlop={HIT_SLOP}
      onPress={() => this.setState({isImageViewerVisible: false})}
      style={styles.closeButton}
    >
      <Text style={styles.closeButton__text}>×</Text>
    </TouchableOpacity>
  );

  onChatItemImagePress = (item) => {
    const index = this.cleanedChatImages.findIndex((image) => {
      return image.id === item.id;
    });

    this.setState({
      tappedImageIndex: index,
      isImageViewerVisible: true,
    });
  };

  onThreadsCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const message = doc.data();
      message.id = doc.id;

      if (!this.existSameSentMessage(data, message)) {
        data.push(message);
      }
    });

    this.setState({threads: data});
  };

  createOne2OneChannel = () => {
    const channelData = {
      creator_id: this.props.user.id,
      name: '',
      lastMessage: this.state.value,
      lastMessageDate: Date.now(),
    };

    const {id, profilePictureURL} = this.props.user;
    const userName = this.props.user.firstName
      ? this.props.user.firstName
      : this.props.user.fullname;

    const that = this;

    firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.CHANNELS)
      .add(channelData)
      .then(function(docRef) {
        channelData.id = docRef.id;
        channelData.participants = that.state.channel.participants;
        that.setState({channel: channelData});

        const participationData = {
          channel: docRef.id,
          user: that.props.user.id,
        };
        firebase
          .firestore()
          .collection(
            ServerConfiguration.database.collection.CHANNEL_PARTICIPATION
          )
          .add(participationData);
        const created = Date.now();
        channelData.participants.forEach((friend) => {
          const friendName = friend.firstName
            ? friend.firstName
            : friend.fullname;
          const friendParticipationData = {
            channel: docRef.id,
            user: friend.id,
          };
          firebase
            .firestore()
            .collection(
              ServerConfiguration.database.collection.CHANNEL_PARTICIPATION
            )
            .add(friendParticipationData);

          const data = {
            content: that.state.value,
            created,
            recipientFirstName: friendName,
            recipientID: friend.id,
            recipientLastName: '',
            recipientProfilePictureURL: friend.profilePictureURL,
            senderFirstName: userName,
            senderID: id,
            senderLastName: '',
            senderProfilePictureURL: profilePictureURL,
            url: that.state.downloadUrl,
          };

          firebase
            .firestore()
            .collection(ServerConfiguration.database.collection.CHANNELS)
            .doc(channelData.id)
            .collection('threads')
            .add(data)
            .then(function(docRef) {
              // alert('Successfully sent friend request!');
            })
            .catch(function(error) {
              alert(error);
            });
        });

        that.threadsRef = firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.CHANNELS)
          .doc(channelData.id)
          .collection('threads')
          .orderBy('created', 'desc');
        that.threadsUnscribe = that.threadsRef.onSnapshot(
          that.onThreadsCollectionUpdate
        );

        that.setState({value: '', downloadUrl: '', photo: ''});
      })
      .catch(function(error) {
        alert(error);
      });
  };

  uploadPromise = () => {
    const uri = this.state.photo;

    return new Promise((resolve, reject) => {
      const filename = uri.substring(uri.lastIndexOf('/') + 1);
      const uploadUri =
        Platform.OS === 'ios' ? uri.replace('file://', '') : uri;
      firebase
        .storage()
        .ref(filename)
        .putFile(uploadUri)
        .then(function(snapshot) {
          resolve(snapshot.downloadURL);
        });
    });
  };

  _send = () => {
    const {id, profilePictureURL} = this.props.user;
    const userName = this.props.user.firstName
      ? this.props.user.firstName
      : this.props.user.fullname;

    if (!this.state.channel.id) {
      this.createOne2OneChannel();
    } else {
      const created = Date.now();
      this.state.channel.participants.forEach((friend) => {
        const friendName = friend.firstName
          ? friend.firstName
          : friend.fullname;

        const data = {
          content: this.state.value,
          created,
          recipientFirstName: friendName,
          recipientID: friend.id,
          recipientLastName: '',
          recipientProfilePictureURL: friend.profilePictureURL,
          senderFirstName: userName,
          senderID: id,
          senderLastName: '',
          senderProfilePictureURL: profilePictureURL,
          url: this.state.downloadUrl,
        };

        firebase
          .firestore()
          .collection(ServerConfiguration.database.collection.CHANNELS)
          .doc(this.state.channel.id)
          .collection('threads')
          .add(data)
          .then(function(docRef) {
            // alert('Successfully sent friend request!');
          })
          .catch(function(error) {
            alert(error);
          });
      });

      let lastMessage = this.state.downloadUrl;
      if (!lastMessage) {
        lastMessage = this.state.value;
      }

      const channel = {...this.state.channel};

      delete channel.participants;
      channel.lastMessage = lastMessage;
      channel.lastMessageDate = new Date();

      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.CHANNELS)
        .doc(this.state.channel.id)
        .set(channel);
      this.setState({value: '', downloadUrl: '', photo: ''});
    }
  };

  onSend = () => {
    this._send();
  };

  onSelect = () => {
    const options = {
      title: 'Select a photo',
      storageOptions: {
        skipBackup: true,
        path: 'images',
      },
    };

    const {id, firstName, profilePictureURL} = this.props.user;
  };

  onChangeText = (text) => {
    this.setState({
      value: text,
    });
  };

  onAddImagePress = () => {
    this.photoUploadDialogActionSheet.current.show();
  };

  onPhotoUploadDialogDone = (index) => {
    if (index == 0) {
      this.onLaunchCamera();
    }

    if (index == 1) {
      this.onOpenPhotos();
    }
  };

  onLaunchCamera = () => {
    const {id, firstName, profilePictureURL} = this.props.user;

    ImagePicker.openCamera({
      cropping: false,
    })
      .then((image) => {
        const source = image.path;

        const data = {
          content: '',
          created: Date.now(),
          senderFirstName: firstName,
          senderID: id,
          senderLastName: '',
          senderProfilePictureURL: profilePictureURL,
          url: 'http://fake',
        };

        this.startUpload(source, data);
      })
      .catch(function(error) {
        this.setState({loading: false});
      });
  };

  onOpenPhotos = () => {
    const {id, firstName, profilePictureURL} = this.props.user;

    ImagePicker.openPicker({
      cropping: false,
    })
      .then((image) => {
        const source = image.path;

        const data = {
          content: '',
          created: Date.now(),
          senderFirstName: firstName,
          senderID: id,
          senderLastName: '',
          senderProfilePictureURL: profilePictureURL,
          url: 'http://fake',
        };

        this.startUpload(source, data);
      })
      .catch(function(error) {
        this.setState({loading: false});
      });
  };

  startUpload = (source, data) => {
    this.setState({
      photo: source,
      threads: [data, ...this.state.threads],
    });

    this.uploadPromise().then((url) => {
      this.setState({downloadUrl: url});
      this._send();
    });
  };

  render() {
    const {user} = this.props;
    const {
      threads,
      isRenameDialogVisible,
      channel,
      value,
      isImageViewerVisible,
      tappedImageIndex,
    } = this.state;

    return (
      <SafeAreaView style={styles.PersonalMessageContainer}>
        <KeyboardAwareView style={styles.PersonalMessageContainer}>
          <MessageThread
            onChatItemImagePress={this.onChatItemImagePress}
            threads={threads}
            user={user}
          />
          <BottomInput
            onAddImagePress={this.onAddImagePress}
            onChangeText={this.onChangeText}
            onSend={this.onSend}
            value={value}
          />
          <ActionSheet
            cancelButtonIndex={2}
            destructiveButtonIndex={1}
            options={['Rename Group', 'Leave Group', 'Cancel']}
            title="Group Settings"
          />
          <ActionSheet
            cancelButtonIndex={1}
            destructiveButtonIndex={0}
            options={['Confirm', 'Cancel']}
            title="Are you sure?"
          />
          <DialogInput
            hintInput={channel.name}
            isDialogVisible={isRenameDialogVisible}
            submitText="OK"
            textInputProps={{selectTextOnFocus: true}}
            title="Change Name"
          />
          <ActionSheet
            cancelButtonIndex={2}
            options={['Launch Camera', 'Open Photo Gallery', 'Cancel']}
            title="Photo Upload"
          />
          <ImageView
            controls={{close: this.closeButton}}
            imageIndex={this.state.tappedImageIndex}
            images={this.formatViewerImages()}
            isSwipeCloseEnabled={false}
            isVisible={this.state.isImageViewerVisible}
            onClose={() => this.setState({isImageViewerVisible: false})}
          />
          <ActionSheet
            cancelButtonIndex={2}
            onPress={this.onPhotoUploadDialogDone}
            options={['Launch Camera', 'Open Photo Gallery', 'Cancel']}
            ref={this.photoUploadDialogActionSheet}
            title="Photo Upload"
          />
        </KeyboardAwareView>
      </SafeAreaView>
    );
  }
}

PersonalMessageScreen.propTypes = {
  user: PropTypes.object,
};

const styles = StyleSheet.create({
  PersonalMessageContainer: {
    backgroundColor: '#ffffff',
    flex: 1,
  },
  closeButton: {
    alignItems: 'center',
    alignSelf: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 12,
    height: 24,
    justifyContent: 'center',
    marginRight: 15,
    marginTop: 40,
    width: 24,
  },
  closeButton__text: {
    backgroundColor: 'transparent',
    color: '#FFF',
    fontSize: 35,
    lineHeight: 35,
    textAlign: 'center',
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(PersonalMessageScreen);
