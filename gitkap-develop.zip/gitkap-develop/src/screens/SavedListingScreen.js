import React from 'react';
import {
  FlatList,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  BackHandler,
} from 'react-native';
import TextButton from 'react-native-button';
import firebase from 'react-native-firebase';
import { AppStyles, AppIcon, TwoColumnListStyle } from '../AppStyles';
import { connect } from 'react-redux';
import FastImage from 'react-native-fast-image';
import SavedButton from '../components/SavedButton';
import { Configuration } from '../Configuration';
import StarRating from 'react-native-star-rating';
import ServerConfiguration from '../ServerConfiguration';

class SavedListingScreen extends React.Component {
  static navigationOptions = ({ navigation }) => ({
    title: 'Saved Listings',
    headerLeft: null,
    headerRight: (
      <TextButton
        onPress={() => navigation.goBack()}
        style={styles.rightButton}
      >
        Cancel
      </TextButton>
    ),
  });

  constructor(props) {
    super(props);

    this.savedListingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.FAVOURITE)
      .where('userId', '==', this.props.user && this.props.user.id);

    this.state = {
      listings: [],
      savedListings: [],
      loading: false,
      error: null,
      refreshing: false,
    };

    this.didFocusSubscription = props.navigation.addListener(
      'didFocus',
      (payload) =>
        BackHandler.addEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentDidMount() {
    this.savedListingsUnsubscribe = this.savedListingsRef.onSnapshot(
      this.onSavedListingsCollectionUpdate
    );

    this.willBlurSubscription = this.props.navigation.addListener(
      'willBlur',
      (payload) =>
        BackHandler.removeEventListener(
          'hardwareBackPress',
          this.onBackButtonPressAndroid
        )
    );
  }

  componentWillUnmount() {
    if (this.listingsUnsubscribe) {
      this.listingsUnsubscribe();
    }

    if (this.savedListingsUnsubscribe) {
      this.savedListingsUnsubscribe();
    }

    this.didFocusSubscription && this.didFocusSubscription.remove();
    this.willBlurSubscription && this.willBlurSubscription.remove();
  }

  onBackButtonPressAndroid = () => {
    this.props.navigation.goBack();

    return true;
  };

  onSavedListingsCollectionUpdate = (querySnapshot) => {
    // console.log("Query: ", querySnapshot)

    const savedListingdata = [];
    querySnapshot.forEach((doc) => {
      const savedListing = doc.data();
      console.log("Data: ", savedListing)
      savedListingdata.push(savedListing.itemId);
    });

    this.listingsRef = firebase
      .firestore()
      .collection(ServerConfiguration.database.collection.LISTINGS);
    if (this.listingsUnsubscribe) this.listingsUnsubscribe();
    this.listingsUnsubscribe = this.listingsRef
      .where('is_approved', '==', true)
      .onSnapshot(this.onListingsCollectionUpdate);

    this.setState({
      savedListings: savedListingdata,
      loading: false,
    });
  };

  onListingsCollectionUpdate = (querySnapshot) => {
    const data = [];
    querySnapshot.forEach((doc) => {
      const listing = doc.data();
      if (this.state.savedListings.findIndex((k) => k == doc.id) >= 0) {
        listing.saved = true;
        data.push({ ...listing, id: doc.id });
      }
    });

    this.setState({
      listings: data,
      loading: false,
    });
  };

  onPressListingItem = (item) => {
    this.props.navigation.navigate('Detail', { item: item, userData: this.props.user, favEnable: true });
  };

  onPressSavedIcon = (item) => {
    if (item.saved) {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .where('listing_id', '==', item.id)
        .where('user_id', '==', this.props.user && this.props.user.id)
        .get()
        .then(function (querySnapshot) {
          querySnapshot.forEach(function (doc) {
            doc.ref.delete();
          });
        });
    } else {
      firebase
        .firestore()
        .collection(ServerConfiguration.database.collection.SAVED_LISTINGS)
        .add({
          user_id: this.props.user && this.props.user.id,
          listing_id: item.id,
        })
        .then(function (docRef) { })
        .catch(function (error) {
          alert(error);
        });
    }
  };

  renderListingItem = ({ item }) => {
    return (
      <TouchableOpacity onPress={() => this.onPressListingItem(item)}>
        <View style={TwoColumnListStyle.listingItemContainer}>
          <FastImage
            source={{ uri: item.cover_photo }}
            style={TwoColumnListStyle.listingPhoto}
          />
          <SavedButton
            item={item}
            onPress={() => this.onPressSavedIcon(item)}
            style={TwoColumnListStyle.savedIcon}
          />
          <Text
            numberOfLines={1}
            style={TwoColumnListStyle.listingName}
          >
            {item.name}
          </Text>
          <Text style={TwoColumnListStyle.listingPlace}>{item.place}</Text>
          <StarRating
            containerStyle={styles.starRatingContainer}
            disabled
            emptyStar={AppIcon.images.starNoFilled}
            fullStar={AppIcon.images.starFilled}
            maxStars={5}
            rating={item.starCount}
            starSize={15}
            starStyle={styles.starStyle}
          />
        </View>
      </TouchableOpacity>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <FlatList
          data={this.state.listings}
          keyExtractor={(item) => `${item.id}`}
          numColumns={2}
          renderItem={this.renderListingItem}
          showsVerticalScrollIndicator={false}
          vertical
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    backgroundColor: 'white',
    flex: 1,
    padding: Configuration.home.listing_item.offset,
  },
  rightButton: {
    color: AppStyles.color.main,
    marginRight: 10,
  },
  starRatingContainer: {
    marginTop: 10,
    width: 90,
  },
  starStyle: {
    tintColor: AppStyles.color.tint,
  },
});

const mapStateToProps = (state) => ({
  user: state.auth.user,
});

export default connect(mapStateToProps)(SavedListingScreen);
