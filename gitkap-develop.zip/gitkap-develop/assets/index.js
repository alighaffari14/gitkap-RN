export const icons = {
    "logo.png": require('./icons/logo.png'),
    "chat.png": require('./icons/chat.png'),
    "file.png": require('./icons/file.png'),
    "map.png": require('./icons/map.png'),
    "heart.png": require('./icons/heart.png'),
    "pin.png": require('./icons/pinpoint.png'),
    "filters.png": require('./icons/filters.png'),
    "instagram.png": require('./icons/instagram.png'),
    "photo.png": require('./icons/photo.png'),
    "notification.png": require('./icons/notification.png')
};
